let fetchJob = {
  running: false,
  tabId: null,
  startedAt: 0,
  videos: [],
  stopRequested: false,
  error: "",
};

const HELPER_URL = "http://127.0.0.1:8010";
let downloadJob = {
  running: false,
  type: "",
  total: 0,
  done: 0,
  message: "",
  error: "",
};

function mergeVideos(videos) {
  const map = new Map();
  for (const video of videos) {
    const key = video?.id || video?.webpage_url;
    if (!key) continue;
    const previous = map.get(key) || {};
    map.set(key, {
      ...previous,
      ...video,
      title: video.title || previous.title,
      description: video.description || previous.description,
      upload_date: video.upload_date || previous.upload_date,
      duration: video.duration || previous.duration,
      thumbnail: video.thumbnail || previous.thumbnail,
      mediaUrl: video.mediaUrl || previous.mediaUrl,
      webpage_url: video.webpage_url || previous.webpage_url,
    });
  }
  return [...map.values()];
}

async function saveJob() {
  await chrome.storage.local.set({ fetchJob });
}

function acquireBridgePath() {
  const popup = chrome.runtime.getManifest()?.action?.default_popup || "";
  return popup.startsWith("extension/") ? "extension/acquire-bridge.js" : "acquire-bridge.js";
}

async function ensureAcquireBridge(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: [acquireBridgePath()],
  });
}

async function startFetchJob(message) {
  fetchJob = {
    running: true,
    tabId: message.tabId,
    startedAt: Date.now(),
    videos: [],
    stopRequested: false,
    error: "",
    progressCount: 0,
  };
  await saveJob();
  try {
    await ensureAcquireBridge(message.tabId);
    await chrome.tabs.sendMessage(message.tabId, {
      type: "TIKGRAB_START_ACQUIRE",
      maxRounds: 300,
      maxVideos: message.maxVideos || 0,
      delayMs: message.scanDelay || 2200,
      dateFrom: message.dateFrom || "",
      dateTo: message.dateTo || "",
    });
  } catch (error) {
    fetchJob.running = false;
    fetchJob.error = "Could not connect to the TikTok tab. Refresh the TikTok profile tab, then click Fetch Videos again.";
    await saveJob();
  }
}

async function stopFetchJob() {
  fetchJob.stopRequested = true;
  fetchJob.running = false;
  if (fetchJob.tabId) {
    chrome.tabs.sendMessage(fetchJob.tabId, { type: "TIKGRAB_STOP_ACQUIRE" }).catch(() => {});
  }
  await saveJob();
}

async function helperPost(path, body) {
  const res = await fetch(`${HELPER_URL}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    let message = "Downloader helper failed.";
    try {
      const payload = await res.json();
      message = payload.detail || message;
    } catch (_) {}
    throw new Error(message);
  }
  return res.json();
}

function helperMessage(error) {
  if (/failed to fetch|network/i.test(error.message)) return "Start TikGrab Downloader Helper first, then try again.";
  return error.message;
}

async function saveDownloadJob() {
  await chrome.storage.local.set({ downloadJob });
}

async function startBackgroundDownload(videos) {
  downloadJob = { running: true, type: "download", total: videos.length, done: 0, message: "Starting downloads...", error: "" };
  await saveDownloadJob();
  try {
    for (const video of videos) {
      downloadJob.message = `Preparing ${downloadJob.done + 1} of ${videos.length}...`;
      await saveDownloadJob();
      const prepared = await helperPost("/api/prepare-video", { url: video.url, id: video.id });
      await chrome.downloads.download({
        url: `${HELPER_URL}/api/prepared/${prepared.token}`,
        filename: prepared.filename || `tiktok_${video.id || Date.now()}.mp4`,
        saveAs: false,
        conflictAction: "uniquify",
      });
      downloadJob.done += 1;
      downloadJob.message = `Started ${downloadJob.done} of ${videos.length} download(s).`;
      await saveDownloadJob();
    }
    downloadJob.running = false;
    downloadJob.message = `Download started for ${downloadJob.done} video(s).`;
  } catch (error) {
    downloadJob.running = false;
    downloadJob.error = helperMessage(error);
  }
  await saveDownloadJob();
}

async function startBackgroundZip(videos) {
  downloadJob = { running: true, type: "zip", total: videos.length, done: 0, message: "Preparing ZIP...", error: "" };
  await saveDownloadJob();
  try {
    const prepared = await helperPost("/api/prepare-zip", { videos });
    await chrome.downloads.download({
      url: `${HELPER_URL}/api/prepared/${prepared.token}`,
      filename: prepared.filename || "tiktok_videos.zip",
      saveAs: true,
      conflictAction: "uniquify",
    });
    downloadJob.running = false;
    downloadJob.done = videos.length;
    downloadJob.message = `ZIP download started with ${prepared.count || videos.length} of ${videos.length} video(s).`;
  } catch (error) {
    downloadJob.running = false;
    downloadJob.error = helperMessage(error);
  }
  await saveDownloadJob();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === "TIKGRAB_BG_START_FETCH") {
      await startFetchJob(message);
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "TIKGRAB_BG_STOP_FETCH") {
      await stopFetchJob();
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "TIKGRAB_BG_GET_JOB") {
      sendResponse({ ok: true, job: fetchJob });
      return;
    }

    if (message?.type === "TIKGRAB_BG_START_DOWNLOAD") {
      startBackgroundDownload(message.videos || []);
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "TIKGRAB_BG_START_ZIP") {
      startBackgroundZip(message.videos || []);
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "TIKGRAB_BG_GET_DOWNLOAD_JOB") {
      sendResponse({ ok: true, job: downloadJob });
      return;
    }

    if (message?.type === "TIKGRAB_CAPTURED_ITEMS" && fetchJob.running && sender.tab?.id === fetchJob.tabId) {
      fetchJob.videos = mergeVideos([...fetchJob.videos, ...(message.videos || [])]);
      await saveJob();
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "TIKGRAB_ACQUIRE_PROGRESS" && fetchJob.running && sender.tab?.id === fetchJob.tabId) {
      fetchJob.progressCount = Math.max(fetchJob.videos.length, message.count || 0);
      await saveJob();
      sendResponse({ ok: true });
      return;
    }

    if ((message?.type === "TIKGRAB_ACQUIRE_DONE" || message?.type === "TIKGRAB_ACQUIRE_STOPPED") && sender.tab?.id === fetchJob.tabId) {
      fetchJob.running = false;
      fetchJob.stopped = message.type === "TIKGRAB_ACQUIRE_STOPPED";
      fetchJob.error = message.error || "";
      await saveJob();
      sendResponse({ ok: true });
      return;
    }
  })();
  return true;
});
