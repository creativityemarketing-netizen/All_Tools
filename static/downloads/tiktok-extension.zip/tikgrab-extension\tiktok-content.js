(function () {
  "use strict";

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function parseJsonScript(id) {
    const el = document.getElementById(id);
    if (!el) return null;
    try {
      const textarea = document.createElement("textarea");
      textarea.innerHTML = el.textContent || "";
      return JSON.parse(textarea.value);
    } catch (_) {
      return null;
    }
  }

  function findSecUid() {
    const sigi = parseJsonScript("SIGI_STATE");
    const users = sigi?.UserModule?.users || sigi?.userModule?.users || {};
    for (const user of Object.values(users)) {
      if (user?.secUid) return user.secUid;
    }

    const universal = parseJsonScript("__UNIVERSAL_DATA_FOR_REHYDRATION__");
    const user = universal?.__DEFAULT_SCOPE__?.["webapp.user-detail"]?.userInfo?.user;
    if (user?.secUid) return user.secUid;

    const next = parseJsonScript("__NEXT_DATA__");
    const nextSecUid = next?.props?.pageProps?.userInfo?.user?.secUid;
    if (nextSecUid) return nextSecUid;

    for (const script of document.querySelectorAll("script")) {
      const match = (script.textContent || "").match(/"secUid"\s*:\s*"([^"]{20,})"/);
      if (match) return match[1];
    }
    return "";
  }

  function first(...values) {
    return values.find((value) => value !== undefined && value !== null && value !== "") || "";
  }

  function normalizeItem(item) {
    const stats = item.stats || item.statsV2 || {};
    const author = item.author || {};
    const video = item.video || {};
    const id = item.id || item.aweme_id || "";
    const handle = author.uniqueId || author.unique_id || location.pathname.split("/").find((part) => part.startsWith("@"))?.slice(1) || "";
    const mediaUrl = first(
      video.playAddr,
      video.downloadAddr,
      video.bitRate?.[0]?.playAddr?.[0],
      video.bitRate?.[0]?.PlayAddr?.UrlList?.[0]
    );

    return {
      id,
      uploader: handle,
      title: item.desc || item.description || "Untitled",
      description: item.desc || item.description || "",
      upload_date: item.createTime ? new Date(Number(item.createTime) * 1000).toISOString().slice(0, 10).replace(/-/g, "") : "",
      timestamp: item.createTime || null,
      duration: video.duration ? Number(video.duration) : null,
      view_count: Number(stats.playCount || stats.play_count || 0),
      like_count: Number(stats.diggCount || stats.digg_count || 0),
      comment_count: Number(stats.commentCount || stats.comment_count || 0),
      repost_count: Number(stats.shareCount || stats.share_count || 0),
      thumbnail: first(video.cover, video.originCover, video.dynamicCover),
      mediaUrl,
      webpage_url: id && handle ? `https://www.tiktok.com/@${handle}/video/${id}` : "",
    };
  }

  async function fetchPage(secUid, cursor) {
    const params = new URLSearchParams({
      secUid,
      count: "30",
      cursor: String(cursor || 0),
      aid: "1988",
      app_language: "en",
    });

    const response = await fetch(`https://www.tiktok.com/api/post/item_list/?${params}`, {
      credentials: "include",
      headers: { "Accept": "application/json,text/plain,*/*" },
    });
    const text = await response.text();
    if (!response.ok) throw new Error(`TikTok returned HTTP ${response.status}.`);
    if (!text.trim()) throw new Error("TikTok returned an empty response. Refresh the TikTok profile and try again.");
    return JSON.parse(text);
  }

  function normalizeDomCard(anchor) {
    const href = anchor.href || "";
    const id = href.match(/\/video\/(\d+)/)?.[1] || "";
    const handle = location.pathname.split("/").find((part) => part.startsWith("@"))?.slice(1) || "";
    const card = anchor.closest("div") || anchor;
    const image = card.querySelector("img") || anchor.querySelector("img");
    const title = image?.alt || anchor.getAttribute("aria-label") || card.textContent?.trim() || "TikTok video";

    return {
      id,
      uploader: handle,
      title,
      description: title,
      upload_date: "",
      timestamp: null,
      duration: null,
      view_count: null,
      like_count: null,
      comment_count: null,
      repost_count: null,
      thumbnail: image?.src || "",
      mediaUrl: "",
      webpage_url: href,
    };
  }

  async function fetchFromDom(maxVideos, sendProgress) {
    const seen = new Set();
    const videos = [];
    let stableRounds = 0;

    for (let round = 0; round < 80; round += 1) {
      const before = videos.length;
      document.querySelectorAll('a[href*="/video/"]').forEach((anchor) => {
        const href = anchor.href;
        if (!href || seen.has(href)) return;
        seen.add(href);
        videos.push(normalizeDomCard(anchor));
      });

      sendProgress(videos.length);
      if (maxVideos && videos.length >= maxVideos) return videos.slice(0, maxVideos);

      if (videos.length === before) stableRounds += 1;
      else stableRounds = 0;
      if (stableRounds >= 8 && videos.length > 0) break;

      window.scrollTo(0, document.body.scrollHeight);
      await sleep(1200);
    }

    if (!videos.length) {
      throw new Error("Could not find videos on the profile page. Open TikTok, log in if needed, then try again.");
    }
    return videos;
  }

  async function fetchAll(maxVideos, sendProgress) {
    const secUid = findSecUid();
    if (!secUid) return fetchFromDom(maxVideos, sendProgress);

    const videos = [];
    let cursor = 0;
    let hasMore = true;
    let page = 0;

    try {
      while (hasMore) {
        page += 1;
        const data = await fetchPage(secUid, cursor);
        const items = data.itemList || data.item_list || [];
        videos.push(...items.map(normalizeItem));
        sendProgress(videos.length);

        hasMore = Boolean(data.hasMore) && items.length > 0;
        cursor = data.nextCursor || data.cursor || 0;
        if (maxVideos && videos.length >= maxVideos) break;
        if (page > 200) break;
        await sleep(900);
      }
    } catch (_error) {
      return fetchFromDom(maxVideos, sendProgress);
    }

    if (!videos.length) return fetchFromDom(maxVideos, sendProgress);
    return maxVideos ? videos.slice(0, maxVideos) : videos;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "TIKGRAB_FETCH_PROFILE") return false;

    fetchAll(Number(message.maxVideos || 0), (count) => {
      chrome.runtime.sendMessage({ type: "TIKGRAB_PROGRESS", count }).catch(() => {});
    })
      .then((videos) => sendResponse({ ok: true, videos }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));

    return true;
  });
})();
