(function () {
  "use strict";

  if (window.__tikgrabAcquireBridgeLoaded) return;
  window.__tikgrabAcquireBridgeLoaded = true;

  function injectHook() {
    if (document.documentElement.dataset.tikgrabHooked === "1") return;
    document.documentElement.dataset.tikgrabHooked = "1";

    const script = document.createElement("script");
    script.textContent = `(() => {
      if (window.__tikgrabHooked) return;
      window.__tikgrabHooked = true;

      const post = (payload) => window.postMessage({ source: "tikgrab-hook", ...payload }, "*");

      function parsePayload(url, text) {
        if (!text || !/itemList|item_list|itemStruct|aweme_list|ItemModule/.test(text)) return;
        try {
          const data = JSON.parse(text);
          const items = data.itemList || data.item_list || data.aweme_list || [];
          if (Array.isArray(items) && items.length) post({ type: "items", url, items });
          const item = data?.itemInfo?.itemStruct || data?.itemStruct || data?.item;
          if (item) post({ type: "items", url, items: [item] });
        } catch (_) {}
      }

      const originalFetch = window.fetch;
      window.fetch = async function (...args) {
        const response = await originalFetch.apply(this, args);
        try {
          const url = String(args[0]?.url || args[0] || response.url || "");
          if (/\\/api\\/(post\\/item_list|item\\/detail)|aweme/i.test(url)) {
            response.clone().text().then((text) => parsePayload(url, text)).catch(() => {});
          }
        } catch (_) {}
        return response;
      };

      const originalOpen = XMLHttpRequest.prototype.open;
      const originalSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function (method, url, ...rest) {
        this.__tikgrabUrl = String(url || "");
        return originalOpen.call(this, method, url, ...rest);
      };
      XMLHttpRequest.prototype.send = function (...args) {
        this.addEventListener("load", function () {
          try {
            if (/\\/api\\/(post\\/item_list|item\\/detail)|aweme/i.test(this.__tikgrabUrl || "")) {
              parsePayload(this.__tikgrabUrl, this.responseText);
            }
          } catch (_) {}
        });
        return originalSend.apply(this, args);
      };

      post({ type: "ready" });
    })();`;
    (document.documentElement || document.head).appendChild(script);
    script.remove();
  }

  function first(...values) {
    return values.find((value) => value !== undefined && value !== null && value !== "") || "";
  }

  function isMediaUrl(url) {
    if (!/^https?:\/\//i.test(url || "")) return false;
    return /tiktokcdn|byteoversea|ibytedtos|bytefcdn|\.mp4|mime_type=video|video_mp4/i.test(url);
  }

  function cleanUrl(value) {
    return String(value || "")
      .replace(/\\u002F/g, "/")
      .replace(/\\\//g, "/")
      .replace(/\\u0026/g, "&")
      .replace(/&amp;/g, "&");
  }

  function uploadDateFromId(id) {
    try {
      const timestamp = Number(BigInt(String(id)) >> 32n);
      if (!timestamp) return "";
      return new Date(timestamp * 1000).toISOString().slice(0, 10).replace(/-/g, "");
    } catch (_) {
      return "";
    }
  }

  function durationToSeconds(value) {
    const raw = String(value || "").trim();
    const match = raw.match(/\b(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\b|\b(\d{1,2}):(\d{2})\b/);
    if (!match) return null;
    if (match[4] !== undefined) return Number(match[4]) * 60 + Number(match[5]);
    return (Number(match[1] || 0) * 3600) + (Number(match[2]) * 60) + Number(match[3]);
  }

  function findDurationInCard(card) {
    const selectors = [
      '[data-e2e*="duration"]',
      '[class*="duration" i]',
      '[class*="time" i]',
      'span',
      'div',
    ];
    for (const selector of selectors) {
      for (const node of card.querySelectorAll(selector)) {
        const duration = durationToSeconds(text(node));
        if (duration) return duration;
      }
    }
    return durationToSeconds(text(card));
  }

  function text(node) {
    return (node?.textContent || "").trim();
  }

  function normalizeDomCard(anchor) {
    const href = anchor.href || "";
    const id = href.match(/\/video\/(\d+)/)?.[1] || "";
    const handle = location.pathname.split("/").find((part) => part.startsWith("@"))?.slice(1) || "";
    const card = anchor.closest('[data-e2e*="user-post"], [class*="DivWrapper"], [class*="video-feed"], div') || anchor;
    const img = card.querySelector("img") || anchor.querySelector("img");
    const videoNode = card.querySelector("video") || anchor.querySelector("video");
    const descNode = card.querySelector('[data-e2e="user-post-item-desc"], [data-e2e*="desc"], h1, h2, p, span');
    const title = img?.alt || text(descNode) || anchor.getAttribute("aria-label") || "TikTok video";
    const mediaCandidate = cleanUrl(videoNode?.currentSrc || videoNode?.src || "");
    return {
      id,
      uploader: handle,
      title,
      description: title,
      upload_date: uploadDateFromId(id),
      timestamp: null,
      duration: findDurationInCard(card),
      view_count: null,
      like_count: null,
      comment_count: null,
      repost_count: null,
      thumbnail: img?.currentSrc || img?.src || "",
      mediaUrl: isMediaUrl(mediaCandidate) ? mediaCandidate : "",
      webpage_url: href,
    };
  }

  function collectDomVideos() {
    const seen = new Set();
    return [...document.querySelectorAll('a[href*="/video/"]')]
      .filter((anchor) => {
        if (!anchor.href || seen.has(anchor.href)) return false;
        seen.add(anchor.href);
        return true;
      })
      .map(normalizeDomCard)
      .filter((video) => video.id || video.webpage_url);
  }

  function normalizeItem(item) {
    const stats = item.stats || item.statsV2 || {};
    const author = item.author || {};
    const video = item.video || {};
    const id = item.id || item.aweme_id || "";
    const handle = author.uniqueId || author.unique_id || location.pathname.split("/").find((part) => part.startsWith("@"))?.slice(1) || "";
    const mediaCandidates = [
      video.playAddr,
      video.downloadAddr,
      video.play_addr?.url_list?.[0],
      video.download_addr?.url_list?.[0],
      video.bitRate?.[0]?.playAddr?.[0],
      video.bitRate?.[0]?.PlayAddr?.UrlList?.[0],
      item.video?.play_addr?.url_list?.[0],
    ].map(cleanUrl);
    const mediaUrl = mediaCandidates.find(isMediaUrl) || "";
    const durationRaw = Number(video.duration || video.durationSecond || item.duration || 0);
    const duration = durationRaw > 1000 ? Math.round(durationRaw / 1000) : durationRaw || null;
    const description = item.desc || item.description || "";

    return {
      id,
      uploader: handle,
      title: description || "TikTok video",
      description,
      upload_date: item.createTime ? new Date(Number(item.createTime) * 1000).toISOString().slice(0, 10).replace(/-/g, "") : uploadDateFromId(id),
      timestamp: item.createTime || null,
      duration,
      view_count: Number(stats.playCount || stats.play_count || 0) || null,
      like_count: Number(stats.diggCount || stats.digg_count || 0) || null,
      comment_count: Number(stats.commentCount || stats.comment_count || 0) || null,
      repost_count: Number(stats.shareCount || stats.share_count || 0) || null,
      thumbnail: first(video.cover, video.originCover, video.dynamicCover),
      mediaUrl,
      webpage_url: id && handle ? `https://www.tiktok.com/@${handle}/video/${id}` : "",
    };
  }

  function dateFromId(id) {
    try {
      const timestamp = Number(BigInt(String(id)) >> 32n);
      if (!timestamp) return "";
      return new Date(timestamp * 1000).toISOString().slice(0, 10).replace(/-/g, "");
    } catch (_) {
      return "";
    }
  }

  function collectedDates() {
    return [...document.querySelectorAll('a[href*="/video/"]')]
      .map((anchor) => anchor.href.match(/\/video\/(\d+)/)?.[1] || "")
      .map(dateFromId)
      .filter(Boolean);
  }

  async function acquireByScrolling(maxRounds, delayMs, dateFrom, dateTo, maxVideos) {
    window.__tikgrabStopAcquire = false;
    const scroller = document.scrollingElement || document.documentElement || document.body;
    let stable = 0;
    let lastCount = 0;
    for (let round = 0; round < maxRounds && !window.__tikgrabStopAcquire; round += 1) {
      const domVideos = collectDomVideos();
      if (domVideos.length) chrome.runtime.sendMessage({ type: "TIKGRAB_CAPTURED_ITEMS", videos: domVideos }).catch(() => {});
      const count = domVideos.length;
      const dates = collectedDates();
      const oldest = dates.length ? dates.sort()[0] : "";
      chrome.runtime.sendMessage({ type: "TIKGRAB_ACQUIRE_PROGRESS", count, round }).catch(() => {});
      if (maxVideos && count >= maxVideos) break;
      if (dateFrom && oldest && oldest < dateFrom) break;
      if (count === lastCount && scroller.scrollTop + window.innerHeight >= scroller.scrollHeight - 10) stable += 1;
      else stable = 0;
      if (stable >= 12 && count > 0) break;
      lastCount = count;
      scroller.scrollTop = Math.min(scroller.scrollTop + Math.max(420, Math.floor(window.innerHeight * 0.55)), scroller.scrollHeight);
      window.dispatchEvent(new Event("scroll"));
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
    const finalVideos = collectDomVideos();
    if (finalVideos.length) chrome.runtime.sendMessage({ type: "TIKGRAB_CAPTURED_ITEMS", videos: finalVideos }).catch(() => {});
    chrome.runtime.sendMessage({
      type: window.__tikgrabStopAcquire ? "TIKGRAB_ACQUIRE_STOPPED" : "TIKGRAB_ACQUIRE_DONE",
      error: finalVideos.length ? "" : "No videos were found on this TikTok profile tab. Make sure the Videos grid is visible, refresh the TikTok tab, then try again.",
    }).catch(() => {});
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.data?.source !== "tikgrab-hook") return;
    if (event.data.type === "items") {
      const videos = (event.data.items || []).map(normalizeItem).filter((video) => video.id);
      if (videos.length) chrome.runtime.sendMessage({ type: "TIKGRAB_CAPTURED_ITEMS", videos }).catch(() => {});
    }
  });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "TIKGRAB_START_ACQUIRE") {
      acquireByScrolling(
        Number(message.maxRounds || 260),
        Number(message.delayMs || 2200),
        message.dateFrom || "",
        message.dateTo || "",
        Number(message.maxVideos || 0)
      );
      sendResponse({ ok: true });
      return true;
    }
    if (message?.type === "TIKGRAB_STOP_ACQUIRE") {
      window.__tikgrabStopAcquire = true;
      sendResponse({ ok: true });
      return true;
    }
    return false;
  });

  injectHook();
})();
