﻿# TikGrab Extension

1. Extract this ZIP file.
2. Open Chrome or Edge and go to chrome://extensions.
3. Turn on Developer mode.
4. Click Load unpacked.
5. Select the tikgrab-extension folder that contains manifest.json.

Open a TikTok profile tab, then use TikGrab for single downloads, bulk profile fetch, filters, exports, and description search.
