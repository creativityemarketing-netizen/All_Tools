let currentVideos = [];
let rawVideos = [];
let searchVideos = [];
let restoringState = false;
let detectedProfile = null;
let capturedVideos = new Map();
let fetchController = null;
let jobPollId = null;
let searchPollId = null;

const $ = (id) => document.getElementById(id);

function fmtNum(n) {
  if (n == null || Number.isNaN(Number(n))) return "-";
  const value = Number(n);
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
  return String(value);
}

function fmtDate(value) {
  if (!value) return "-";
  if (String(value).length >= 8 && !String(value).includes("-")) {
    const d = String(value);
    return `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}`;
  }
  const date = new Date(Number(value) * 1000);
  return Number.isNaN(date.getTime()) ? "-" : date.toISOString().slice(0, 10);
}

function exportDate(value) {
  if (!value) return "";
  const text = String(value);
  if (/^\d{8}$/.test(text)) return `${text.slice(0, 4)}-${text.slice(4, 6)}-${text.slice(6, 8)}`;
  return fmtDate(value);
}

function fmtDur(s) {
  if (s == null) return "-";
  if (typeof s === "string" && s.includes(":")) return s;
  let value = Number(s);
  if (value > 1000) value = value / 1000;
  const minutes = Math.floor(value / 60);
  const seconds = Math.floor(value % 60);
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function exportDuration(value) {
  if (value === null || value === undefined || value === "") return "";
  return fmtDur(value);
}

function showAlert(id, msg, type = "error") {
  const el = $(id);
  el.textContent = msg;
  el.className = `alert alert-${type} visible`;
}

function hideAlert(id) {
  $(id).className = "alert";
}

function setProgress(barId, textId, pct, label) {
  $(barId).style.width = `${pct}%`;
  $(textId).textContent = label;
}

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  document.querySelectorAll(".theme-toggle-option").forEach((opt) => {
    opt.classList.toggle("active", opt.dataset.themeVal === theme);
  });
  localStorage.setItem("tikgrab-theme", theme);
}

const storageGet = (keys) => chrome.storage.local.get(keys);
const storageSet = (values) => chrome.storage.local.set(values);
const HELPER_URL = "http://127.0.0.1:8010";

function readFormState() {
  return {
    singleUrl: $("single-url")?.value || "",
    filterDateFrom: $("filter-date-from")?.value || "",
    filterDateTo: $("filter-date-to")?.value || "",
    bulkMax: $("bulk-max")?.value || "",
    searchWords: $("search-words")?.value || "",
    searchMatchAll: $("search-match-all")?.checked ?? true,
    searchMax: $("search-max")?.value || "",
  };
}

function restoreFormState(state = {}) {
  const map = {
    "single-url": state.singleUrl,
    "filter-date-from": state.filterDateFrom,
    "filter-date-to": state.filterDateTo,
    "bulk-max": state.bulkMax,
    "search-words": state.searchWords,
    "search-max": state.searchMax,
  };
  Object.entries(map).forEach(([id, value]) => {
    if ($(id) && value !== undefined) $(id).value = value;
  });
  if ($("search-match-all")) $("search-match-all").checked = state.searchMatchAll ?? true;
}

function activeTabName() {
  return document.querySelector(".tab-btn.active")?.dataset.tab || "bulk";
}

function activateTab(tabName) {
  const btn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
  const panel = $(`tab-${tabName}`);
  if (!btn || !panel) return;
  document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
  document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
  btn.classList.add("active");
  panel.classList.add("active");
}

async function saveState() {
  if (restoringState) return;
  await storageSet({
    currentVideos,
    rawVideos,
    searchVideos,
    activeTab: activeTabName(),
    formState: readFormState(),
  });
}

async function restoreState() {
  restoringState = true;
  const saved = await storageGet(["currentVideos", "rawVideos", "searchVideos", "activeTab", "formState"]);
  currentVideos = Array.isArray(saved.currentVideos) ? saved.currentVideos : [];
  rawVideos = Array.isArray(saved.rawVideos) ? saved.rawVideos : currentVideos;
  searchVideos = Array.isArray(saved.searchVideos) ? saved.searchVideos : [];
  restoreFormState(saved.formState || {});
  if (currentVideos.length) renderBulkResults(currentVideos);
  if (searchVideos.length) renderSearchResults(searchVideos);
  activateTab(saved.activeTab || "bulk");
  restoringState = false;
}

function escapeHtml(value) {
  return String(value || "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  }[char]));
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function wordsFromInput(value) {
  return String(value || "").split(/[,\s]+/).map((word) => word.trim()).filter(Boolean);
}

function highlightSearchWords(value, words = []) {
  const safeText = escapeHtml(value);
  const uniqueWords = [...new Set(words.filter(Boolean))].sort((a, b) => b.length - a.length);
  if (!uniqueWords.length) return safeText;
  const pattern = new RegExp(`(${uniqueWords.map(escapeRegExp).join("|")})`, "gi");
  return safeText.replace(pattern, '<mark class="search-highlight">$1</mark>');
}

function currentSearchWords() {
  return wordsFromInput($("search-words")?.value || "").map((word) => word.toLowerCase());
}

function searchableText(video) {
  return [
    video.description,
    video.title,
    video.contents?.[0]?.desc,
  ].filter(Boolean).join(" ").toLowerCase();
}

function filterSearchVideos(videos, words, matchAll) {
  return videos.filter((video) => {
    const description = searchableText(video);
    return matchAll ? words.every((word) => description.includes(word)) : words.some((word) => description.includes(word));
  });
}

function handleFromTikTokUrl(urlValue) {
  try {
    const url = new URL(urlValue || "");
    if (!url.hostname.includes("tiktok.com")) return "";
    const handle = url.pathname.split("/").find((part) => part.startsWith("@"));
    return handle ? handle.slice(1) : "";
  } catch (_) {
    return "";
  }
}

async function detectCurrentProfile() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const active = tabs[0];
  const activeHandle = handleFromTikTokUrl(active?.url);
  if (activeHandle) {
    detectedProfile = { handle: activeHandle, tab: active };
    updateDetectedProfile();
    return detectedProfile;
  }

  const profileTabs = await chrome.tabs.query({ url: "https://www.tiktok.com/@*" });
  const firstProfile = profileTabs.find((tab) => handleFromTikTokUrl(tab.url));
  if (firstProfile) {
    detectedProfile = { handle: handleFromTikTokUrl(firstProfile.url), tab: firstProfile };
  } else {
    detectedProfile = null;
  }
  updateDetectedProfile();
  return detectedProfile;
}

function updateDetectedProfile() {
  const label = detectedProfile?.handle ? `@${detectedProfile.handle}` : "No TikTok profile detected";
  if ($("current-profile-name")) $("current-profile-name").textContent = label;
  if ($("search-profile-name")) $("search-profile-name").textContent = label;
}

async function requireCurrentProfile() {
  const profile = await detectCurrentProfile();
  if (!profile?.handle || !profile?.tab?.id) {
    throw new Error("Open a TikTok profile tab first, then click Fetch Videos.");
  }
  return profile;
}

function normalizeVideoUrl(input) {
  const value = input.trim();
  if (!/^https?:\/\//i.test(value)) throw new Error("Enter a TikTok video URL.");
  return value;
}

function isDownloadableMediaUrl(url) {
  if (!/^https?:\/\//i.test(url || "")) return false;
  try {
    const parsed = new URL(url);
    const fullUrl = decodeURIComponent(url).toLowerCase();
    const host = parsed.hostname.toLowerCase();
    if (parsed.hostname.includes("tiktok.com") && /\/@[^/]+\/video\//.test(parsed.pathname)) return false;
    if (/\.(?:jpe?g|jfif|png|webp|gif|avif)(?:$|[?#])|mime_type=image|image\/|~tplv-/i.test(fullUrl)) return false;
    return /\.mp4(?:$|[?#])|mime_type=video|video_mp4|\/video\/|video\/tos|\/tos-[^/?#]+\/|tiktokcdn|tiktokv|muscdn|akamaized|byteoversea|ibytedtos|bytefcdn/i.test(fullUrl)
      || /tiktokcdn|tiktokv|muscdn|akamaized|byteoversea|ibytedtos|bytefcdn/i.test(host);
  } catch (_) {
    return false;
  }
}

function isImageContentType(type) {
  return /^image\//i.test(type || "");
}

function isVideoContentType(type) {
  return /^video\//i.test(type || "") || /octet-stream/i.test(type || "");
}

function isDefinitelyNotVideoContentType(type) {
  return /^(?:image|text)\//i.test(type || "") || /json|html|xml/i.test(type || "");
}

function looksLikeMp4Bytes(bytes) {
  if (!bytes || bytes.length < 12) return false;
  const text = (offset, length) => String.fromCharCode(...bytes.slice(offset, offset + length));
  if (text(4, 4) === "ftyp" || text(4, 4) === "styp") return true;
  const header = text(0, Math.min(bytes.length, 4096));
  return /ftyp|styp|moov|moof|mdat/.test(header);
}

async function blobToVerifiedVideoBytes(blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  if (!bytes.length) throw new Error("TikTok returned an empty video file.");
  if (!looksLikeMp4Bytes(bytes)) throw new Error("TikTok returned bytes that are not a playable MP4 file.");
  return bytes;
}

function decodeMaybeEscapedUrl(value) {
  if (!value) return "";
  return value
    .replace(/\\u002F/g, "/")
    .replace(/\\\//g, "/")
    .replace(/\\u0026/g, "&")
    .replace(/&amp;/g, "&");
}

function mediaCandidatesFromValue(value) {
  if (!value) return [];
  if (typeof value === "string") return [decodeMaybeEscapedUrl(value)];
  if (Array.isArray(value)) return value.flatMap(mediaCandidatesFromValue);
  if (typeof value === "object") {
    return [
      value.url,
      value.uri,
      value.playAddr,
      value.downloadAddr,
      value.UrlList,
      value.urlList,
      value.url_list,
    ].flatMap(mediaCandidatesFromValue);
  }
  return [];
}

function extractMediaUrlFromItem(item) {
  const video = item?.video || item?.Video || {};
  const candidates = [
    video.playAddr,
    video.downloadAddr,
    video.play_addr,
    video.download_addr,
    video.PlayAddr,
    video.DownloadAddr,
    video.bitRate,
    video.bitrateInfo,
    item?.video?.play_addr,
    item?.video?.download_addr,
  ].flatMap(mediaCandidatesFromValue);
  return candidates.find(isDownloadableMediaUrl) || "";
}

function extractMediaUrlFromHtml(html) {
  const patterns = [
    /"playAddr"\s*:\s*"([^"]+)"/i,
    /"downloadAddr"\s*:\s*"([^"]+)"/i,
    /"play_addr"\s*:\s*\{[^}]*"url_list"\s*:\s*\[\s*"([^"]+)"/i,
    /"PlayAddr"\s*:\s*\{[^}]*"UrlList"\s*:\s*\[\s*"([^"]+)"/i,
    /<video[^>]+src=["']([^"']+)["']/i,
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    const url = decodeMaybeEscapedUrl(match?.[1] || "");
    if (isDownloadableMediaUrl(url)) return url;
  }

  for (const id of ["SIGI_STATE", "__UNIVERSAL_DATA_FOR_REHYDRATION__", "__NEXT_DATA__"]) {
    const data = parseJsonScript(html, id);
    const items = [];
    if (id === "SIGI_STATE") items.push(...Object.values(data?.ItemModule || data?.itemModule || {}));
    if (id === "__UNIVERSAL_DATA_FOR_REHYDRATION__") items.push(data?.__DEFAULT_SCOPE__?.["webapp.video-detail"]?.itemInfo?.itemStruct);
    if (id === "__NEXT_DATA__") items.push(data?.props?.pageProps?.itemInfo?.itemStruct);
    for (const item of items.filter(Boolean)) {
      const mediaUrl = extractMediaUrlFromItem(item);
      if (mediaUrl) return mediaUrl;
    }
  }
  return "";
}

function uploadDateFromTikTokId(id) {
  try {
    const timestamp = Number(BigInt(String(id)) >> 32n);
    if (!timestamp || timestamp < 1_000_000_000) return "";
    return new Date(timestamp * 1000).toISOString().slice(0, 10).replace(/-/g, "");
  } catch (_) {
    return "";
  }
}

async function fetchText(url) {
  const response = await fetch(url, {
    credentials: "include",
    headers: {
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    },
  });
  if (!response.ok) throw new Error(`TikTok returned HTTP ${response.status}. Open TikTok in this browser and try again.`);
  return response.text();
}

async function fetchJson(url) {
  const response = await fetch(url, {
    credentials: "include",
    headers: { "Accept": "application/json,text/plain,*/*" },
  });
  if (!response.ok) throw new Error(`TikTok returned HTTP ${response.status}.`);
  return response.json();
}

function parseJsonScript(html, id) {
  const match = html.match(new RegExp(`<script[^>]+id=["']${id}["'][^>]*>([\\s\\S]*?)<\\/script>`));
  if (!match) return null;
  try {
    const textarea = document.createElement("textarea");
    textarea.innerHTML = match[1];
    return JSON.parse(textarea.value);
  } catch (_) {
    return null;
  }
}

function findSecUid(html) {
  const sigi = parseJsonScript(html, "SIGI_STATE");
  const users = sigi?.UserModule?.users || sigi?.userModule?.users || {};
  for (const user of Object.values(users)) {
    if (user?.secUid) return user.secUid;
  }

  const universal = parseJsonScript(html, "__UNIVERSAL_DATA_FOR_REHYDRATION__");
  const user = universal?.__DEFAULT_SCOPE__?.["webapp.user-detail"]?.userInfo?.user;
  if (user?.secUid) return user.secUid;

  const next = parseJsonScript(html, "__NEXT_DATA__");
  const nextSecUid = next?.props?.pageProps?.userInfo?.user?.secUid;
  if (nextSecUid) return nextSecUid;

  const match = html.match(/"secUid"\s*:\s*"([^"]{20,})"/);
  return match ? match[1] : "";
}

function first(...values) {
  return values.find((value) => value !== undefined && value !== null && value !== "") || "";
}

function normalizeItem(item) {
  const stats = item.stats || item.statsV2 || {};
  const author = item.author || {};
  const video = item.video || {};
  const imagePost = item.imagePost || {};
  const contentDescription = Array.isArray(item.contents)
    ? item.contents.map((content) => content?.desc || content?.description).find(Boolean)
    : "";
  const description = first(item.desc, item.description, contentDescription);
  const covers = [
    video.cover,
    video.originCover,
    video.dynamicCover,
    imagePost?.cover?.imageURL?.urlList?.[0],
    item?.contents?.[0]?.textExtra?.[0]?.thumbnail,
  ];
  const mediaUrl = extractMediaUrlFromItem(item) || first(
    video.playAddr,
    video.downloadAddr,
    video.bitRate?.[0]?.playAddr?.[0],
    video.bitRate?.[0]?.PlayAddr?.UrlList?.[0]
  );
  const id = item.id || item.aweme_id || "";
  const handle = author.uniqueId || author.unique_id || "";

  return {
    id,
    uploader: handle,
    title: description || "Untitled",
    description,
    upload_date: item.createTime ? fmtDate(item.createTime).replace(/-/g, "") : "",
    timestamp: item.createTime || null,
    duration: video.duration ? Number(video.duration) : null,
    view_count: Number(stats.playCount || stats.play_count || 0),
    like_count: Number(stats.diggCount || stats.digg_count || 0),
    comment_count: Number(stats.commentCount || stats.comment_count || 0),
    repost_count: Number(stats.shareCount || stats.share_count || 0),
    thumbnail: first(...covers),
    mediaUrl,
    webpage_url: id && handle ? `https://www.tiktok.com/@${handle}/video/${id}` : "",
  };
}

async function getProfileSecUid(handle) {
  const html = await fetchText(`https://www.tiktok.com/@${encodeURIComponent(handle)}`);
  const secUid = findSecUid(html);
  if (!secUid) throw new Error("Could not find TikTok profile data. Open the profile in this browser, refresh, and try again.");
  return secUid;
}

async function fetchProfileVideosFromApi(handle, maxVideos, onProgress, signal) {
  const secUid = await getProfileSecUid(handle);
  let cursor = 0;
  let hasMore = true;
  let page = 0;
  let videos = [];
  let completed = false;

  while (hasMore) {
    if (signal?.aborted) throw new Error("Fetch stopped.");
    page += 1;
    const params = new URLSearchParams({
      secUid,
      count: "30",
      cursor: String(cursor || 0),
      aid: "1988",
      app_language: "en",
    });
    const data = await fetchJson(`https://www.tiktok.com/api/post/item_list/?${params}`);
    const items = data.itemList || data.item_list || data.aweme_list || [];
    if (!Array.isArray(items) || !items.length) {
      completed = true;
      break;
    }

    videos = mergeVideos([
      ...videos,
      ...items.map((item) => {
        const video = normalizeItem(item);
        return { ...video, uploader: video.uploader || handle };
      }),
    ]);
    onProgress(videos.length, "Reading full TikTok descriptions", videos);

    hasMore = Boolean(data.hasMore ?? data.has_more) && items.length > 0;
    cursor = data.nextCursor || data.next_cursor || data.cursor || 0;
    if (maxVideos && videos.length >= maxVideos) {
      completed = true;
      break;
    }
    if (!hasMore) {
      completed = true;
      break;
    }
    if (page >= 200) {
      completed = true;
      break;
    }
    await sleep(500);
  }

  return {
    videos: maxVideos ? videos.slice(0, maxVideos) : videos,
    completed,
  };
}

async function fetchProfileVideos(profile, options = {}) {
  const handle = profile.handle;
  const maxVideos = Number(options.maxVideos || 0);
  const scanDelay = Number(options.scanDelay || 2200);
  const stopDateFrom = options.stopDateFrom || "";
  const stopDateTo = options.stopDateTo || "";
  const onProgress = options.onProgress || (() => {});
  const tab = profile.tab;
  let apiVideos = [];

  if (options.preferApi) {
    try {
      onProgress(0, "Reading full TikTok descriptions...");
      const apiResult = await fetchProfileVideosFromApi(handle, maxVideos, onProgress, options.signal);
      apiVideos = apiResult.videos;
      if (maxVideos && apiResult.completed && apiVideos.length) return apiVideos;
      if (apiVideos.length) onProgress(apiVideos.length, "Full descriptions partially read, continuing visible profile scan", apiVideos);
    } catch (error) {
      onProgress(0, `TikTok description API was blocked, using visible profile scan instead`);
    }
  }

  onProgress(0, "Reading the open TikTok profile tab...");
  const captured = await acquireCapturedVideos(tab.id, maxVideos, scanDelay, onProgress, options.signal, stopDateFrom, stopDateTo);
  if (options.signal?.aborted) throw new Error("Fetch stopped.");
  if (captured.length || apiVideos.length) {
    const capturedOnly = mergeVideos([...apiVideos, ...captured]);
    return maxVideos ? capturedOnly.slice(0, maxVideos) : capturedOnly;
  }
  const domVideos = await scrapeVisibleTikTokTab(tab.id, maxVideos, scanDelay, stopDateFrom, stopDateTo, onProgress, options.signal);
  if (options.signal?.aborted) throw new Error("Fetch stopped.");
  const videos = mergeVideos([...apiVideos, ...domVideos, ...captured]);
  if (!videos.length) {
    throw new Error("No videos found on the visible TikTok profile. Scroll the profile until videos are visible, then click Fetch Videos again.");
  }
  return maxVideos ? videos.slice(0, maxVideos) : videos;
}

async function bgMessage(message) {
  return chrome.runtime.sendMessage(message);
}

async function startBackgroundFetch(profile, options = {}) {
  await bgMessage({
    type: "TIKGRAB_BG_START_FETCH",
    tabId: profile.tab.id,
    scanDelay: options.scanDelay || 2200,
    dateFrom: options.stopDateFrom || "",
    dateTo: options.stopDateTo || "",
  });
}

async function stopBackgroundFetch() {
  await bgMessage({ type: "TIKGRAB_BG_STOP_FETCH" });
}

async function getBackgroundJob() {
  const response = await bgMessage({ type: "TIKGRAB_BG_GET_JOB" });
  return response?.job || { running: false, videos: [] };
}

async function getBackgroundDownloadJob() {
  const response = await bgMessage({ type: "TIKGRAB_BG_GET_DOWNLOAD_JOB" });
  return response?.job || { running: false };
}

function startDownloadJobPolling() {
  const poll = setInterval(async () => {
    const job = await getBackgroundDownloadJob();
    if (job.error) {
      showAlert("bulk-alert", job.error, "error");
      clearInterval(poll);
      return;
    }
    if (job.message) showAlert("bulk-alert", job.message, job.running ? "warning" : "success");
    if (!job.running) clearInterval(poll);
  }, 1000);
}

function startJobPolling() {
  if (jobPollId) clearInterval(jobPollId);
  jobPollId = setInterval(async () => {
    const job = await getBackgroundJob();
    const count = job.videos?.length || job.progressCount || 0;
    setProgress("bulk-progress-bar", "bulk-progress-text", job.running ? 45 : 100, job.running ? `Acquiring ${count} videos` : `Done - ${count} videos`);
    if (!job.running) {
      clearInterval(jobPollId);
      jobPollId = null;
      if (job.error) {
        showAlert("bulk-alert", job.error, "error");
        $("bulk-progress-wrap").classList.remove("visible");
      } else {
        await renderFilteredResultsFromRaw(job.videos || []);
      }
      $("btn-bulk-fetch").disabled = false;
      $("btn-stop-fetch").disabled = true;
      $("btn-bulk-fetch").textContent = "Fetch Videos";
    }
  }, 1200);
}

async function updateSearchResultsFromJob(job, words, matchAll, final = false) {
  const videos = job.videos || [];
  searchVideos = filterSearchVideos(videos, words, matchAll);
  renderSearchResults(
    searchVideos,
    final
      ? `No descriptions contain "${words.join(", ")}" in the ${videos.length} video${videos.length === 1 ? "" : "s"} scanned.`
      : `Still scanning. No matches for "${words.join(", ")}" in the ${videos.length} video${videos.length === 1 ? "" : "s"} checked so far.`,
    words
  );
  await saveState();
  showAlert(
    "search-alert",
    final
      ? `Scan complete. Scanned ${videos.length} video(s). Found ${searchVideos.length} matching video(s).`
      : `Scanning in background (${videos.length} video${videos.length === 1 ? "" : "s"} found so far, ${searchVideos.length} match${searchVideos.length === 1 ? "" : "es"}). You can switch tabs.`,
    final ? (searchVideos.length ? "success" : "warning") : "warning"
  );
}

function startSearchJobPolling(words, matchAll) {
  if (searchPollId) clearInterval(searchPollId);
  const btn = $("btn-search-descriptions");
  const stopBtn = $("btn-stop-search");
  btn.disabled = true;
  btn.textContent = "Searching...";
  if (stopBtn) stopBtn.disabled = false;

  searchPollId = setInterval(async () => {
    const job = await getBackgroundJob();
    await updateSearchResultsFromJob(job, words, matchAll, !job.running);
    if (!job.running) {
      clearInterval(searchPollId);
      searchPollId = null;
      btn.disabled = false;
      btn.textContent = "Search Descriptions";
      if (stopBtn) stopBtn.disabled = true;
    }
  }, 1200);
}

function mergeVideos(videos) {
  const merged = new Map();
  for (const video of videos) {
    const key = video.id || video.webpage_url;
    if (!key) continue;
    const previous = merged.get(key) || {};
    merged.set(key, {
      ...previous,
      ...video,
      title: video.title || previous.title,
      description: video.description || previous.description,
      upload_date: video.upload_date || previous.upload_date,
      duration: video.duration || previous.duration,
      thumbnail: video.thumbnail || previous.thumbnail,
      mediaUrl: video.mediaUrl || previous.mediaUrl,
      webpage_url: video.webpage_url || previous.webpage_url,
    });
  }
  return [...merged.values()];
}

async function acquireCapturedVideos(tabId, maxVideos, scanDelay, onProgress, signal, stopDateFrom, stopDateTo) {
  capturedVideos = new Map();
  let acquireDone = false;
  let lastProgressCount = 0;

  const listener = (message, sender) => {
    if (sender.tab?.id !== tabId) return;
    if (message?.type === "TIKGRAB_CAPTURED_ITEMS") {
      for (const video of message.videos || []) {
        const key = video.id || video.webpage_url;
        if (!key) continue;
        capturedVideos.set(key, mergeVideos([capturedVideos.get(key), video])[0]);
      }
      lastProgressCount = Math.max(lastProgressCount, capturedVideos.size);
      onProgress(capturedVideos.size, `Acquired ${capturedVideos.size} videos`);
    }
    if (message?.type === "TIKGRAB_ACQUIRE_PROGRESS") {
      lastProgressCount = Math.max(lastProgressCount, message.count || 0, capturedVideos.size);
      onProgress(lastProgressCount, `Acquiring ${lastProgressCount} videos`);
    }
    if (message?.type === "TIKGRAB_ACQUIRE_DONE" || message?.type === "TIKGRAB_ACQUIRE_STOPPED") {
      acquireDone = true;
      lastProgressCount = Math.max(lastProgressCount, capturedVideos.size);
      onProgress(lastProgressCount, message.type === "TIKGRAB_ACQUIRE_STOPPED" ? "Search stopped" : "Finished acquiring videos");
    }
  };

  chrome.runtime.onMessage.addListener(listener);
  try {
    try {
      await chrome.tabs.sendMessage(tabId, {
        type: "TIKGRAB_START_ACQUIRE",
        maxRounds: 300,
        delayMs: scanDelay,
        dateFrom: stopDateFrom,
        dateTo: stopDateTo,
      });
    } catch (_) {
      return [];
    }

    const timeoutMs = maxVideos ? Math.max(30000, maxVideos * 250) : 240000;
    const started = Date.now();
    let lastCount = -1;
    let stableRounds = 0;
    while (Date.now() - started < timeoutMs) {
      if (signal?.aborted) {
        chrome.tabs.sendMessage(tabId, { type: "TIKGRAB_STOP_ACQUIRE" }).catch(() => {});
        break;
      }
      await sleep(1000);
      if (acquireDone) break;
      if (maxVideos && capturedVideos.size >= maxVideos) break;
      const currentCount = Math.max(capturedVideos.size, lastProgressCount);
      if (currentCount === lastCount) stableRounds += 1;
      else stableRounds = 0;
      lastCount = currentCount;
      if (stableRounds >= 20 && currentCount > 0) break;
    }
    chrome.tabs.sendMessage(tabId, { type: "TIKGRAB_STOP_ACQUIRE" }).catch(() => {});
    onProgress(Math.max(capturedVideos.size, lastProgressCount), "Finished search scan");
    return [...capturedVideos.values()];
  } finally {
    chrome.runtime.onMessage.removeListener(listener);
  }
}

async function scrapeVisibleTikTokTab(tabId, maxVideos, scanDelay, stopDateFrom, stopDateTo, onProgress, signal) {
  if (signal?.aborted) return [];
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (limit, delayMs, dateFrom, dateTo) => {
      const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
      const getHandle = () => location.pathname.split("/").find((part) => part.startsWith("@"))?.slice(1) || "";
      const text = (node) => (node?.textContent || "").trim();
      const toNumber = (value) => {
        const raw = String(value || "").trim().toLowerCase();
        const num = parseFloat(raw.replace(/[^0-9.]/g, ""));
        if (Number.isNaN(num)) return null;
        if (raw.includes("m")) return Math.round(num * 1_000_000);
        if (raw.includes("k")) return Math.round(num * 1_000);
        return Math.round(num);
      };
      const durationToSeconds = (value) => {
        const raw = String(value || "").trim();
        const match = raw.match(/\b(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\b|\b(\d{1,2}):(\d{2})\b/);
        if (!match) return null;
        if (match[4] !== undefined) return Number(match[4]) * 60 + Number(match[5]);
        return (Number(match[1] || 0) * 3600) + (Number(match[2]) * 60) + Number(match[3]);
      };
      const isMediaUrl = (url) => {
        if (!/^https?:\/\//i.test(url || "")) return false;
        try {
          const parsed = new URL(url);
          if (parsed.hostname.includes("tiktok.com") && /\/@[^/]+\/video\//.test(parsed.pathname)) return false;
          return /tiktokcdn|byteoversea|ibytedtos|bytefcdn|\.mp4|mime_type=video|video_mp4/i.test(url);
        } catch (_) {
          return false;
        }
      };
      const cleanUrl = (value) => String(value || "")
        .replace(/\\u002F/g, "/")
        .replace(/\\\//g, "/")
        .replace(/\\u0026/g, "&")
        .replace(/&amp;/g, "&");
      const findMediaUrlInText = (html) => {
        const patterns = [
          /"playAddr"\s*:\s*"([^"]+)"/i,
          /"downloadAddr"\s*:\s*"([^"]+)"/i,
          /"play_addr"\s*:\s*\{[^}]*"url_list"\s*:\s*\[\s*"([^"]+)"/i,
          /"PlayAddr"\s*:\s*\{[^}]*"UrlList"\s*:\s*\[\s*"([^"]+)"/i,
          /<video[^>]+src=["']([^"']+)["']/i,
        ];
        for (const pattern of patterns) {
          const url = cleanUrl(html.match(pattern)?.[1] || "");
          if (isMediaUrl(url)) return url;
        }
        return "";
      };
      const findCardDuration = (card) => {
        const selectors = [
          '[data-e2e*="duration"]',
          '[class*="duration" i]',
          '[class*="time" i]',
          'span',
          'div',
        ];
        for (const selector of selectors) {
          for (const node of card.querySelectorAll(selector)) {
            const value = durationToSeconds(text(node));
            if (value) return value;
          }
        }
        return durationToSeconds(text(card));
      };
      const dateFromId = (id) => {
        try {
          const timestamp = Number(BigInt(String(id)) >> 32n);
          if (!timestamp) return "";
          return new Date(timestamp * 1000).toISOString().slice(0, 10).replace(/-/g, "");
        } catch (_) {
          return "";
        }
      };
      const first = (...values) => values.find((value) => value !== undefined && value !== null && value !== "") || "";
      const parseJsonScript = (html, id) => {
        const match = html.match(new RegExp(`<script[^>]+id=["']${id}["'][^>]*>([\\s\\S]*?)<\\/script>`));
        if (!match) return null;
        try {
          const textarea = document.createElement("textarea");
          textarea.innerHTML = match[1];
          return JSON.parse(textarea.value);
        } catch (_) {
          return null;
        }
      };
      const normalizeDetailItem = (item, fallback) => {
        if (!item) return fallback;
        const stats = item.stats || item.statsV2 || {};
        const author = item.author || {};
        const video = item.video || {};
        const handle = author.uniqueId || author.unique_id || fallback.uploader || getHandle();
        const id = item.id || item.aweme_id || fallback.id || "";
        const created = item.createTime || item.create_time || fallback.timestamp;
        const duration = video.duration ? Number(video.duration) : fallback.duration;
        const mediaUrl = first(
          video.playAddr,
          video.downloadAddr,
          video.bitRate?.[0]?.playAddr?.[0],
          video.bitRate?.[0]?.PlayAddr?.UrlList?.[0],
          fallback.mediaUrl
        );
        const thumbnail = first(video.cover, video.originCover, video.dynamicCover, fallback.thumbnail);
        const desc = first(item.desc, item.description, fallback.description, fallback.title);
        return {
          ...fallback,
          id,
          uploader: handle,
          title: desc || fallback.title,
          description: desc || fallback.description,
          upload_date: created ? new Date(Number(created) * 1000).toISOString().slice(0, 10).replace(/-/g, "") : (fallback.upload_date || ""),
          timestamp: created || fallback.timestamp,
          duration: duration && duration > 1000 ? Math.round(duration / 1000) : duration,
          view_count: Number(stats.playCount || stats.play_count || fallback.view_count || 0) || fallback.view_count,
          like_count: Number(stats.diggCount || stats.digg_count || fallback.like_count || 0) || fallback.like_count,
          comment_count: Number(stats.commentCount || stats.comment_count || fallback.comment_count || 0) || fallback.comment_count,
          repost_count: Number(stats.shareCount || stats.share_count || fallback.repost_count || 0) || fallback.repost_count,
          thumbnail,
          mediaUrl,
          webpage_url: fallback.webpage_url || (id && handle ? `https://www.tiktok.com/@${handle}/video/${id}` : ""),
        };
      };
      const parseVideoDetail = (html, fallback) => {
        const sigi = parseJsonScript(html, "SIGI_STATE");
        const itemModule = sigi?.ItemModule || sigi?.itemModule || {};
        const sigiItem = Object.values(itemModule)[0];
        if (sigiItem) return normalizeDetailItem(sigiItem, fallback);

        const universal = parseJsonScript(html, "__UNIVERSAL_DATA_FOR_REHYDRATION__");
        const universalItem = universal?.__DEFAULT_SCOPE__?.["webapp.video-detail"]?.itemInfo?.itemStruct;
        if (universalItem) return normalizeDetailItem(universalItem, fallback);

        const next = parseJsonScript(html, "__NEXT_DATA__");
        const nextItem = next?.props?.pageProps?.itemInfo?.itemStruct;
        if (nextItem) return normalizeDetailItem(nextItem, fallback);

        return normalizeDetailFromText(html, fallback);
      };
      const normalizeDuration = (value) => {
        const duration = Number(value);
        if (!duration || Number.isNaN(duration)) return null;
        return duration > 1000 ? Math.round(duration / 1000) : Math.round(duration);
      };
      const textNumber = (html, patterns) => {
        for (const pattern of patterns) {
          const match = html.match(pattern);
          if (match?.[1] !== undefined) return Number(match[1]);
        }
        return null;
      };
      const textString = (html, patterns) => {
        for (const pattern of patterns) {
          const match = html.match(pattern);
          if (match?.[1]) {
            try {
              return JSON.parse(`"${match[1].replace(/"/g, '\\"')}"`);
            } catch (_) {
              return match[1];
            }
          }
        }
        return "";
      };
      const normalizeDetailFromText = (html, fallback) => {
        const duration = normalizeDuration(textNumber(html, [
          /"duration"\s*:\s*"?(\d{1,8})"?/i,
          /"Duration"\s*:\s*"?(\d{1,8})"?/i,
          /"videoDuration"\s*:\s*"?(\d{1,8})"?/i,
          /"lengthSeconds"\s*:\s*"?(\d{1,8})"?/i,
        ]));
        const created = textNumber(html, [
          /"createTime"\s*:\s*"?(\d{10})"?/i,
          /"create_time"\s*:\s*"?(\d{10})"?/i,
          /"datePublished"\s*:\s*"(\d{4})-/i,
        ]);
        const desc = textString(html, [
          /"desc"\s*:\s*"([^"]{1,1000})"/i,
          /"description"\s*:\s*"([^"]{1,1000})"/i,
          /<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i,
        ]);
        return {
          ...fallback,
          title: desc || fallback.title,
          description: desc || fallback.description,
          duration: duration || fallback.duration,
          upload_date: created && created > 1_000_000_000
            ? new Date(created * 1000).toISOString().slice(0, 10).replace(/-/g, "")
            : fallback.upload_date,
          timestamp: created && created > 1_000_000_000 ? created : fallback.timestamp,
          view_count: textNumber(html, [/"playCount"\s*:\s*"?(\d+)"?/i, /"play_count"\s*:\s*"?(\d+)"?/i]) || fallback.view_count,
          like_count: textNumber(html, [/"diggCount"\s*:\s*"?(\d+)"?/i, /"digg_count"\s*:\s*"?(\d+)"?/i]) || fallback.like_count,
          comment_count: textNumber(html, [/"commentCount"\s*:\s*"?(\d+)"?/i, /"comment_count"\s*:\s*"?(\d+)"?/i]) || fallback.comment_count,
          repost_count: textNumber(html, [/"shareCount"\s*:\s*"?(\d+)"?/i, /"share_count"\s*:\s*"?(\d+)"?/i]) || fallback.repost_count,
          mediaUrl: findMediaUrlInText(html) || fallback.mediaUrl,
        };
      };
      const fetchItemDetail = async (video) => {
        if (!video.id) return video;
        try {
          const params = new URLSearchParams({
            itemId: video.id,
            aid: "1988",
            app_language: "en",
          });
          const response = await fetch(`https://www.tiktok.com/api/item/detail/?${params}`, {
            credentials: "include",
            headers: { "Accept": "application/json,text/plain,*/*" },
          });
          if (!response.ok) return video;
          const data = await response.json();
          return normalizeDetailItem(data?.itemInfo?.itemStruct || data?.itemStruct || data?.item, video);
        } catch (_) {
          return video;
        }
      };
      const enrichVideo = async (video) => {
        const withDate = {
          ...video,
          upload_date: video.upload_date || (video.id ? (() => {
            try {
              const timestamp = Number(BigInt(String(video.id)) >> 32n);
              return timestamp ? new Date(timestamp * 1000).toISOString().slice(0, 10).replace(/-/g, "") : "";
            } catch (_) {
              return "";
            }
          })() : ""),
        };
        const apiDetail = await fetchItemDetail(withDate);
        if (apiDetail.duration || apiDetail.like_count || apiDetail.comment_count) return apiDetail;

        if (!withDate.webpage_url) return apiDetail;
        try {
          const response = await fetch(withDate.webpage_url, {
            credentials: "include",
            headers: { "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" },
          });
          if (!response.ok) return apiDetail;
          return parseVideoDetail(await response.text(), apiDetail);
        } catch (_) {
          return apiDetail;
        }
      };
      const enrichVideos = async (videos) => {
        const enriched = [];
        let index = 0;
        const workers = Array.from({ length: 4 }, async () => {
          while (index < videos.length) {
            const current = index;
            index += 1;
            enriched[current] = await enrichVideo(videos[current]);
            await sleep(80);
          }
        });
        await Promise.all(workers);
        return enriched;
      };
      const normalize = (anchor) => {
        const href = anchor.href || "";
        const id = href.match(/\/video\/(\d+)/)?.[1] || "";
        const handle = getHandle();
        const card = anchor.closest('[data-e2e*="user-post"], [class*="DivWrapper"], [class*="video-feed"], div') || anchor;
        const img = card.querySelector("img") || anchor.querySelector("img");
        const videoNode = card.querySelector("video") || anchor.querySelector("video");
        const descNode = card.querySelector('[data-e2e="user-post-item-desc"], [data-e2e*="desc"], h1, h2, p, span');
        const viewsNode = card.querySelector('[data-e2e="video-views"], strong, span');
        const cardDuration = findCardDuration(card);
        const title = img?.alt || text(descNode) || anchor.getAttribute("aria-label") || "TikTok video";
        return {
          id,
          uploader: handle,
          title,
          description: title,
          upload_date: id ? dateFromId(id) : "",
          timestamp: null,
          duration: cardDuration,
          view_count: toNumber(text(viewsNode)),
          like_count: null,
          comment_count: null,
          repost_count: null,
          thumbnail: img?.currentSrc || img?.src || "",
          mediaUrl: isMediaUrl(videoNode?.currentSrc || videoNode?.src || "") ? (videoNode.currentSrc || videoNode.src) : "",
          webpage_url: href,
        };
      };
      const videoMap = new Map();
      const collect = () => {
        document.querySelectorAll('a[href*="/video/"]').forEach((anchor) => {
          if (!anchor.href || videoMap.has(anchor.href)) return;
          videoMap.set(anchor.href, normalize(anchor));
        });
        return [...videoMap.values()];
      };

      const waitForNewItems = async (previousCount) => {
        for (let wait = 0; wait < 8; wait += 1) {
          await sleep(Math.max(300, Math.floor(delayMs / 4)));
          const count = collect().length;
          if (count > previousCount) return count;
        }
        return collect().length;
      };
      const hasPassedDateRange = (videos) => {
        if (!dateFrom || !videos.length) return false;
        const dated = videos.map((video) => video.upload_date).filter(Boolean).sort();
        if (!dated.length) return false;
        const oldestSeen = dated[0];
        return oldestSeen < dateFrom;
      };

      let videos = [];
      let stable = 0;
      let lastTop = -1;
      const scroller = document.scrollingElement || document.documentElement || document.body;
      scroller.scrollTop = 0;
      window.scrollTo(0, 0);
      await sleep(delayMs);
      for (let i = 0; i < 260; i += 1) {
        const before = videos.length;
        videos = collect();
        if (limit && videos.length >= limit) return enrichVideos(videos.slice(0, limit));
        if (hasPassedDateRange(videos)) break;
        if (videos.length === before && scroller.scrollTop === lastTop) stable += 1;
        else stable = 0;
        if (stable >= 18 && videos.length > 0) break;
        lastTop = scroller.scrollTop;
        const step = Math.max(Math.floor(window.innerHeight * 0.65), 420);
        scroller.scrollTop = Math.min(scroller.scrollTop + step, scroller.scrollHeight);
        window.dispatchEvent(new Event("scroll"));
        await waitForNewItems(before);
        videos = collect();
        if (limit && videos.length >= limit) return enrichVideos(videos.slice(0, limit));
        if (hasPassedDateRange(videos)) break;
        window.scrollBy(0, Math.max(Math.floor(window.innerHeight * 0.25), 180));
        window.dispatchEvent(new Event("scroll"));
        await sleep(delayMs);
      }
      return enrichVideos(limit ? videos.slice(0, limit) : videos);
    },
    args: [maxVideos, scanDelay, stopDateFrom, stopDateTo],
  });

  onProgress(result?.length || 0, `Fetched ${result?.length || 0} videos`);
  return result || [];
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function withTimeout(promise, ms, message) {
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      setTimeout(() => reject(new Error(message)), ms);
    }),
  ]);
}

function waitForTabComplete(tabId) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("TikTok profile took too long to load."));
    }, 30000);

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }

    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function sendProfileFetchMessage(tabId, maxVideos) {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    try {
      return await chrome.tabs.sendMessage(tabId, {
        type: "TIKGRAB_FETCH_PROFILE",
        maxVideos,
      });
    } catch (_) {
      await sleep(500);
    }
  }
  throw new Error("Could not connect to the TikTok profile page. Refresh TikTok, make sure you are logged in, and try again.");
}

function applyFilters(videos) {
  const dateFrom = ($("filter-date-from").value || "").replace(/-/g, "");
  const dateToValue = ($("filter-date-to").value || "").replace(/-/g, "");
  const dateTo = dateFrom && !dateToValue ? dateFrom : dateToValue;
  const minDur = 0;
  const maxDur = 0;
  const keywords = [];

  return videos.filter((video) => {
    const uploadDate = video.upload_date || "";
    const duration = Number(video.duration || 0);
    const text = `${video.title || ""} ${video.description || ""}`.toLowerCase();
    if (dateFrom && uploadDate && uploadDate < dateFrom) return false;
    if (dateTo && uploadDate && uploadDate > dateTo) return false;
    if (!Number.isNaN(minDur) && duration < minDur) return false;
    if (!Number.isNaN(maxDur) && duration > maxDur) return false;
    if (keywords.length && !keywords.every((word) => text.includes(word))) return false;
    return true;
  });
}

async function renderFilteredResultsFromRaw(videos) {
  rawVideos = Array.isArray(videos) ? videos : [];
  currentVideos = applyFilters(rawVideos);
  renderBulkResults(currentVideos);
  await saveState();
  if (rawVideos.length && !currentVideos.length) {
    showAlert("bulk-alert", `Fetched ${rawVideos.length} videos, but 0 match the current filters. Clear or adjust filters.`, "warning");
  } else if (rawVideos.length) {
    hideAlert("bulk-alert");
  }
}

async function clearBulkFilters() {
  ["filter-date-from", "filter-date-to", "bulk-max"].forEach((id) => {
    if ($(id)) $(id).value = "";
  });
  if (rawVideos.length) await renderFilteredResultsFromRaw(rawVideos);
  else await saveState();
}

async function fetchVideoInfo(url) {
  const html = await fetchText(url);
  const sigi = parseJsonScript(html, "SIGI_STATE");
  const itemModule = sigi?.ItemModule || sigi?.itemModule || {};
  const firstItem = Object.values(itemModule)[0];
  if (firstItem) return normalizeItem(firstItem);

  const universal = parseJsonScript(html, "__UNIVERSAL_DATA_FOR_REHYDRATION__");
  const item = universal?.__DEFAULT_SCOPE__?.["webapp.video-detail"]?.itemInfo?.itemStruct;
  if (item) return normalizeItem(item);

  const next = parseJsonScript(html, "__NEXT_DATA__");
  const nextItem = next?.props?.pageProps?.itemInfo?.itemStruct;
  if (nextItem) return normalizeItem(nextItem);

  throw new Error("Could not read video info from this TikTok page.");
}

function renderSinglePreview(info, url) {
  $("preview-thumb").src = info.thumbnail || "";
  $("preview-title").textContent = info.title || "Untitled";
  $("stat-user").textContent = `User ${info.uploader || "-"}`;
  $("stat-duration").textContent = `Time ${fmtDur(info.duration)}`;
  $("stat-views").textContent = `Views ${fmtNum(info.view_count)}`;
  $("stat-likes").textContent = `Likes ${fmtNum(info.like_count)}`;
  $("stat-date").textContent = `Date ${fmtDate(info.upload_date)}`;
  $("single-preview").classList.add("visible");
  $("btn-download-single").disabled = !info.mediaUrl;
  $("btn-download-single").dataset.url = info.mediaUrl || "";
  $("btn-download-single").dataset.filename = `tiktok_${info.id || Date.now()}.mp4`;
  if (!info.mediaUrl) showAlert("single-alert", "Preview loaded, but TikTok did not expose a downloadable media URL.", "warning");
}

async function fetchSingleInfo() {
  try {
    const url = normalizeVideoUrl($("single-url").value);
    const btn = $("btn-fetch-info");
    hideAlert("single-alert");
    btn.disabled = true;
    btn.textContent = "Fetching...";
    const info = await fetchVideoInfo(url);
    renderSinglePreview(info, url);
    showAlert("single-alert", "Info loaded.", "success");
  } catch (error) {
    showAlert("single-alert", error.message);
  } finally {
    $("btn-fetch-info").disabled = false;
    $("btn-fetch-info").textContent = "Fetch Info";
  }
}

async function verifyDownloadableVideoUrl(url) {
  if (!isDownloadableMediaUrl(url)) throw new Error("Resolved URL is not a video file.");
  const checkType = (type) => {
    if (isImageContentType(type)) throw new Error("TikTok returned an image instead of a video file.");
    if (type && !isVideoContentType(type)) throw new Error(`TikTok returned ${type} instead of a video file.`);
    return Boolean(type);
  };
  try {
    const response = await fetch(url, {
      method: "HEAD",
      credentials: "include",
      headers: { "Accept": "video/mp4,video/*,*/*" },
    });
    if (checkType(response.headers.get("Content-Type") || "")) return;
  } catch (error) {
    if (/image instead|instead of a video/i.test(error.message)) throw error;
  }

  try {
    const response = await fetch(url, {
      credentials: "include",
      headers: { "Accept": "video/mp4,video/*,*/*", "Range": "bytes=0-0" },
    });
    checkType(response.headers.get("Content-Type") || "");
  } catch (error) {
    if (/image instead|instead of a video/i.test(error.message)) throw error;
  }
}

function waitForDownloadComplete(downloadId) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.downloads.onChanged.removeListener(listener);
      reject(new Error("Download took too long to finish. Check Chrome downloads."));
    }, 10 * 60 * 1000);

    function listener(delta) {
      if (delta.id !== downloadId || !delta.state?.current) return;
      if (delta.state.current === "complete") {
        clearTimeout(timeout);
        chrome.downloads.onChanged.removeListener(listener);
        resolve();
      }
      if (delta.state.current === "interrupted") {
        clearTimeout(timeout);
        chrome.downloads.onChanged.removeListener(listener);
        reject(new Error("Chrome interrupted the download."));
      }
    }

    chrome.downloads.onChanged.addListener(listener);
  });
}

function chromeDownloadBlob(blob, filename) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({ url, filename, saveAs: false, conflictAction: "uniquify" }, (downloadId) => {
      const error = chrome.runtime.lastError;
      if (error) {
        URL.revokeObjectURL(url);
        reject(new Error(error.message));
      } else {
        waitForDownloadComplete(downloadId)
          .then(() => resolve(downloadId))
          .catch(reject)
          .finally(() => URL.revokeObjectURL(url));
      }
    });
  });
}

async function fetchVideoBlob(url) {
  await verifyDownloadableVideoUrl(url);
  const response = await fetch(url, {
    credentials: "include",
    headers: { "Accept": "video/mp4,video/*,*/*" },
  });
  if (!response.ok) throw new Error(`TikTok returned HTTP ${response.status}.`);
  const type = response.headers.get("Content-Type") || "";
  if (isDefinitelyNotVideoContentType(type)) throw new Error(`TikTok returned ${type || "a non-video response"} instead of a video.`);
  const blob = await response.blob();
  if (!blob.size) throw new Error("TikTok returned an empty video file.");
  if (isDefinitelyNotVideoContentType(blob.type)) throw new Error(`TikTok returned ${blob.type} instead of a video.`);
  return new Blob([blob], { type: isVideoContentType(blob.type) ? blob.type : "video/mp4" });
}

async function fetchVideoBlobViaVideoTab(video, mediaUrl) {
  if (!video?.webpage_url) throw new Error("TikTok returned JSON and no video page fallback is available.");
  let tab;
  try {
    tab = await chrome.tabs.create({ url: video.webpage_url, active: true });
    await waitForTabComplete(tab.id).catch(() => {});
    await sleep(3500);
    const token = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const chunks = [];
    let mimeType = "video/mp4";
    const transferPromise = new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        chrome.runtime.onMessage.removeListener(listener);
        reject(new Error("TikTok page fallback timed out while transferring video bytes."));
      }, 30000);

      function listener(message, sender) {
        if (sender.tab?.id !== tab.id || message?.token !== token) return;
        if (message.type === "TIKGRAB_VIDEO_BYTES_CHUNK") {
          chunks[message.index] = new Uint8Array(message.bytes || []);
        }
        if (message.type === "TIKGRAB_VIDEO_BYTES_DONE") {
          clearTimeout(timeout);
          chrome.runtime.onMessage.removeListener(listener);
          mimeType = message.mimeType || mimeType;
          const size = chunks.reduce((sum, chunk) => sum + (chunk?.length || 0), 0);
          const bytes = new Uint8Array(size);
          let offset = 0;
          for (const chunk of chunks) {
            if (!chunk) continue;
            bytes.set(chunk, offset);
            offset += chunk.length;
          }
          resolve(bytes);
        }
        if (message.type === "TIKGRAB_VIDEO_BYTES_ERROR") {
          clearTimeout(timeout);
          chrome.runtime.onMessage.removeListener(listener);
          reject(new Error(message.error || "TikTok page fallback could not download the video."));
        }
      }

      chrome.runtime.onMessage.addListener(listener);
    });

    const [{ result }] = await withTimeout(
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: async (url, transferToken) => {
        const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
        const isBadType = (type) => /^(?:image|text)\//i.test(type || "") || /json|html|xml/i.test(type || "");
        const clean = (value) => String(value || "")
          .replace(/\\u002F/g, "/")
          .replace(/\\\//g, "/")
          .replace(/\\u0026/g, "&")
          .replace(/&amp;/g, "&");
        const isLikelyVideoUrl = (value) => {
          if (!/^https?:\/\//i.test(value || "")) return false;
          const fullUrl = decodeURIComponent(String(value)).toLowerCase();
          if (/\.(?:jpe?g|jfif|png|webp|gif|avif)(?:$|[?#])|mime_type=image|image\/|~tplv-/i.test(fullUrl)) return false;
          return /\.mp4(?:$|[?#])|mime_type=video|video_mp4|\/video\/|video\/tos|\/tos-[^/?#]+\/|tiktokcdn|tiktokv|muscdn|akamaized|byteoversea|ibytedtos|bytefcdn/i.test(fullUrl);
        };
        const looksLikeMp4Bytes = (bytes) => {
          if (!bytes || bytes.length < 12) return false;
          const text = (offset, length) => String.fromCharCode(...bytes.slice(offset, offset + length));
          if (text(4, 4) === "ftyp" || text(4, 4) === "styp") return true;
          const header = text(0, Math.min(bytes.length, 4096));
          return /ftyp|styp|moov|moof|mdat/.test(header);
        };
        const candidatesFromPage = () => {
          const candidates = [url];
          const video = document.querySelector("video");
          if (video) {
            video.muted = true;
            video.play().catch(() => {});
            candidates.push(video.currentSrc, video.src, video.getAttribute("src"));
          }
          document.querySelectorAll("source").forEach((source) => {
            candidates.push(source.currentSrc, source.src, source.getAttribute("src"));
          });
          performance.getEntriesByType("resource").forEach((entry) => {
            candidates.push(entry.name);
          });
          return [...new Set(candidates.map(clean).filter(isLikelyVideoUrl))];
        };
        const fetchCandidate = async (candidate) => {
          let timeout;
          try {
            const controller = new AbortController();
            timeout = setTimeout(() => controller.abort(), 12000);
            const response = await fetch(candidate, {
              credentials: "include",
              referrer: location.href,
              signal: controller.signal,
              headers: { "Accept": "video/mp4,video/*,*/*" },
            });
            if (!response.ok) return null;
            const type = response.headers.get("Content-Type") || "";
            if (isBadType(type)) return null;
            const blob = await response.blob();
            if (!blob.size || isBadType(blob.type)) return null;
            const bytes = new Uint8Array(await blob.arrayBuffer());
            const text = (offset, length) => String.fromCharCode(...bytes.slice(offset, offset + length));
            const header = text(0, Math.min(bytes.length, 128));
            if (text(4, 4) !== "ftyp" && !/ftyp|moov|mdat/.test(header)) return null;
            const chunkSize = 128 * 1024;
            for (let index = 0; index * chunkSize < bytes.length; index += 1) {
              const chunk = bytes.slice(index * chunkSize, Math.min(bytes.length, (index + 1) * chunkSize));
              await chrome.runtime.sendMessage({
                type: "TIKGRAB_VIDEO_BYTES_CHUNK",
                token: transferToken,
                index,
                bytes: Array.from(chunk),
              });
            }
            await chrome.runtime.sendMessage({
              type: "TIKGRAB_VIDEO_BYTES_DONE",
              token: transferToken,
              mimeType: blob.type || "video/mp4",
            });
            return { ok: true };
          } catch (_) {
          } finally {
            if (timeout) clearTimeout(timeout);
          }
          return null;
        };

        for (let round = 0; round < 8; round += 1) {
          for (const candidate of candidates) {
            const result = await fetchCandidate(candidate);
            if (result?.ok) return result;
          }
          window.scrollBy(0, 200);
          await sleep(1000);
        }
        await chrome.runtime.sendMessage({
          type: "TIKGRAB_VIDEO_BYTES_ERROR",
          token: transferToken,
          error: "TikTok page did not expose video bytes for ZIP. Use Download for this video.",
        });
        return { ok: false };
        },
        args: [mediaUrl, token],
      }),
      30000,
      "TikTok page ZIP fetch is blocked. Use Download for this video."
    );
    if (!result?.ok) throw new Error(result?.error || "TikTok page fallback could not download the video.");
    const bytes = await transferPromise;
    if (!bytes.length) throw new Error("TikTok page returned an empty video file.");
    if (!looksLikeMp4Bytes(bytes)) throw new Error("TikTok page returned bytes that are not a playable MP4 file.");
    return new Blob([bytes], { type: mimeType });
  } catch (error) {
    if (/message length|quota|exceeded|too large|out of memory/i.test(error.message || "")) {
      throw new Error("Video is too large to add to an in-browser ZIP. Use Download for this video.");
    }
    throw error;
  } finally {
    if (tab?.id) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

async function downloadViaVideoTab(video, mediaUrl, filename) {
  if (!video?.webpage_url) throw new Error("TikTok returned JSON and no video page fallback is available.");
  let tab;
  try {
    tab = await chrome.tabs.create({ url: video.webpage_url, active: false });
    await waitForTabComplete(tab.id).catch(() => {});
    await sleep(3500);
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async (url, suggestedName) => {
        const isBadType = (type) => /^(?:image|text)\//i.test(type || "") || /json|html|xml/i.test(type || "");
        const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
        const clean = (value) => String(value || "")
          .replace(/\\u002F/g, "/")
          .replace(/\\\//g, "/")
          .replace(/\\u0026/g, "&")
          .replace(/&amp;/g, "&");
        const isLikelyVideoUrl = (value) => {
          if (!/^https?:\/\//i.test(value || "")) return false;
          const fullUrl = decodeURIComponent(String(value)).toLowerCase();
          if (/\.(?:jpe?g|jfif|png|webp|gif|avif)(?:$|[?#])|mime_type=image|image\/|~tplv-/i.test(fullUrl)) return false;
          return /\.mp4(?:$|[?#])|mime_type=video|video_mp4|\/video\/|video\/tos|\/tos-[^/?#]+\/|tiktokcdn|tiktokv|muscdn|akamaized|byteoversea|ibytedtos|bytefcdn/i.test(fullUrl);
        };
        const fromValue = (value) => {
          if (!value) return [];
          if (typeof value === "string") return [clean(value)];
          if (Array.isArray(value)) return value.flatMap(fromValue);
          if (typeof value === "object") {
            return [
              value.url,
              value.uri,
              value.playAddr,
              value.downloadAddr,
              value.PlayAddr,
              value.DownloadAddr,
              value.urlList,
              value.UrlList,
              value.url_list,
            ].flatMap(fromValue);
          }
          return [];
        };
        const parseScriptJson = (id) => {
          const el = document.getElementById(id);
          if (!el) return null;
          try {
            const textarea = document.createElement("textarea");
            textarea.innerHTML = el.textContent || "";
            return JSON.parse(textarea.value);
          } catch (_) {
            return null;
          }
        };
        const mediaFromItem = (item) => {
          const video = item?.video || item?.Video || {};
          return [
            video.playAddr,
            video.downloadAddr,
            video.play_addr,
            video.download_addr,
            video.PlayAddr,
            video.DownloadAddr,
            video.bitRate,
            video.bitrateInfo,
          ].flatMap(fromValue);
        };
        const candidatesFromPage = () => {
          const candidates = [url];
          const video = document.querySelector("video");
          if (video) {
            video.muted = true;
            video.play().catch(() => {});
            candidates.push(video.currentSrc, video.src, video.getAttribute("src"));
          }
          document.querySelectorAll("source").forEach((source) => {
            candidates.push(source.currentSrc, source.src, source.getAttribute("src"));
          });
          performance.getEntriesByType("resource").forEach((entry) => {
            candidates.push(entry.name);
          });
          const sigi = parseScriptJson("SIGI_STATE");
          Object.values(sigi?.ItemModule || sigi?.itemModule || {}).forEach((item) => {
            candidates.push(...mediaFromItem(item));
          });
          const universal = parseScriptJson("__UNIVERSAL_DATA_FOR_REHYDRATION__");
          candidates.push(...mediaFromItem(universal?.__DEFAULT_SCOPE__?.["webapp.video-detail"]?.itemInfo?.itemStruct));
          const next = parseScriptJson("__NEXT_DATA__");
          candidates.push(...mediaFromItem(next?.props?.pageProps?.itemInfo?.itemStruct));
          return [...new Set(candidates.map(clean).filter(isLikelyVideoUrl))];
        };

        for (let round = 0; round < 12; round += 1) {
          for (const candidate of candidatesFromPage()) {
            try {
              const response = await fetch(candidate, {
                credentials: "include",
                referrer: location.href,
                headers: { "Accept": "video/mp4,video/*,*/*" },
              });
              if (!response.ok) continue;
              const type = response.headers.get("Content-Type") || "";
              if (isBadType(type)) continue;
              const blob = await response.blob();
              if (!blob.size || isBadType(blob.type)) continue;
              const blobUrl = URL.createObjectURL(new Blob([blob], { type: blob.type || "video/mp4" }));
              const a = document.createElement("a");
              a.href = blobUrl;
              a.download = suggestedName.split("/").pop() || "tiktok_video.mp4";
              document.body.appendChild(a);
              a.click();
              a.remove();
              setTimeout(() => URL.revokeObjectURL(blobUrl), 30000);
              return { ok: true };
            } catch (_) {}
          }
          window.scrollBy(0, 200);
          await sleep(1000);
        }
        return { ok: false, error: "TikTok page could not start the browser download." };
      },
      args: [mediaUrl, filename],
    });
    if (!result?.ok) throw new Error(result?.error || "TikTok page fallback could not download the video.");
  } finally {
    if (tab?.id) setTimeout(() => chrome.tabs.remove(tab.id).catch(() => {}), 5000);
  }
}

async function downloadUrl(url, filename, video = null) {
  try {
    const blob = await fetchVideoBlob(url);
    await chromeDownloadBlob(blob, filename);
  } catch (error) {
    if (/json|html|text\//i.test(error.message || "") && video?.webpage_url) {
      await downloadViaVideoTab(video, url, filename);
      return;
    }
    throw error;
  }
}

async function fetchVideoBlobWithFallback(url, video = null) {
  try {
    return await fetchVideoBlob(url);
  } catch (error) {
    if (/json|html|text\//i.test(error.message || "") && video?.webpage_url) {
      return fetchVideoBlobViaVideoTab(video, url);
    }
    throw error;
  }
}

function safeFilenamePart(value) {
  return String(value || "")
    .replace(/[\\/:*?"<>|]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 80);
}

function videoFilename(video, index) {
  const handle = safeFilenamePart(video.uploader || "tiktok");
  const title = safeFilenamePart(video.title || video.description || video.id || `video_${index + 1}`);
  return `TikGrab/${handle}_${video.id || index + 1}_${title || "video"}.mp4`;
}

function zipEntryName(video, index) {
  const name = videoFilename(video, index).replace(/^TikGrab\//, "");
  return /\.mp4$/i.test(name) ? name : `${name}.mp4`;
}

async function ensureMediaUrl(video) {
  if (isDownloadableMediaUrl(video.mediaUrl)) {
    try {
      await verifyDownloadableVideoUrl(video.mediaUrl);
      return video.mediaUrl;
    } catch (_) {
      video.mediaUrl = "";
    }
  }
  if (!video.webpage_url) return "";

  if (video.id) {
    try {
      const params = new URLSearchParams({
        itemId: video.id,
        aid: "1988",
        app_language: "en",
      });
      const data = await fetchJson(`https://www.tiktok.com/api/item/detail/?${params}`);
      const item = data?.itemInfo?.itemStruct || data?.itemStruct || data?.item;
      const apiMediaUrl = extractMediaUrlFromItem(item);
      if (isDownloadableMediaUrl(apiMediaUrl)) {
        video.mediaUrl = apiMediaUrl;
        await saveState();
        return apiMediaUrl;
      }
    } catch (_) {}
  }

  try {
    const response = await fetch(video.webpage_url, {
      credentials: "include",
      headers: { "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" },
    });
    const mediaUrl = response.ok ? extractMediaUrlFromHtml(await response.text()) : "";
    if (mediaUrl) {
      video.mediaUrl = mediaUrl;
      await saveState();
      return mediaUrl;
    }
  } catch (_) {}

  return resolveMediaUrlFromVideoTab(video);
}

async function resolveMediaUrlFromVideoTab(video) {
  if (!video.webpage_url) return "";
  let tab;
  try {
    tab = await chrome.tabs.create({ url: video.webpage_url, active: false });
    await waitForTabComplete(tab.id).catch(() => {});
    await sleep(3500);
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
        const isMedia = (url) => {
          if (!/^https?:\/\//i.test(url || "")) return false;
          const fullUrl = decodeURIComponent(String(url)).toLowerCase();
          const host = new URL(url).hostname.toLowerCase();
          if (/\.(?:jpe?g|jfif|png|webp|gif|avif)(?:$|[?#])|mime_type=image|image\/|~tplv-/i.test(fullUrl)) return false;
          return /\.mp4(?:$|[?#])|mime_type=video|video_mp4|\/video\/|video\/tos|\/tos-[^/?#]+\/|tiktokcdn|tiktokv|muscdn|akamaized|byteoversea|ibytedtos|bytefcdn/i.test(fullUrl)
            || /tiktokcdn|tiktokv|muscdn|akamaized|byteoversea|ibytedtos|bytefcdn/i.test(host);
        };
        const clean = (value) => String(value || "")
          .replace(/\\u002F/g, "/")
          .replace(/\\\//g, "/")
          .replace(/\\u0026/g, "&")
          .replace(/&amp;/g, "&");
        const fromValue = (value) => {
          if (!value) return [];
          if (typeof value === "string") return [clean(value)];
          if (Array.isArray(value)) return value.flatMap(fromValue);
          if (typeof value === "object") {
            return [
              value.url,
              value.uri,
              value.playAddr,
              value.downloadAddr,
              value.PlayAddr,
              value.DownloadAddr,
              value.urlList,
              value.UrlList,
              value.url_list,
            ].flatMap(fromValue);
          }
          return [];
        };
        const mediaFromItem = (item) => {
          const video = item?.video || item?.Video || {};
          return [
            video.playAddr,
            video.downloadAddr,
            video.play_addr,
            video.download_addr,
            video.PlayAddr,
            video.DownloadAddr,
            video.bitRate,
            video.bitrateInfo,
          ].flatMap(fromValue).find(isMedia) || "";
        };
        const parseScriptJson = (id) => {
          const el = document.getElementById(id);
          if (!el) return null;
          try {
            const textarea = document.createElement("textarea");
            textarea.innerHTML = el.textContent || "";
            return JSON.parse(textarea.value);
          } catch (_) {
            return null;
          }
        };
        const fromDom = () => {
          const candidates = [];
          document.querySelectorAll("video, source").forEach((node) => {
            candidates.push(node.currentSrc, node.src, node.getAttribute("src"));
          });
          return candidates.map(clean).find(isMedia) || "";
        };
        const fromPerformance = () => {
          return performance.getEntriesByType("resource")
            .map((entry) => entry.name)
            .map(clean)
            .find(isMedia) || "";
        };
        const fromJsonScripts = () => {
          const sigi = parseScriptJson("SIGI_STATE");
          for (const item of Object.values(sigi?.ItemModule || sigi?.itemModule || {})) {
            const media = mediaFromItem(item);
            if (media) return media;
          }
          const universal = parseScriptJson("__UNIVERSAL_DATA_FOR_REHYDRATION__");
          const universalItem = universal?.__DEFAULT_SCOPE__?.["webapp.video-detail"]?.itemInfo?.itemStruct;
          const universalMedia = mediaFromItem(universalItem);
          if (universalMedia) return universalMedia;
          const next = parseScriptJson("__NEXT_DATA__");
          return mediaFromItem(next?.props?.pageProps?.itemInfo?.itemStruct);
        };
        const fromHtml = () => {
          const html = document.documentElement.innerHTML;
          const patterns = [
            /"playAddr"\s*:\s*"([^"]+)"/i,
            /"downloadAddr"\s*:\s*"([^"]+)"/i,
            /"play_addr"\s*:\s*\{[^}]*"url_list"\s*:\s*\[\s*"([^"]+)"/i,
            /"PlayAddr"\s*:\s*\{[^}]*"UrlList"\s*:\s*\[\s*"([^"]+)"/i,
          ];
          for (const pattern of patterns) {
            const url = clean(html.match(pattern)?.[1] || "");
            if (isMedia(url)) return url;
          }
          return "";
        };

        for (let i = 0; i < 14; i += 1) {
          const media = fromDom() || fromPerformance() || fromJsonScripts() || fromHtml();
          if (media) return media;
          const video = document.querySelector("video");
          if (video) {
            video.muted = true;
            video.play().catch(() => {});
          }
          window.scrollBy(0, 300);
          await sleep(1000);
        }
        return "";
      },
    });
    const mediaUrl = result || "";
    if (isDownloadableMediaUrl(mediaUrl)) {
      video.mediaUrl = mediaUrl;
      await saveState();
      return mediaUrl;
    }
    return "";
  } catch (_) {
    return "";
  } finally {
    if (tab?.id) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

async function downloadSingle() {
  try {
    $("btn-download-single").disabled = true;
    $("btn-download-single").textContent = "Downloading...";
    await downloadUrl($("btn-download-single").dataset.url, $("btn-download-single").dataset.filename || `tiktok_${Date.now()}.mp4`);
    showAlert("single-alert", "Download complete.", "success");
  } catch (error) {
    showAlert("single-alert", error.message);
  } finally {
    $("btn-download-single").disabled = false;
    $("btn-download-single").textContent = "Download";
  }
}

async function startBulkFetch() {
  const btn = $("btn-bulk-fetch");
  const stopBtn = $("btn-stop-fetch");
  try {
    const profile = await requireCurrentProfile();
    hideAlert("bulk-alert");
    btn.disabled = true;
    stopBtn.disabled = false;
    btn.textContent = "Fetching...";
    $("bulk-progress-wrap").classList.add("visible");
    $("bulk-results-card").style.display = "none";
    setProgress("bulk-progress-bar", "bulk-progress-text", 8, "Reading profile...");

    const maxVideos = parseInt($("bulk-max").value, 10) || 0;
    const scanDelay = 2200;
    const stopDateFrom = ($("filter-date-from").value || "").replace(/-/g, "");
    const stopDateTo = ($("filter-date-to").value || "").replace(/-/g, "");
    await startBackgroundFetch(profile, { scanDelay, stopDateFrom, stopDateTo, maxVideos });
    startJobPolling();
  } catch (error) {
    showAlert("bulk-alert", error.message);
    $("bulk-progress-wrap").classList.remove("visible");
    btn.disabled = false;
    stopBtn.disabled = true;
    btn.textContent = "Fetch Videos";
  }
}

function renderBulkResults(videos) {
  $("result-count").textContent = videos.length;
  const tbody = $("results-tbody");
  tbody.innerHTML = "";
  videos.forEach((v) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><input type="checkbox" class="row-chk" data-id="${escapeHtml(v.id)}" /></td>
      <td class="thumb-cell">${v.thumbnail ? `<img src="${escapeHtml(v.thumbnail)}" alt="" loading="lazy" />` : ""}</td>
      <td class="title-cell" title="${escapeHtml(v.title)}">${escapeHtml(v.title || "-")}</td>
      <td>${fmtDate(v.upload_date)}</td>
      <td>${fmtDur(v.duration)}</td>
      <td>${fmtNum(v.view_count)}</td>
      <td>${fmtNum(v.like_count)}</td>
    `;
    tbody.appendChild(tr);
  });
  $("bulk-results-card").style.display = "block";
  $("chk-all-header").checked = false;
}

function getSelectedVideos() {
  const ids = new Set([...document.querySelectorAll(".row-chk:checked")].map((c) => c.dataset.id));
  return currentVideos.filter((video) => ids.has(video.id));
}

async function downloadSelected() {
  const btn = $("btn-download-selected");
  try {
    const selected = getSelectedVideos();
    if (!selected.length) throw new Error("Select at least one video.");

    btn.disabled = true;
    btn.textContent = "Downloading...";
    $("download-progress-wrap").classList.add("visible");
    setProgress("dl-progress-bar", "dl-progress-text", 0, `Preparing 0/${selected.length} downloads...`);
    hideAlert("bulk-alert");

    let started = 0;
    let failed = 0;
    const failureMessages = [];
    for (let index = 0; index < selected.length; index += 1) {
      const video = selected[index];
      try {
        setProgress(
          "dl-progress-bar",
          "dl-progress-text",
          Math.round((index / selected.length) * 100),
          `Preparing ${index + 1}/${selected.length}: ${video.title || video.id || "video"}`
        );
        const mediaUrl = await ensureMediaUrl(video);
        if (!mediaUrl) throw new Error("No real video URL found.");
        if (!isDownloadableMediaUrl(mediaUrl)) throw new Error("Resolved URL is not a video file.");
        await downloadUrl(mediaUrl, videoFilename(video, index), video);
        started += 1;
        setProgress(
          "dl-progress-bar",
          "dl-progress-text",
          Math.round(((index + 1) / selected.length) * 100),
          `Downloaded ${started}/${selected.length} video(s)...`
        );
      } catch (error) {
        failed += 1;
        failureMessages.push(`${safeFilenamePart(video.title || video.id || `video ${index + 1}`)}: ${error.message}`);
      }
      await sleep(250);
    }

    await saveState();
    setProgress("dl-progress-bar", "dl-progress-text", 100, `Done - ${started} video download(s) complete`);
    showAlert(
      "bulk-alert",
      failed
        ? `Downloaded ${started} video(s). Failed ${failed}: ${failureMessages.slice(0, 2).join(" | ")}`
        : `Download complete: ${started} video(s) saved.`,
      failed ? "warning" : "success"
    );
  } catch (error) {
    showAlert("bulk-alert", error.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "Download";
  }
}

async function helperFetch(path, body) {
  const res = await fetch(`${HELPER_URL}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    let message = "Downloader helper failed.";
    try {
      const payload = await res.json();
      message = payload.detail || message;
    } catch (_) {}
    throw new Error(message);
  }
  return res;
}

function helperErrorMessage(error) {
  if (/failed to fetch|network/i.test(error.message)) {
    return "Start TikGrab Downloader Helper first, then try again.";
  }
  return error.message;
}

function filenameFromResponse(res, fallback) {
  const match = (res.headers.get("Content-Disposition") || "").match(/filename="?([^"]+)"?/);
  return match ? match[1] : fallback;
}

function triggerBlobDownload(blob, filename) {
  if (/text|json|html/i.test(blob.type || "") || /\.txt$|\.html?$|\.json$/i.test(filename || "")) {
    throw new Error("Downloader returned a text/page file instead of a video. This post may be blocked by TikTok.");
  }
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename, saveAs: false, conflictAction: "uniquify" }, () => {
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  });
}

async function openSelected() {
  try {
    const selected = getSelectedVideos();
    if (!selected.length) throw new Error("Select at least one video.");
    for (const video of selected.slice(0, 10)) {
      if (video.webpage_url) await chrome.tabs.create({ url: video.webpage_url, active: false });
      await sleep(120);
    }
    showAlert("bulk-alert", `Opened ${Math.min(selected.length, 10)} selected video page(s).`, "success");
  } catch (error) {
    showAlert("bulk-alert", error.message);
  }
}

const crcTable = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let c = i;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function u16(value) {
  return [value & 0xff, (value >>> 8) & 0xff];
}

function u32(value) {
  return [value & 0xff, (value >>> 8) & 0xff, (value >>> 16) & 0xff, (value >>> 24) & 0xff];
}

function dosTimeDate(date = new Date()) {
  const time = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
  const dosDate = ((date.getFullYear() - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { time, dosDate };
}

function buildZip(files) {
  const encoder = new TextEncoder();
  const chunks = [];
  const central = [];
  let offset = 0;
  const { time, dosDate } = dosTimeDate();

  for (const file of files) {
    const nameBytes = encoder.encode(file.name);
    const data = file.bytes;
    const crc = crc32(data);
    const local = new Uint8Array([
      ...u32(0x04034b50), ...u16(20), ...u16(0), ...u16(0), ...u16(time), ...u16(dosDate),
      ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nameBytes.length), ...u16(0),
    ]);
    chunks.push(local, nameBytes, data);

    central.push(new Uint8Array([
      ...u32(0x02014b50), ...u16(20), ...u16(20), ...u16(0), ...u16(0), ...u16(time), ...u16(dosDate),
      ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nameBytes.length), ...u16(0), ...u16(0),
      ...u16(0), ...u16(0), ...u32(0), ...u32(offset),
    ]), nameBytes);

    offset += local.length + nameBytes.length + data.length;
  }

  const centralStart = offset;
  const centralSize = central.reduce((sum, chunk) => sum + chunk.length, 0);
  const end = new Uint8Array([
    ...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length),
    ...u32(centralSize), ...u32(centralStart), ...u16(0),
  ]);
  return new Blob([...chunks, ...central, end], { type: "application/zip" });
}

function bytesFromText(text) {
  return new TextEncoder().encode(text);
}

function xmlEscape(value) {
  return String(value ?? "").replace(/[<>&"']/g, (char) => ({
    "<": "&lt;",
    ">": "&gt;",
    "&": "&amp;",
    '"': "&quot;",
    "'": "&apos;",
  }[char]));
}

function columnName(index) {
  let name = "";
  let value = index;
  while (value > 0) {
    const mod = (value - 1) % 26;
    name = String.fromCharCode(65 + mod) + name;
    value = Math.floor((value - mod) / 26);
  }
  return name;
}

function sheetCell(ref, value, style = 0) {
  const styleAttr = style ? ` s="${style}"` : "";
  return `<c r="${ref}" t="inlineStr"${styleAttr}><is><t>${xmlEscape(value)}</t></is></c>`;
}

function sheetFormulaCell(ref, formula, style = 0) {
  const styleAttr = style ? ` s="${style}"` : "";
  return `<c r="${ref}"${styleAttr}><f>${xmlEscape(formula)}</f></c>`;
}

function xlsxDate() {
  return new Date().toISOString();
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error("Could not read thumbnail image."));
    reader.readAsDataURL(blob);
  });
}

async function imageBlobToPngBytes(blob) {
  const image = new Image();
  image.decoding = "async";
  image.src = await blobToDataUrl(blob);
  await new Promise((resolve, reject) => {
    image.onload = resolve;
    image.onerror = () => reject(new Error("Could not decode thumbnail image."));
  });

  const canvas = document.createElement("canvas");
  canvas.width = image.naturalWidth || image.width;
  canvas.height = image.naturalHeight || image.height;
  const ctx = canvas.getContext("2d");
  if (!ctx || !canvas.width || !canvas.height) throw new Error("Could not render thumbnail image.");
  ctx.drawImage(image, 0, 0);

  const pngBlob = await new Promise((resolve, reject) => {
    canvas.toBlob((result) => result ? resolve(result) : reject(new Error("Could not convert thumbnail image.")), "image/png");
  });
  return new Uint8Array(await pngBlob.arrayBuffer());
}

async function fetchThumbnailForXlsx(video, index) {
  if (!video.thumbnail) return null;
  try {
    const res = await fetch(video.thumbnail, {
      headers: {
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
      },
    });
    if (!res.ok) return null;
    const blob = await res.blob();
    const bytes = await imageBlobToPngBytes(blob);
    if (!bytes.length) return null;
    return {
      row: index + 2,
      relId: `rId${index + 1}`,
      name: `image${index + 1}.png`,
      extension: "png",
      bytes,
    };
  } catch (_) {
    return null;
  }
}

async function fetchThumbnailsForXlsx(videos, alertId) {
  const images = [];
  let next = 0;
  let done = 0;
  const workers = Array.from({ length: Math.min(6, videos.length) }, async () => {
    while (next < videos.length) {
      const index = next;
      next += 1;
      const image = await fetchThumbnailForXlsx(videos[index], index);
      if (image) images.push(image);
      done += 1;
      if (done % 10 === 0 || done === videos.length) {
        showAlert(alertId, `Preparing Excel previews ${done}/${videos.length}...`, "warning");
      }
    }
  });
  await Promise.all(workers);
  return images.sort((a, b) => a.row - b.row);
}

async function buildXlsxBlob(videos, alertId) {
  const headers = ["Preview", "ID", "Uploader", "Title", "Description", "Published day", "Duration", "Thumbnail URL", "Webpage URL"];
  const rows = videos.map((video) => [
    video.thumbnail || "",
    video.id || "",
    video.uploader || "",
    video.title || "",
    video.description || "",
    exportDate(video.upload_date),
    exportDuration(video.duration),
    video.thumbnail || "",
    video.webpage_url || "",
  ]);
  const hyperlinks = [];
  rows.forEach((row, rowIndex) => {
    const excelRow = rowIndex + 2;
    const thumbnailUrl = row[7];
    const videoUrl = row[8];
    if (thumbnailUrl) {
      hyperlinks.push({
        ref: `H${excelRow}`,
        relId: `rId${hyperlinks.length + 2}`,
        target: thumbnailUrl,
        tooltip: "Open thumbnail",
      });
    }
    if (videoUrl) {
      hyperlinks.push({
        ref: `I${excelRow}`,
        relId: `rId${hyperlinks.length + 2}`,
        target: videoUrl,
        tooltip: "Open TikTok video",
      });
    }
  });
  const files = [];

  const sheetRows = [];
  sheetRows.push(`<row r="1" ht="24" customHeight="1">${headers.map((header, index) => sheetCell(`${columnName(index + 1)}1`, header, 1)).join("")}</row>`);
  rows.forEach((row, rowIndex) => {
    const excelRow = rowIndex + 2;
    const height = row[0] ? 82 : 34;
    sheetRows.push(`<row r="${excelRow}" ht="${height}" customHeight="1">${row.map((value, colIndex) => {
      const ref = `${columnName(colIndex + 1)}${excelRow}`;
      if (colIndex === 0 && value) return sheetFormulaCell(ref, `IMAGE("${String(value).replace(/"/g, '""')}")`);
      const isLink = colIndex === 7 || colIndex === 8;
      return sheetCell(ref, value, isLink && value ? 2 : 0);
    }).join("")}</row>`);
  });
  const hyperlinkXml = hyperlinks.length
    ? `<hyperlinks>${hyperlinks.map((link) => `<hyperlink ref="${link.ref}" r:id="${link.relId}" tooltip="${xmlEscape(link.tooltip)}"/>`).join("")}</hyperlinks>`
    : "";

  const sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheetViews><sheetView workbookViewId="0"/></sheetViews>
  <sheetFormatPr defaultRowHeight="15"/>
  <cols>
    <col min="1" max="1" width="18" customWidth="1"/>
    <col min="2" max="2" width="23" customWidth="1"/>
    <col min="3" max="3" width="20" customWidth="1"/>
    <col min="4" max="5" width="42" customWidth="1"/>
    <col min="6" max="7" width="16" customWidth="1"/>
    <col min="8" max="9" width="55" customWidth="1"/>
  </cols>
  <sheetData>${sheetRows.join("")}</sheetData>
  ${hyperlinkXml}
</worksheet>`;

  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>`;

  const created = xlsxDate();
  const staticFiles = {
    "[Content_Types].xml": contentTypes,
    "_rels/.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`,
    "docProps/app.xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>TikGrab</Application></Properties>`,
    "docProps/core.xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>TikGrab</dc:creator><cp:lastModifiedBy>TikGrab</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${created}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${created}</dcterms:modified></cp:coreProperties>`,
    "xl/workbook.xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="TikTok metadata" sheetId="1" r:id="rId1"/></sheets></workbook>`,
    "xl/_rels/workbook.xml.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
    "xl/styles.xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/><color rgb="FFFFFFFF"/></font><font><u/><sz val="11"/><name val="Calibri"/><color rgb="FF0563C1"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF10893E"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles><dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium9" defaultPivotStyle="PivotStyleLight16"/></styleSheet>`,
    "xl/worksheets/sheet1.xml": sheetXml,
    "xl/worksheets/_rels/sheet1.xml.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${hyperlinks.map((link) => `<Relationship Id="${link.relId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${xmlEscape(link.target)}" TargetMode="External"/>`).join("")}</Relationships>`,
  };

  Object.entries(staticFiles).forEach(([name, text]) => files.push({ name, bytes: bytesFromText(text) }));
  return buildZip(files);
}

function exportBlob(content, filename, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename, saveAs: true }, () => {
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  });
}

async function enrichMissingMetadata(videos, alertId) {
  const missing = videos.filter((video) => !video.duration && video.webpage_url);
  if (!missing.length) return videos;
  try {
    const profile = await requireCurrentProfile();
    showAlert(alertId, `Fetching ${missing.length} missing video duration(s)...`, "warning");
    const [{ result = [] }] = await chrome.scripting.executeScript({
      target: { tabId: profile.tab.id },
      args: [missing.map((video) => ({ id: String(video.id || ""), url: video.webpage_url }))],
      func: async (items) => {
        const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
        const durationSeconds = (value) => {
          if (value === null || value === undefined || value === "") return null;
          if (typeof value === "string" && /^PT/i.test(value)) {
            const match = value.match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?$/i);
            if (!match) return null;
            return Math.round((Number(match[1] || 0) * 3600) + (Number(match[2] || 0) * 60) + Number(match[3] || 0)) || null;
          }
          const duration = Number(value);
          if (!duration || Number.isNaN(duration)) return null;
          return Math.round(duration >= 1000 ? duration / 1000 : duration);
        };
        const itemDuration = (item) => {
          const video = item?.video || item?.Video || {};
          const values = [
            video.duration,
            video.durationSecond,
            video.durationSeconds,
            video.duration_ms,
            video.durationMs,
            item?.duration,
            item?.durationSecond,
            item?.duration_ms,
            item?.durationMs,
            item?.videoDuration,
          ];
          for (const value of values) {
            const duration = durationSeconds(value);
            if (duration) return duration;
          }
          return null;
        };
        const durationFromHtml = (html) => {
          const patterns = [
            /"duration"\s*:\s*"?(\d+(?:\.\d+)?)"?/i,
            /"durationSecond(?:s)?"\s*:\s*"?(\d+(?:\.\d+)?)"?/i,
            /"duration_ms"\s*:\s*"?(\d+(?:\.\d+)?)"?/i,
            /"durationMs"\s*:\s*"?(\d+(?:\.\d+)?)"?/i,
            /"videoDuration"\s*:\s*"?(\d+(?:\.\d+)?)"?/i,
            /"duration"\s*:\s*"(PT[^"]+)"/i,
          ];
          for (const pattern of patterns) {
            const duration = durationSeconds(html.match(pattern)?.[1]);
            if (duration) return duration;
          }
          return null;
        };
        const fetchDuration = async (video) => {
          if (video.id) {
            try {
              const params = new URLSearchParams({
                itemId: video.id,
                aid: "1988",
                app_language: "en",
              });
              const response = await fetch(`https://www.tiktok.com/api/item/detail/?${params}`, {
                credentials: "include",
                headers: { "Accept": "application/json,text/plain,*/*" },
              });
              if (response.ok) {
                const data = await response.json();
                const item = data?.itemInfo?.itemStruct || data?.itemStruct || data?.item;
                const duration = itemDuration(item);
                if (duration) return { id: video.id, duration };
              }
            } catch (_) {}
          }
          try {
            const response = await fetch(video.url, {
              credentials: "include",
              headers: { "Accept": "text/html,application/xhtml+xml" },
            });
            if (response.ok) {
              const duration = durationFromHtml(await response.text());
              if (duration) return { id: video.id, duration };
            }
          } catch (_) {}
          return { id: video.id, duration: null };
        };

        const output = new Array(items.length);
        let next = 0;
        const workers = Array.from({ length: 5 }, async () => {
          while (next < items.length) {
            const index = next;
            next += 1;
            output[index] = await fetchDuration(items[index]);
            await sleep(75);
          }
        });
        await Promise.all(workers);
        return output;
      },
    });
    const byId = new Map(result.map((video) => [String(video.id || ""), video]));
    const enriched = videos.map((video) => {
      const info = byId.get(String(video.id || ""));
      if (!info) return video;
      return {
        ...video,
        duration: video.duration || info.duration,
        upload_date: video.upload_date || info.upload_date,
        thumbnail: video.thumbnail || info.thumbnail,
        title: video.title || info.title,
        description: video.description || info.description,
        uploader: video.uploader || info.uploader,
      };
    });
    currentVideos = enriched;
    rawVideos = rawVideos.map((video) => enriched.find((item) => item.id === video.id) || video);
    searchVideos = searchVideos.map((video) => enriched.find((item) => item.id === video.id) || video);
    await saveState();
    return enriched;
  } catch (error) {
    showAlert(alertId, "Some durations could not be fetched because TikTok metadata was slow or blocked.", "warning");
    return videos;
  }
}

async function exportVideos(videos, format, alertId) {
  if (!videos.length) return showAlert(alertId, "No videos to export.", "warning");
  showAlert(alertId, `Preparing ${format.toUpperCase()} export...`, "warning");
  videos = await enrichMissingMetadata(videos, alertId);
  if (format === "xlsx") {
    try {
      const blob = await buildXlsxBlob(videos, alertId);
      const url = URL.createObjectURL(new Blob([blob], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }));
      chrome.downloads.download({ url, filename: "tiktok_metadata.xlsx", saveAs: true, conflictAction: "uniquify" }, () => {
        setTimeout(() => URL.revokeObjectURL(url), 5000);
      });
      showAlert(alertId, "XLSX export downloaded without helper.", "success");
    } catch (error) {
      showAlert(alertId, error.message || "Could not create XLSX export.");
    }
    return;
  }
  if (format === "json") {
    exportBlob(JSON.stringify(videos, null, 2), "tiktok_metadata.json", "application/json");
    return;
  }
  const fields = ["id", "uploader", "title", "description", "published_day", "duration", "thumbnail_preview", "thumbnail_url", "webpage_url"];
  const excelTextFields = new Set(["id"]);
  const rows = [fields.join(",")].concat(videos.map((video) => fields.map((field) => {
    const rawValue = {
      id: video.id,
      uploader: video.uploader,
      title: video.title,
      description: video.description,
      published_day: exportDate(video.upload_date),
      duration: exportDuration(video.duration),
      thumbnail_preview: video.thumbnail ? `=IMAGE("${String(video.thumbnail).replace(/"/g, '""')}")` : "",
      thumbnail_url: video.thumbnail,
      webpage_url: video.webpage_url,
    }[field] ?? "";
    const value = String(rawValue).replace(/"/g, '""');
    if (excelTextFields.has(field) && value) return `"=""${value}"""`;
    return `"${value}"`;
  }).join(",")));
  exportBlob(`\ufeff${rows.join("\n")}`, "tiktok_metadata.csv", "text/csv;charset=utf-8");
}

async function searchDescriptions() {
  const btn = $("btn-search-descriptions");
  try {
    const profile = await requireCurrentProfile();
    const words = wordsFromInput($("search-words").value).map((word) => word.toLowerCase());
    if (!words.length) throw new Error("Enter at least one word to search.");
    const matchAll = $("search-match-all").checked;
    hideAlert("search-alert");
    btn.disabled = true;
    btn.textContent = "Searching...";
    searchVideos = [];
    await saveState();
    renderSearchResults(searchVideos, `Scanning @${profile.handle}. No matches for "${words.join(", ")}" yet.`, words);
    showAlert("search-alert", "Background search started. You can switch tabs while it scans.", "warning");
    await startBackgroundFetch(profile, { scanDelay: 1200 });
    startSearchJobPolling(words, matchAll);
  } catch (error) {
    showAlert("search-alert", error.message);
    btn.disabled = false;
    $("btn-stop-search").disabled = true;
    btn.textContent = "Search Descriptions";
  }
}

function renderSearchResults(videos, emptyMessage = "No matching descriptions found. Try another word or uncheck Match all words.", words = currentSearchWords()) {
  $("search-result-count").textContent = videos.length;
  const list = $("search-results-list");
  list.innerHTML = "";
  if (!videos.length) {
    const item = document.createElement("div");
    item.className = "search-empty";
    item.textContent = emptyMessage;
    list.appendChild(item);
    $("search-results-card").style.display = "block";
    return;
  }
  videos.forEach((video) => {
    const item = document.createElement("article");
    item.className = "search-result";
    item.innerHTML = `
      ${video.thumbnail ? `<img src="${escapeHtml(video.thumbnail)}" alt="" loading="lazy" />` : "<div class=\"empty-thumb\"></div>"}
      <div>
        <h3>${highlightSearchWords(video.title || "Untitled", words)}</h3>
        <p>${highlightSearchWords(video.description || "", words)}</p>
        <div class="stats">
          <span>${fmtDate(video.upload_date)}</span>
          <span>${fmtDur(video.duration)}</span>
          <span>${fmtNum(video.view_count)} views</span>
          <span>${fmtNum(video.like_count)} likes</span>
        </div>
        <a href="${escapeHtml(video.webpage_url || "#")}" target="_blank" rel="noreferrer">Open on TikTok</a>
      </div>
    `;
    list.appendChild(item);
  });
  $("search-results-card").style.display = "block";
}

function initTabs() {
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      activateTab(btn.dataset.tab);
      saveState();
    });
  });
}

async function init() {
  applyTheme(localStorage.getItem("tikgrab-theme") || "dark");
  initTabs();
  await restoreState();
  await detectCurrentProfile();
  const existingJob = await getBackgroundJob();
  if (existingJob.running && activeTabName() === "search") {
    const words = wordsFromInput($("search-words").value).map((word) => word.toLowerCase());
    const matchAll = $("search-match-all").checked;
    if (words.length) {
      await updateSearchResultsFromJob(existingJob, words, matchAll, false);
      startSearchJobPolling(words, matchAll);
    }
  } else if (existingJob.running) {
    $("bulk-progress-wrap").classList.add("visible");
    $("btn-bulk-fetch").disabled = true;
    $("btn-stop-fetch").disabled = false;
    $("btn-bulk-fetch").textContent = "Fetching...";
    startJobPolling();
  } else if (existingJob.videos?.length) {
    await renderFilteredResultsFromRaw(existingJob.videos);
  }
  $("theme-toggle").addEventListener("click", (event) => {
    const opt = event.target.closest(".theme-toggle-option");
    if (opt) applyTheme(opt.dataset.themeVal);
  });
  $("btn-fetch-info")?.addEventListener("click", fetchSingleInfo);
  $("btn-download-single")?.addEventListener("click", downloadSingle);
  $("btn-bulk-fetch").addEventListener("click", startBulkFetch);
  $("btn-clear-filters").addEventListener("click", clearBulkFilters);
  $("btn-stop-fetch").addEventListener("click", () => {
    stopBackgroundFetch();
    showAlert("bulk-alert", "Stopping fetch...", "warning");
  });
  $("btn-search-descriptions").addEventListener("click", searchDescriptions);
  $("btn-stop-search")?.addEventListener("click", () => {
    stopBackgroundFetch();
    $("btn-stop-search").disabled = true;
    showAlert("search-alert", "Stopping search...", "warning");
  });
  $("chk-all-header").addEventListener("change", (event) => {
    document.querySelectorAll(".row-chk").forEach((check) => { check.checked = event.target.checked; });
  });
  $("btn-select-all").addEventListener("click", () => {
    document.querySelectorAll(".row-chk").forEach((check) => { check.checked = true; });
    $("chk-all-header").checked = true;
  });
  $("btn-select-none").addEventListener("click", () => {
    document.querySelectorAll(".row-chk").forEach((check) => { check.checked = false; });
    $("chk-all-header").checked = false;
  });
  $("btn-download-selected")?.addEventListener("click", downloadSelected);
  $("btn-open-selected").addEventListener("click", openSelected);
  $("btn-export-csv-bulk").addEventListener("click", () => exportVideos(currentVideos, "csv", "bulk-alert"));
  $("btn-export-xlsx-bulk").addEventListener("click", () => exportVideos(currentVideos, "xlsx", "bulk-alert"));
  $("btn-export-json-bulk").addEventListener("click", () => exportVideos(currentVideos, "json", "bulk-alert"));
  $("btn-export-csv-search").addEventListener("click", () => exportVideos(searchVideos, "csv", "search-alert"));
  $("btn-export-xlsx-search").addEventListener("click", () => exportVideos(searchVideos, "xlsx", "search-alert"));
  $("btn-export-json-search").addEventListener("click", () => exportVideos(searchVideos, "json", "search-alert"));

  document.querySelectorAll("input").forEach((input) => {
    input.addEventListener("change", async () => {
      if (rawVideos.length && input.closest("#tab-bulk")) await renderFilteredResultsFromRaw(rawVideos);
      else await saveState();
    });
    input.addEventListener("blur", saveState);
  });
}

document.addEventListener("DOMContentLoaded", init);
