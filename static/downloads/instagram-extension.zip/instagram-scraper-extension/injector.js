// injector.js - Runs in the PAGE context (not extension context)
// Monkey-patches fetch and XHR to intercept Instagram's GraphQL responses

(function () {
  'use strict';

  // Keys that indicate a response contains media/post data
  const DATA_KEYS = [
    'edge_owner_to_timeline_media',
    'xdt_api__v1__feed__user_timeline_connection',
    'xdt_api__v1__feed__timeline_connection',
    'xdt_api__v1__user__web_profile_info',
    'edge_hashtag_to_media',
    'timeline_list_fetch_time',
    'media_or_ad',
    'GraphImage',
    'GraphVideo',
    'GraphSidecar',
    'XDTMediaDict',
    'clips_v2',
    'video_versions',
  ];

  // URLs to skip (static assets, not API)
  const SKIP_PATTERNS = [
    '.jpg', '.jpeg', '.png', '.gif', '.webp', '.mp4',
    '.js', '.css', '.ico', '.woff', '.svg',
    'accounts/login', 'static/', 'rsrc.php',
  ];

  function shouldSkipUrl(url) {
    const lower = url.toLowerCase();
    return SKIP_PATTERNS.some((p) => lower.includes(p));
  }

  function isInstagramApiUrl(url) {
    return (
      url.includes('instagram.com') &&
      !shouldSkipUrl(url)
    );
  }

  function containsPostData(str) {
    if (DATA_KEYS.some((key) => str.includes(key))) return true;
    // Catch any private-API response that has post items with media fields
    return (str.includes('"code"') || str.includes('"shortcode"')) &&
           (str.includes('"video_url"') || str.includes('"video_versions"') || str.includes('"image_versions2"'));
  }

  function dispatchData(data) {
    try {
      document.dispatchEvent(
        new CustomEvent('__ig_scraper_data', {
          detail: typeof data === 'string' ? data : JSON.stringify(data),
        })
      );
    } catch (e) {}
  }

  // ── Per-post media cache ────────────────────────────────────────────────────
  // Stores shortcode → slides in a hidden DOM <script> element so the
  // ISOLATED-world content script can read entries that were cached before
  // it registered its event listener (timing gap between document_start and
  // document_idle). Also dispatches __scs_post_cached for real-time updates.

  const CACHE_EL_ID = '__scs_ig_cache';

  function getDomCache() {
    let el = document.getElementById(CACHE_EL_ID);
    if (!el) {
      el = document.createElement('script');
      el.type = 'application/json';
      el.id   = CACHE_EL_ID;
      el.textContent = '{}';
      (document.head || document.documentElement).appendChild(el);
    }
    return el;
  }

  function cacheMediaItem(item) {
    const sc = item.code || item.shortcode;
    if (!sc) return;
    const videoUrl = item.video_url || item.video_versions?.[0]?.url;
    const imgUrl   = item.image_versions2?.candidates?.[0]?.url || item.display_url;

    // If this item is a video/reel but we only have a thumbnail URL (e.g. profile
    // grid SSR nodes), skip caching it — downloading the thumbnail JPG as if it
    // were a video would be misleading. The reel page's deeper SSR data will have
    // the real video_url and will be cached correctly.
    const isVideoItem = item.media_type === 2 || item.is_video === true ||
                        item.__typename === 'GraphVideo' || item.product_type === 'clips';
    if (isVideoItem && !videoUrl) return;

    const mediaUrl = videoUrl || imgUrl;
    if (!mediaUrl) return;

    let slides;
    if (item.carousel_media?.length) {
      slides = item.carousel_media.map(s => {
        const vUrl = s.video_url || s.video_versions?.[0]?.url;
        const iUrl = s.image_versions2?.candidates?.[0]?.url;
        const url  = vUrl || iUrl;
        if (!url) return null;
        return { url, id: String(s.pk || s.id || ''), isVideo: !!vUrl };
      }).filter(Boolean);
    } else {
      slides = [{ url: mediaUrl, id: String(item.pk || item.id || ''), isVideo: !!videoUrl }];
    }
    if (!slides.length) return;

    // Persist in DOM so late-loading content scripts can catch up
    try {
      const el  = getDomCache();
      const obj = JSON.parse(el.textContent || '{}');
      if (!obj[sc]) {
        obj[sc] = slides;
        el.textContent = JSON.stringify(obj);
      }
    } catch (_) {}

    // Also dispatch event for already-registered listeners
    try {
      document.dispatchEvent(new CustomEvent('__scs_post_cached', {
        detail: JSON.stringify({ shortcode: sc, slides }),
      }));
    } catch (_) {}
  }

  // Recursive walker — handles every nesting Instagram uses:
  //   items[], media[], medias[], nodes[], edges[].node, media_or_ad,
  //   GraphQL profile nodes (shortcode + display_url only), etc.
  function walkForItems(val, depth) {
    if (!val || typeof val !== 'object' || depth > 20) return;

    if (Array.isArray(val)) {
      for (const it of val) {
        // Unwrap common wrappers first
        const unwrapped = it?.node || it?.media || it;
        if (unwrapped && typeof unwrapped === 'object') walkForItems(unwrapped, depth + 1);
        // Some reel items have a sibling .media
        if (it?.media && it.media !== unwrapped) walkForItems(it.media, depth + 1);
      }
      return;
    }

    // If this object looks like a post item, cache it and stop recursing into it.
    // Covers both Private API items (image_versions2 / video_url / video_versions)
    // and GraphQL profile-grid nodes (display_url / thumbnail_src only).
    if ((val.code || val.shortcode) &&
        (val.video_url || val.video_versions?.length || val.image_versions2 ||
         val.carousel_media || val.display_url || val.thumbnail_src)) {
      cacheMediaItem(val);
      return;
    }

    for (const v of Object.values(val)) {
      if (v && typeof v === 'object') walkForItems(v, depth + 1);
    }
  }

  function cacheItemsFromData(data) {
    if (!data || typeof data !== 'object') return;
    walkForItems(data, 0);
  }

  // ── Helper: process an intercepted response text ────────────────────────
  function handleInterceptedText(text, urlLabel) {
    if (!text || text[0] !== '{') return;
    const hasData = containsPostData(text);
    console.log('[SCS-DBG]', urlLabel, '| len:', text.length, '| hasData:', hasData);
    if (!hasData) return;
    try {
      const parsed = JSON.parse(text);
      const before = (() => { try { return Object.keys(JSON.parse(document.getElementById('__scs_ig_cache')?.textContent||'{}')).length; } catch(_){return 0;} })();
      dispatchData(parsed);
      cacheItemsFromData(parsed);
      const after = (() => { try { return Object.keys(JSON.parse(document.getElementById('__scs_ig_cache')?.textContent||'{}')).length; } catch(_){return 0;} })();
      if (after > before) console.log('[SCS-DBG] cached', after - before, 'new items from', urlLabel);
    } catch (e) { console.log('[SCS-DBG] parse error from', urlLabel, ':', e.message); }
  }

  // ── Patch Cache API (Service Worker cache reads) ───────────────────────
  // Instagram's home/reels feed data is fetched by the Service Worker and
  // stored in the Cache API. The page reads it via cache.match() — never
  // through window.fetch — so we must intercept here.
  try {
    const _origCacheMatch = Cache.prototype.match;
    Cache.prototype.match = async function (request, ...rest) {
      const resp = await _origCacheMatch.call(this, request, ...rest);
      if (resp) {
        const url = typeof request === 'string' ? request
                  : request instanceof Request  ? request.url
                  : String(request || '');
        if (url && !shouldSkipUrl(url) && url.includes('instagram.com')) {
          try { resp.clone().text().then(t => handleInterceptedText(t, 'CACHE ' + url.slice(0, 60))).catch(() => {}); } catch (_) {}
        }
      }
      return resp;
    };

    const _origCachesMatch = caches.match.bind(caches);
    caches.match = async function (request, ...rest) {
      const resp = await _origCachesMatch(request, ...rest);
      if (resp) {
        const url = typeof request === 'string' ? request
                  : request instanceof Request  ? request.url
                  : String(request || '');
        if (url && !shouldSkipUrl(url) && url.includes('instagram.com')) {
          try { resp.clone().text().then(t => handleInterceptedText(t, 'CACHES ' + url.slice(0, 60))).catch(() => {}); } catch (_) {}
        }
      }
      return resp;
    };

    console.log('[SCS-DBG] Cache API patched');
  } catch (e) {
    console.log('[SCS-DBG] Cache patch error:', e.message);
  }

  // --- Patch fetch ---
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const url =
      typeof args[0] === 'string'
        ? args[0]
        : args[0] instanceof Request
        ? args[0].url
        : String(args[0] || '');

    // Log EVERY fetch call before any filtering
    console.log('[SCS-DBG] FETCH:', url.slice(0, 100), '| skip:', shouldSkipUrl(url));

    const response = await originalFetch.apply(this, args);

    try {
      if (!shouldSkipUrl(url)) {
        const clone = response.clone();
        clone.text().then((text) => {
          console.log('[SCS-DBG] RESP:', url.slice(0,60), '| starts:', JSON.stringify((text||'').slice(0,6)), '| len:', (text||'').length);
          if (!text) return;
          if (text[0] !== '{') return;
          const hasData = containsPostData(text);
          console.log('[SCS-DBG] JSON hasData:', hasData);
          if (hasData) {
            try {
              const parsed = JSON.parse(text);
              const before = (() => { try { return Object.keys(JSON.parse(document.getElementById('__scs_ig_cache')?.textContent||'{}')).length; } catch(_){return 0;} })();
              dispatchData(parsed);
              cacheItemsFromData(parsed);
              const after = (() => { try { return Object.keys(JSON.parse(document.getElementById('__scs_ig_cache')?.textContent||'{}')).length; } catch(_){return 0;} })();
              console.log('[SCS-DBG] cacheItemsFromData done, items before:', before, '-> after:', after);
            } catch (e) { console.log('[SCS-DBG] parse error:', e.message); }
          }
        }).catch((e) => { console.log('[SCS-DBG] clone.text error:', e?.message); });
      }
    } catch (_) {}

    return response;
  };

  // --- Patch XMLHttpRequest ---
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._igScraperUrl = String(url || '');
    return originalOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    const url = this._igScraperUrl || '';
    if (url && isInstagramApiUrl(url)) {
      console.log('[SCS-DBG] XHR:', url.slice(0, 100));
      this.addEventListener('load', function () {
        try {
          const text = this.responseText;
          const hasData = text && text[0] === '{' && containsPostData(text);
          console.log('[SCS-DBG] XHR RESP:', url.slice(0, 60), '| starts:', JSON.stringify((text||'').slice(0,6)), '| hasData:', hasData);
          if (hasData) {
            const parsed = JSON.parse(text);
            dispatchData(parsed);
            cacheItemsFromData(parsed);
          }
        } catch (_) {}
      });
    }
    return originalSend.apply(this, args);
  };

  // --- Read initial page data embedded in HTML script tags ---
  function extractInitialData() {
    let found = 0;

    // Try window._sharedData (legacy)
    try {
      if (window._sharedData) {
        const str = JSON.stringify(window._sharedData);
        if (containsPostData(str)) {
          dispatchData(window._sharedData);
          cacheItemsFromData(window._sharedData);
          found++;
        }
      }
    } catch (e) {}

    // Try all inline script tags for embedded JSON (taken_at / shortcode guard)
    try {
      const scripts = document.querySelectorAll('script');
      for (const script of scripts) {
        const text = script.textContent || '';
        if (
          containsPostData(text) &&
          (text.includes('taken_at') || text.includes('shortcode'))
        ) {
          const jsonMatches = text.match(/\{[\s\S]*?"taken_at[\s\S]*?\}/g);
          if (jsonMatches) {
            for (const match of jsonMatches) {
              try {
                const parsed = JSON.parse(match);
                dispatchData(parsed);
                cacheItemsFromData(parsed);
                found++;
              } catch (e) {}
            }
          }
        }
      }
    } catch (e) {}

    // Try <script type="application/json"> — walk ALL of them, not just those
    // matching containsPostData, because home/reels feed may use keys we don't
    // recognise yet. walkForItems only caches objects that look like real posts.
    try {
      const scripts = document.querySelectorAll('script[type="application/json"]');
      console.log('[SCS-DBG] extractInitialData: scanning', scripts.length, 'app/json scripts');
      let idx = 0;
      for (const script of scripts) {
        const text = script.textContent || '';
        const id   = script.id || '-';
        const hasData = containsPostData(text);
        if (text.length > 50) {
          console.log('[SCS-DBG] script[' + idx + '] id:', id,
            '| len:', text.length, '| hasData:', hasData,
            '| start:', JSON.stringify(text.slice(0, 120)));
        }
        idx++;
        try {
          const parsed = JSON.parse(text);
          if (parsed && typeof parsed === 'object') {
            if (hasData) dispatchData(parsed);
            const before = (() => { try { return Object.keys(JSON.parse(document.getElementById('__scs_ig_cache')?.textContent||'{}')).length; } catch(_){return 0;} })();
            cacheItemsFromData(parsed);
            const after = (() => { try { return Object.keys(JSON.parse(document.getElementById('__scs_ig_cache')?.textContent||'{}')).length; } catch(_){return 0;} })();
            if (after > before) { found++; console.log('[SCS-DBG] script[' + (idx-1) + '] added', after - before, 'items'); }
          }
        } catch (e) {}
      }
    } catch (e) {}

    const total = (() => { try { return Object.keys(JSON.parse(document.getElementById('__scs_ig_cache')?.textContent||'{}')).length; } catch(_){return 0;} })();
    console.log('[SCS-DBG] extractInitialData: found', found, 'blobs, cache now has', total, 'items');
  }

  // ── On-demand reel page fetch ─────────────────────────────────────────────
  // When the feed cache is empty for a shortcode, the content script fires
  // __scs_fetch_reel. We fetch that reel's own page (which always has SSR data)
  // and parse it, which fires __scs_post_cached back to the content script.
  document.addEventListener('__scs_fetch_reel', async function (e) {
    try {
      const { shortcode } = JSON.parse(e.detail);
      if (!shortcode) return;
      console.log('[SCS-DBG] on-demand fetch for shortcode:', shortcode);
      const resp = await originalFetch('https://www.instagram.com/reel/' + shortcode + '/', { credentials: 'include' });
      const html = await resp.text();
      if (!html || html[0] !== '<') { console.log('[SCS-DBG] reel page bad response'); return; }
      const parser = new DOMParser();
      const doc    = parser.parseFromString(html, 'text/html');
      for (const script of doc.querySelectorAll('script[type="application/json"]')) {
        try {
          const parsed = JSON.parse(script.textContent || '');
          if (parsed && typeof parsed === 'object') cacheItemsFromData(parsed);
        } catch (_) {}
      }
      const total = (() => { try { return Object.keys(JSON.parse(document.getElementById('__scs_ig_cache')?.textContent||'{}')).length; } catch(_){return 0;} })();
      console.log('[SCS-DBG] on-demand parse done, cache now:', total);
    } catch (err) {
      console.log('[SCS-DBG] on-demand fetch error:', err.message);
    }
  });

  console.log('[SCS-DBG] injector.js MAIN world started, fetch patched:', typeof window.fetch);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', extractInitialData);
  } else {
    extractInitialData();
  }

  setTimeout(extractInitialData, 2000);
})();
