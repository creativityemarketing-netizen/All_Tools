function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

async function convertImage(bytes, mime) {
  const source = new Blob([new Uint8Array(bytes)], { type: mime || 'image/webp' });
  const bitmap = await createImageBitmap(source);
  const canvas = document.createElement('canvas');
  canvas.width = bitmap.width;
  canvas.height = bitmap.height;
  canvas.getContext('2d').drawImage(bitmap, 0, 0);
  bitmap.close();
  const jpeg = await new Promise((resolve, reject) => {
    canvas.toBlob(
      blob => blob ? resolve(blob) : reject(new Error('Image conversion failed')),
      'image/jpeg',
      0.88
    );
  });
  return blobToDataUrl(jpeg);
}

function readVideoDuration(url) {
  return new Promise(resolve => {
    const video = document.createElement('video');
    let finished = false;
    const finish = value => {
      if (finished) return;
      finished = true;
      video.removeAttribute('src');
      video.load();
      resolve(Number(value) || 0);
    };
    const timer = setTimeout(() => finish(0), 12000);
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      clearTimeout(timer);
      finish(Number.isFinite(video.duration) ? video.duration : 0);
    };
    video.onerror = () => {
      clearTimeout(timer);
      finish(0);
    };
    video.src = url;
  });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.target !== 'offscreen-media') return;
  if (message.type === 'CONVERT_IMAGE') {
    convertImage(message.bytes, message.mime)
      .then(dataUrl => sendResponse({ dataUrl }))
      .catch(error => sendResponse({ error: error.message }));
    return true;
  }
  if (message.type === 'READ_VIDEO_DURATION') {
    readVideoDuration(message.url)
      .then(duration => sendResponse({ duration }))
      .catch(error => sendResponse({ error: error.message }));
    return true;
  }
});
