// background.js - Service worker: state management, CSV/Excel export, media downloads

importScripts('utils/platform-detector.js', 'utils/normalizer.js', 'utils/csv-generator.js', 'utils/download-queue.js');

const tabState = new Map(); // tabId → { posts, handle, platform, isExtracting, lastError, profile }

function getState(tabId) {
  if (!tabState.has(tabId)) {
    tabState.set(tabId, {
      posts: new Map(),
      handle: '',
      platform: '',
      isExtracting: false,
      lastError: null,
      profile: null,
      dateFilterFrom: null,
      dateFilterTo: null,
    });
  }
  return tabState.get(tabId);
}

function saveStateToSession(tabId) {
  const s = getState(tabId);
  chrome.storage.session.set({
    [`tab_${tabId}`]: {
      posts: Array.from(s.posts.values()),
      totalPosts: s.posts.size,
      handle: s.handle,
      platform: s.platform,
      isExtracting: s.isExtracting,
      lastError: s.lastError,
      profile: s.profile,
      dateFilterFrom: s.dateFilterFrom || null,
      dateFilterTo: s.dateFilterTo || null,
    },
  });
}

async function restoreFromSession(tabId) {
  const s = getState(tabId);
  if (s.posts.size > 0) return s;
  const key = `tab_${tabId}`;
  const result = await chrome.storage.session.get(key);
  const saved = result[key];
  if (saved?.posts?.length > 0) {
    for (const post of saved.posts) s.posts.set(post.postId, post);
    s.handle = saved.handle || '';
    s.platform = saved.platform || '';
    s.isExtracting = false;
    s.profile = saved.profile || null;
    s.dateFilterFrom = saved.dateFilterFrom || null;
    s.dateFilterTo   = saved.dateFilterTo   || null;
  }
  return s;
}

function normalizeItems(platform, items, handle) {
  const posts = [];
  for (const item of items) {
    let post = null;
    try {
      if (platform === 'instagram') post = Normalizer.fromInstagram(item, handle);
      else if (platform === 'tiktok')    post = Normalizer.fromTikTok(item);
      else if (platform === 'twitter')   post = Normalizer.fromTwitter(item);
      else if (platform === 'facebook')  post = Normalizer.fromFacebook(item);
    } catch(e) {}
    if (post) posts.push(post);
  }
  return posts;
}

// ── ZIP builder (pure JS, STORE method — no compression) ─────────────────────
function crc32(buf) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = c >>> 1 ^ (c & 1 ? 0xEDB88320 : 0);
  }
  return (c ^ 0xFFFFFFFF) >>> 0;
}

function buildZip(entries) {
  const parts = entries.map(e => ({ ...e, crc: crc32(e.data), nb: new TextEncoder().encode(e.name) }));
  const locals = [], cdirs = [], offsets = [];
  let offset = 0;

  for (const p of parts) {
    const blk = new Uint8Array(30 + p.nb.length + p.data.length);
    const dv  = new DataView(blk.buffer);
    dv.setUint32( 0, 0x04034B50, true); dv.setUint16( 4, 20, true);
    dv.setUint16( 6, 0, true);          dv.setUint16( 8, 0,  true); // STORE
    dv.setUint16(10, 0, true);          dv.setUint16(12, 0,  true);
    dv.setUint32(14, p.crc,          true);
    dv.setUint32(18, p.data.length,  true);
    dv.setUint32(22, p.data.length,  true);
    dv.setUint16(26, p.nb.length,    true); dv.setUint16(28, 0, true);
    blk.set(p.nb, 30); blk.set(p.data, 30 + p.nb.length);
    offsets.push(offset); locals.push(blk); offset += blk.length;
  }

  const cdirStart = offset;
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    const blk = new Uint8Array(46 + p.nb.length);
    const dv  = new DataView(blk.buffer);
    dv.setUint32( 0, 0x02014B50, true); dv.setUint16( 4, 20, true); dv.setUint16( 6, 20, true);
    dv.setUint16( 8, 0, true);          dv.setUint16(10, 0,  true); // STORE
    dv.setUint16(12, 0, true);          dv.setUint16(14, 0,  true);
    dv.setUint32(16, p.crc,         true);
    dv.setUint32(20, p.data.length, true);
    dv.setUint32(24, p.data.length, true);
    dv.setUint16(28, p.nb.length,   true); dv.setUint16(30, 0, true); dv.setUint16(32, 0, true);
    dv.setUint16(34, 0, true);             dv.setUint16(36, 0, true);
    dv.setUint32(38, 0, true);             dv.setUint32(42, offsets[i], true);
    blk.set(p.nb, 46); cdirs.push(blk); offset += blk.length;
  }

  const cdirSize = offset - cdirStart;
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32( 0, 0x06054B50,   true); ev.setUint16( 4, 0, true); ev.setUint16(6, 0, true);
  ev.setUint16( 8, parts.length, true); ev.setUint16(10, parts.length, true);
  ev.setUint32(12, cdirSize,     true); ev.setUint32(16, cdirStart,    true); ev.setUint16(20, 0, true);

  const zip = new Uint8Array(offset + 22);
  let pos = 0;
  for (const b of locals) { zip.set(b, pos); pos += b.length; }
  for (const b of cdirs)  { zip.set(b, pos); pos += b.length; }
  zip.set(eocd, pos);
  return zip;
}

function binaryToDataUrl(bytes, mime) {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return `data:${mime};base64,` + btoa(bin);
}

// ── Shortcode → numeric media ID (base-64 decode with Instagram's alphabet) ──
function scToId(sc) {
  const B62 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  let n = BigInt(0);
  for (const c of sc) {
    const i = B62.indexOf(c);
    if (i >= 0) n = n * 64n + BigInt(i);
  }
  return n.toString();
}

// ── Instagram extraction — alarm-driven chunks (survives service worker restarts) ──
async function igFetch(url, csrf, wwwClaim) {
  const resp = await fetch(url, {
    headers: {
      'X-IG-App-ID':      '936619743392459',
      'X-CSRFToken':      csrf,
      'X-Requested-With': 'XMLHttpRequest',
      'X-IG-WWW-Claim':   wwwClaim || '0',
      'Accept':           'application/json',
    },
    credentials: 'include',
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  return resp.json();
}

async function igPost(url, body, csrf, wwwClaim) {
  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'X-IG-App-ID':      '936619743392459',
      'X-CSRFToken':      csrf,
      'X-Requested-With': 'XMLHttpRequest',
      'X-IG-WWW-Claim':   wwwClaim || '0',
      'Content-Type':     'application/x-www-form-urlencoded',
      'Accept':           'application/json',
    },
    credentials: 'include',
    body,
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  return resp.json();
}

const IG_ALARM_PREFIX = 'ig_extract_';

async function startInstagramExtraction(tid, handle, csrf, dateFilterFrom, dateFilterTo) {
  const s = getState(tid);

  // Fetch profile within the active event handler so the SW stays alive
  const profileData = await igFetch(
    `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(handle)}`,
    csrf
  );
  const user = profileData?.data?.user;
  if (!user) throw new Error('User not found. Make sure you are logged in to Instagram.');
  const userId = String(user.id || user.pk);

  s.handle   = handle;
  s.platform = 'instagram';
  s.profile  = {
    userId,
    username:       user.username       || handle,
    fullName:       user.full_name      || '',
    followerCount:  user.edge_followed_by?.count  ?? 0,
    followingCount: user.edge_follow?.count        ?? 0,
    postCount:      user.edge_owner_to_timeline_media?.count ?? 0,
    isVerified: user.is_verified ?? false,
    isPrivate:  user.is_private  ?? false,
  };
  saveStateToSession(tid);

  // Persist extraction cursor state — survives SW termination
  await chrome.storage.session.set({
    [`${IG_ALARM_PREFIX}${tid}`]: {
      handle, csrf, userId,
      phase:          'feed',
      feedCursor:     null,
      feedDone:       false,
      feedEmptyPages: 0,
      reelsCursor:    null,
      reelsDone:      false,
      dateFilterFrom: dateFilterFrom || null,
      stopped:        false,
    },
  });

  // Remember which tab is extracting and when it started so the popup can resume correctly
  await chrome.storage.session.set({
    ig_active_tab: String(tid),
    ig_extract_start: Date.now(),
  });

  // Schedule the first chunk immediately
  chrome.alarms.create(`${IG_ALARM_PREFIX}${tid}`, { delayInMinutes: 0 });
}

// Runs the full extraction loop in one async call so the service worker stays alive.
// A 1-minute backup alarm is armed before each sleep; if the SW is killed the alarm
// restarts this function which resumes from the last saved cursor.
async function processInstagramChunk(tid) {
  const stored = await chrome.storage.session.get(`${IG_ALARM_PREFIX}${tid}`);
  const es     = stored[`${IG_ALARM_PREFIX}${tid}`];
  if (!es || es.stopped) {
    chrome.storage.session.remove(`${IG_ALARM_PREFIX}${tid}`);
    const s = getState(tid);
    s.isExtracting = false;
    saveStateToSession(tid);
    return;
  }

  let s = getState(tid);
  if (s.posts.size === 0 && !s.handle) {
    await restoreFromSession(tid);
    s = getState(tid);
  }
  s.isExtracting = true;
  saveStateToSession(tid);

  const { handle, csrf, userId, dateFilterFrom } = es;
  const fromTs = dateFilterFrom ? new Date(dateFilterFrom).getTime() / 1000 : null;
  const sleep  = (ms) => new Promise(r => setTimeout(r, ms));

  const finishExtraction = async (error) => {
    s.isExtracting = false;
    if (error) s.lastError = error;
    saveStateToSession(tid);
    await chrome.storage.session.remove(`${IG_ALARM_PREFIX}${tid}`);
    chrome.storage.session.remove('ig_active_tab');
  };

  const persistCursor = () => chrome.storage.session.set({
    [`${IG_ALARM_PREFIX}${tid}`]: {
      ...es,
      phase, feedCursor, feedDone, feedEmptyPages, reelsCursor, reelsDone,
    },
  });

  let phase          = es.phase;
  let feedCursor     = es.feedCursor;
  let feedDone       = es.feedDone;
  let feedEmptyPages = es.feedEmptyPages;
  let reelsCursor    = es.reelsCursor;
  let reelsDone      = es.reelsDone;

  try {
    while (true) {
      // Respect stop signal written by STOP_EXTRACTION handler
      const check = await chrome.storage.session.get(`${IG_ALARM_PREFIX}${tid}`);
      const live  = check[`${IG_ALARM_PREFIX}${tid}`];
      if (!live || live.stopped) { await finishExtraction(null); return; }

      if (phase === 'feed' && !feedDone) {
        let url = `https://www.instagram.com/api/v1/feed/user/${userId}/?count=50`;
        if (feedCursor) url += `&max_id=${encodeURIComponent(feedCursor)}`;
        const data  = await igFetch(url, csrf);
        const items = data?.items || [];
        let stopFeed = false;

        if (items.length > 0) {
          feedEmptyPages = 0;
          for (const post of normalizeItems('instagram', items, handle)) s.posts.set(post.postId, post);
          saveStateToSession(tid);
          if (fromTs) {
            const oldest = Math.min(...items.map(i => i.taken_at || Infinity));
            if (oldest < fromTs) stopFeed = true;
          }
        } else {
          feedEmptyPages++;
        }

        const moreAvail  = !!data?.more_available;
        const nextCursor = data?.next_max_id || null;
        feedDone   = stopFeed || feedEmptyPages >= 3 || !moreAvail || !nextCursor;
        feedCursor = nextCursor;
        if (feedDone) phase = 'reels';

        await persistCursor();
        if (!feedDone) {
          // Backup alarm: resumes extraction if SW is killed during sleep
          chrome.alarms.create(`${IG_ALARM_PREFIX}${tid}`, { delayInMinutes: 1 });
          await sleep(1500 + Math.random() * 700);
          chrome.alarms.clear(`${IG_ALARM_PREFIX}${tid}`); // SW survived, cancel backup
        }

      } else if (phase === 'reels' && !reelsDone) {
        let body = `target_user_id=${userId}&page_size=50`;
        if (reelsCursor) body += `&max_id=${encodeURIComponent(reelsCursor)}`;

        try {
          const rd        = await igPost('https://www.instagram.com/api/v1/clips/user/', body, csrf);
          const reelItems = (rd.items || []).map(i => ({ ...(i.media || i), _forceType: 'reel' }));
          let stopReels = false;

          if (reelItems.length > 0) {
            for (const post of normalizeItems('instagram', reelItems, handle)) s.posts.set(post.postId, post);
            saveStateToSession(tid);
            if (fromTs) {
              const oldest = Math.min(...reelItems.map(i => i.taken_at || Infinity));
              if (oldest < fromTs) stopReels = true;
            }
          }

          reelsDone = stopReels || !rd.paging_info?.more_available || !rd.paging_info?.max_id;
          if (!reelsDone) {
            reelsCursor = rd.paging_info?.max_id || null;
            await persistCursor();
            chrome.alarms.create(`${IG_ALARM_PREFIX}${tid}`, { delayInMinutes: 1 });
            await sleep(1800 + Math.random() * 700);
            chrome.alarms.clear(`${IG_ALARM_PREFIX}${tid}`);
          } else {
            await finishExtraction(null);
            return;
          }
        } catch (_) {
          await finishExtraction(null); // reels unavailable for this account
          return;
        }

      } else {
        await finishExtraction(null);
        return;
      }
    }
  } catch (err) {
    // Persist current cursor so the backup alarm can resume
    await persistCursor();
    chrome.alarms.create(`${IG_ALARM_PREFIX}${tid}`, { delayInMinutes: 1 });
  }
}

// Alarm listener: starts or resumes IG extraction after a service worker restart
chrome.alarms.onAlarm.addListener((alarm) => {
  if (!alarm.name.startsWith(IG_ALARM_PREFIX)) return;
  const tid = parseInt(alarm.name.slice(IG_ALARM_PREFIX.length), 10);
  if (!isNaN(tid)) processInstagramChunk(tid);
});

// ── Excel generator — HTML-as-XLS with embedded thumbnail images ────────────
async function fetchThumbBase64(url) {
  if (!url) return null;
  try {
    const r = await fetch(url);
    if (!r.ok) return null;
    const mime = r.headers.get('content-type') || 'image/jpeg';
    // WebP is not supported as an embedded XLSX drawing in LibreOffice / Google Sheets — skip it
    if (mime.includes('webp')) return null;
    const buf = await r.arrayBuffer();
    // Encode in 64KB chunks to avoid call-stack overflow on very large images
    const bytes = new Uint8Array(buf);
    let b64 = '';
    const CHUNK = 65536;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      b64 += btoa(String.fromCharCode(...bytes.subarray(i, i + CHUNK)));
    }
    return `data:${mime};base64,` + b64;
  } catch (_) { return null; }
}

async function generateExcel(posts, handle) {
  const thumbData = await Promise.all(posts.map(p => fetchThumbBase64(p.thumbnailUrl)));
  const h = s => String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  const lnk = url => url ? `<a href="${h(url)}">${h(url)}</a>` : '';
  const fmtDuration = seconds => {
    const total = Math.round(Number(seconds || 0));
    if (!total) return '';
    const hr = Math.floor(total / 3600);
    const min = Math.floor((total % 3600) / 60);
    const sec = total % 60;
    return hr > 0 ? `${hr}:${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${min}:${String(sec).padStart(2, '0')}`;
  };
  const td = 'padding:4px 6px;border:1px solid #ccc;vertical-align:middle;font-family:Arial;font-size:12px;white-space:nowrap';
  const th = 'padding:5px 6px;border:1px solid #999;background:#217346;color:#fff;font-family:Arial;font-size:12px;font-weight:bold;white-space:nowrap';
  const cols = ['Platform','Account','Post ID','Post URL','Caption','Published At','Media Type','Video Duration','Likes','Comments','Media URL','Thumbnail URL','Preview'];
  const hdr = '<tr>' + cols.map(c => `<th style="${th}">${c}</th>`).join('') + '</tr>';
  const rows = posts.map((p, i) => {
    const src = thumbData[i] || (p.thumbnailUrl ? h(p.thumbnailUrl) : null);
    const imgCell = src ? `<img src="${src}" style="max-height:72px;max-width:72px"/>` : '';
    return '<tr>' +
      `<td style="${td}">${h(p.platform)}</td>` +
      `<td style="${td}">${h(p.ownerHandle)}</td>` +
      `<td style="${td}">${h(p.postId)}</td>` +
      `<td style="${td}">${lnk(p.postUrl)}</td>` +
      `<td style="${td};white-space:normal;max-width:300px">${h(p.caption)}</td>` +
      `<td style="${td}">${h(p.publishedAt)}</td>` +
      `<td style="${td}">${h(p.mediaType)}</td>` +
      `<td style="${td}">${h(fmtDuration(p.videoDuration))}</td>` +
      `<td style="${td};text-align:right">${Number(p.likesCount || 0)}</td>` +
      `<td style="${td};text-align:right">${Number(p.commentsCount || 0)}</td>` +
      `<td style="${td}">${lnk(p.mediaUrl)}</td>` +
      `<td style="${td}">${lnk(p.thumbnailUrl)}</td>` +
      `<td style="${td};text-align:center;width:80px">${imgCell}</td>` +
      '</tr>';
  }).join('');
  return '<!DOCTYPE html><html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"/><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Posts</x:Name></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table border="1" style="border-collapse:collapse">' + hdr + rows + '</table></body></html>';
}

// ── XLSX generator — proper ZIP with embedded images (works in Excel & Google Sheets) ──
function generateXLSX(posts, thumbData) {
  const enc = new TextEncoder();
  const xe  = s => String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  const xa  = s => xe(s).replace(/'/g,'&apos;');

  // Parse base64 data-URIs into raw image bytes
  const images = [];
  for (let i = 0; i < posts.length; i++) {
    if (!thumbData[i]) continue;
    const m = thumbData[i].match(/^data:image\/(\w+);base64,(.+)$/);
    if (!m) continue;
    const ext = m[1] === 'jpg' ? 'jpeg' : m[1];
    const bin = atob(m[2]);
    const arr = new Uint8Array(bin.length);
    for (let j = 0; j < bin.length; j++) arr[j] = bin.charCodeAt(j);
    images.push({ data: arr, ext, rId: 'rId' + (images.length + 1), rowIdx: i });
  }

  // Shared strings table
  const strs = [], sidx = {};
  const ss = v => { const k = String(v ?? ''); if (sidx[k] === undefined) { sidx[k] = strs.length; strs.push(k); } return sidx[k]; };

  // Column letter from 0-indexed number
  const cl = n => { let s = '', i = n + 1; while (i > 0) { s = String.fromCharCode(65 + (i-1)%26) + s; i = Math.floor((i-1)/26); } return s; };

  const fmtDuration = seconds => {
    const total = Math.round(Number(seconds || 0));
    if (!total) return '';
    const hr = Math.floor(total / 3600);
    const min = Math.floor((total % 3600) / 60);
    const sec = total % 60;
    return hr > 0 ? `${hr}:${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${min}:${String(sec).padStart(2, '0')}`;
  };
  const COLS = ['Platform','Account','Post ID','Post URL','Caption','Published At','Media Type','Video Duration','Likes','Comments','Media URL','Thumbnail URL','Preview'];
  COLS.forEach(ss);
  const hyperlinks = [];
  const urlCell = (ref, url) => {
    if (!url) return `<c r="${ref}" t="s" s="0"><v>${ss('')}</v></c>`;
    hyperlinks.push({ ref, url: String(url) });
    return `<c r="${ref}" t="s" s="3"><v>${ss(url)}</v></c>`;
  };

  // Worksheet rows
  let rows = '<row r="1" ht="20" customHeight="1">' + COLS.map((c, ci) => `<c r="${cl(ci)}1" t="s" s="1"><v>${ss(c)}</v></c>`).join('') + '</row>';
  posts.forEach((p, ri) => {
    const rn = ri + 2;
    const acct = p.account || p.ownerHandle || '';
    rows += `<row r="${rn}" ht="60" customHeight="1">` +
      `<c r="A${rn}" t="s" s="0"><v>${ss(p.platform||'')}</v></c>` +
      `<c r="B${rn}" t="s" s="0"><v>${ss(acct)}</v></c>` +
      `<c r="C${rn}" t="s" s="0"><v>${ss(p.postId||'')}</v></c>` +
      urlCell(`D${rn}`, p.postUrl) +
      `<c r="E${rn}" t="s" s="0"><v>${ss(p.caption||'')}</v></c>` +
      `<c r="F${rn}" t="s" s="0"><v>${ss(p.publishedAt||'')}</v></c>` +
      `<c r="G${rn}" t="s" s="0"><v>${ss(p.mediaType||'')}</v></c>` +
      `<c r="H${rn}" t="s" s="0"><v>${ss(fmtDuration(p.videoDuration))}</v></c>` +
      `<c r="I${rn}" t="n" s="2"><v>${Number(p.likesCount||0)}</v></c>` +
      `<c r="J${rn}" t="n" s="2"><v>${Number(p.commentsCount||0)}</v></c>` +
      urlCell(`K${rn}`, p.mediaUrl) +
      urlCell(`L${rn}`, p.thumbnailUrl) +
      `<c r="M${rn}" s="0"/>` +
      '</row>';
  });

  const colDefs = [12,18,22,30,45,22,12,16,10,10,30,30,12].map((w,i) => `<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join('');
  const sheetXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
    '<sheetFormatPr defaultRowHeight="60" customHeight="1"/>' +
    '<cols>' + colDefs + '</cols>' +
    '<sheetData>' + rows + '</sheetData>' +
    (hyperlinks.length ? '<hyperlinks>' + hyperlinks.map((link, idx) => `<hyperlink ref="${link.ref}" r:id="rId${images.length ? idx + 2 : idx + 1}"/>`).join('') + '</hyperlinks>' : '') +
    (images.length ? '<drawing r:id="rId1"/>' : '') +
    '</worksheet>';

  // Drawing XML — one oneCellAnchor per image, pinned to column L
  const IMG = 548640, MAR = 18288; // EMUs: ~60px image, ~2px margin
  let drawXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" ' +
    'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" ' +
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
  images.forEach((img, idx) => {
    drawXml +=
      '<xdr:oneCellAnchor>' +
        '<xdr:from>' +
          '<xdr:col>12</xdr:col><xdr:colOff>' + MAR + '</xdr:colOff>' +
          '<xdr:row>' + (img.rowIdx + 1) + '</xdr:row><xdr:rowOff>' + MAR + '</xdr:rowOff>' +
        '</xdr:from>' +
        '<xdr:ext cx="' + IMG + '" cy="' + IMG + '"/>' +
        '<xdr:pic>' +
          '<xdr:nvPicPr><xdr:cNvPr id="' + (idx+2) + '" name="img' + (idx+1) + '"/><xdr:cNvPicPr/></xdr:nvPicPr>' +
          '<xdr:blipFill><a:blip r:embed="' + img.rId + '"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>' +
          '<xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + IMG + '" cy="' + IMG + '"/></a:xfrm>' +
          '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr>' +
        '</xdr:pic>' +
        '<xdr:clientData/>' +
      '</xdr:oneCellAnchor>';
  });
  drawXml += '</xdr:wsDr>';

  let drawRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
  images.forEach((img, idx) => {
    drawRels += '<Relationship Id="' + img.rId + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image' + (idx+1) + '.' + img.ext + '"/>';
  });
  drawRels += '</Relationships>';

  // Shared strings XML
  const ssXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' + strs.length + '" uniqueCount="' + strs.length + '">' +
    strs.map(s => '<si><t xml:space="preserve">' + xe(s) + '</t></si>').join('') +
    '</sst>';

  // Styles
  const stylesXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
    '<fonts><font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="10"/><name val="Arial"/><color rgb="FFFFFFFF"/></font><font><u/><sz val="10"/><name val="Arial"/><color rgb="FF0563C1"/></font></fonts>' +
    '<fills><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF217346"/></patternFill></fill></fills>' +
    '<borders><border><left/><right/><top/><bottom/><diagonal/></border>' +
    '<border><left style="thin"><color rgb="FFCCCCCC"/></left><right style="thin"><color rgb="FFCCCCCC"/></right><top style="thin"><color rgb="FFCCCCCC"/></top><bottom style="thin"><color rgb="FFCCCCCC"/></bottom><diagonal/></border></borders>' +
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
    '<cellXfs>' +
      '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf>' +
      '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" horizontal="center"/></xf>' +
      '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center" horizontal="right"/></xf>' +
      '<xf numFmtId="0" fontId="2" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>' +
    '</cellXfs>' +
    '</styleSheet>';

  // Content types
  const imgExts = [...new Set(images.map(img => img.ext))];
  let ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
    '<Default Extension="xml" ContentType="application/xml"/>';
  imgExts.forEach(ext => { ct += '<Default Extension="' + ext + '" ContentType="image/' + ext + '"/>'; });
  ct += '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
    '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' +
    '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>' +
    '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
  if (images.length) ct += '<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>';
  ct += '</Types>';

  const rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
  const wbXml   = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Posts" sheetId="1" r:id="rId1"/></sheets></workbook>';
  const wbRels  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
  let shRels  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
  if (images.length) shRels += '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/>';
  hyperlinks.forEach((link, idx) => {
    shRels += '<Relationship Id="rId' + (images.length ? idx + 2 : idx + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="' + xa(link.url) + '" TargetMode="External"/>';
  });
  shRels += '</Relationships>';

  const entries = [
    { name: '[Content_Types].xml',         data: enc.encode(ct)       },
    { name: '_rels/.rels',                 data: enc.encode(rootRels) },
    { name: 'xl/workbook.xml',             data: enc.encode(wbXml)    },
    { name: 'xl/_rels/workbook.xml.rels',  data: enc.encode(wbRels)   },
    { name: 'xl/worksheets/sheet1.xml',    data: enc.encode(sheetXml) },
    { name: 'xl/sharedStrings.xml',        data: enc.encode(ssXml)    },
    { name: 'xl/styles.xml',               data: enc.encode(stylesXml)},
  ];
  if (images.length || hyperlinks.length) {
    entries.push({ name: 'xl/worksheets/_rels/sheet1.xml.rels',  data: enc.encode(shRels)    });
  }
  if (images.length) {
    entries.push({ name: 'xl/drawings/drawing1.xml',             data: enc.encode(drawXml)   });
    entries.push({ name: 'xl/drawings/_rels/drawing1.xml.rels',  data: enc.encode(drawRels)  });
    images.forEach((img, idx) => entries.push({ name: 'xl/media/image' + (idx+1) + '.' + img.ext, data: img.data }));
  }
  return buildZip(entries);
}

function toDataUrl(content, mime) {
  const bytes = new TextEncoder().encode(content);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return `data:${mime};charset=utf-8;base64,` + btoa(binary);
}

function applyDateFilter(posts, s) {
  if (!s.dateFilterFrom && !s.dateFilterTo) return posts;
  const from = s.dateFilterFrom || null; // 'YYYY-MM-DD'
  const to   = s.dateFilterTo   || null;
  return posts.filter(p => {
    // Convert UTC timestamp to local date string (YYYY-MM-DD) so the comparison
    // respects the user's timezone instead of UTC midnight boundaries
    const localDate = new Date(p.publishedAt).toLocaleDateString('en-CA');
    if (from && localDate < from) return false;
    if (to   && localDate > to)   return false;
    return true;
  });
}

// ─────────────────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id || msg.tabId;

  switch (msg.type) {

    case 'START_EXTRACTION': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({ error: 'No tab ID' }); return; }
      const state = getState(tid);
      state.posts.clear(); state.lastError = null; state.isExtracting = true;
      saveStateToSession(tid);

      chrome.tabs.get(tid, (tab) => {
        if (chrome.runtime.lastError || !tab?.url) {
          state.isExtracting = false;
          state.lastError = 'Tab not found.';
          saveStateToSession(tid);
          sendResponse({ error: state.lastError });
          return;
        }
        const detected = PlatformDetector.detect(tab.url);
        if (detected?.platform === 'instagram') {
          // Extraction runs entirely in the service worker — ask content script only for cookies
          chrome.tabs.sendMessage(tid, { type: 'GET_CREDENTIALS' }, (creds) => {
            if (chrome.runtime.lastError || !creds?.csrf) {
              state.isExtracting = false;
              state.lastError = 'Content script not ready. Refresh the page and try again.';
              saveStateToSession(tid);
              sendResponse({ error: state.lastError });
              return;
            }
            startInstagramExtraction(
              tid,
              creds.handle || detected.handle || '',
              creds.csrf,
              msg.dateFilterFrom || null,
              msg.dateFilterTo   || null
            ).then(() => {
              sendResponse({ status: 'started' });
            }).catch(err => {
              state.isExtracting = false;
              state.lastError = err.message;
              saveStateToSession(tid);
              sendResponse({ error: err.message });
            });
          });
        } else {
          // Other platforms: forward to their content scripts as before
          chrome.tabs.sendMessage(tid, {
            type:           'START_EXTRACTION',
            dateFilterFrom: msg.dateFilterFrom || null,
            dateFilterTo:   msg.dateFilterTo   || null,
          }, (resp) => {
            if (chrome.runtime.lastError) {
              state.isExtracting = false;
              state.lastError = 'Content script not ready. Refresh the page and try again.';
              saveStateToSession(tid);
              sendResponse({ error: state.lastError });
            } else {
              sendResponse(resp || { status: 'started' });
            }
          });
        }
      });
      return true;
    }

    case 'STOP_EXTRACTION': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({}); return; }
      getState(tid).isExtracting = false;
      saveStateToSession(tid);
      // Cancel any pending IG extraction alarm and mark cursor state as stopped
      chrome.alarms.clear(`${IG_ALARM_PREFIX}${tid}`);
      chrome.storage.session.get(`${IG_ALARM_PREFIX}${tid}`, (r) => {
        const es = r[`${IG_ALARM_PREFIX}${tid}`];
        if (es) chrome.storage.session.set({ [`${IG_ALARM_PREFIX}${tid}`]: { ...es, stopped: true } });
      });
      // For non-Instagram platforms the content script loop still checks this flag via message
      chrome.tabs.get(tid, (tab) => {
        if (!chrome.runtime.lastError && tab?.url) {
          const detected = PlatformDetector.detect(tab.url);
          if (detected?.platform !== 'instagram') {
            chrome.tabs.sendMessage(tid, { type: 'STOP_EXTRACTION' }, () => {});
          }
        }
        sendResponse({ status: 'stopped' });
      });
      return true;
    }

    case 'EXTRACTION_STARTED': {
      if (!tabId) return;
      const s = getState(tabId);
      s.isExtracting = true;
      s.handle = msg.handle || '';
      s.platform = msg.platform || '';
      s.profile = msg.profile || null;
      saveStateToSession(tabId);
      break;
    }

    case 'POST_DATA': {
      if (!tabId) { sendResponse({}); return; }
      const s = getState(tabId);
      const platform = msg.platform || s.platform;
      const handle = msg.handle || s.handle;

      let posts = [];
      if (msg.data?.normalizedItems) {
        posts = msg.data.normalizedItems;
      } else if (msg.data?.items) {
        posts = normalizeItems(platform, msg.data.items, handle);
      }

      for (const post of posts) s.posts.set(post.postId, post);
      saveStateToSession(tabId);
      sendResponse({ totalPosts: s.posts.size });
      break;
    }

    case 'EXTRACTION_COMPLETE': {
      if (!tabId) return;
      const s = getState(tabId);
      s.isExtracting = false;
      saveStateToSession(tabId);
      break;
    }

    case 'EXTRACTION_ERROR': {
      if (!tabId) return;
      const s = getState(tabId);
      s.isExtracting = false;
      s.lastError = msg.error || 'Unknown error';
      saveStateToSession(tabId);
      break;
    }

    case 'GET_STATE': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({}); return; }
      restoreFromSession(tid).then(s => {
        const allPosts = applyDateFilter(Array.from(s.posts.values()), s);
        let feedCount = 0, reelCount = 0;
        for (const p of allPosts) {
          if (p.mediaType === 'reel') reelCount++;
          else feedCount++;
        }
        // Sort newest first for the table preview
        const sorted = allPosts.slice().sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));
        sendResponse({
          totalPosts: allPosts.length,
          fetchedTotal: s.posts.size,   // unfiltered — shows real fetch progress
          feedCount,
          reelCount,
          handle: s.handle,
          platform: s.platform,
          isExtracting: s.isExtracting,
          lastError: s.lastError,
          profile: s.profile,
          samplePosts: sorted.slice(0, 50),
          downloadProgress: DownloadQueue.getProgress(tid),
          dateFilterFrom: s.dateFilterFrom || null,
          dateFilterTo:   s.dateFilterTo   || null,
        });
      });
      return true;
    }

    case 'DOWNLOAD_CSV': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({ error: 'No tab ID' }); return; }
      restoreFromSession(tid).then(s => {
        try {
          const posts = applyDateFilter(Array.from(s.posts.values()), s);
          if (posts.length === 0) { sendResponse({ error: 'No posts to export' }); return; }
          const csv = CsvGenerator.generate(posts);
          const filename = CsvGenerator.getFilename(s.platform || 'social', s.handle);
          const url = toDataUrl(csv, 'text/csv');
          chrome.downloads.download({ url, filename, saveAs: false }, (dlId) => {
            if (chrome.runtime.lastError) { sendResponse({ error: chrome.runtime.lastError.message }); return; }
            sendResponse({ downloadId: dlId, postCount: posts.length });
          });
        } catch (err) { sendResponse({ error: 'CSV export failed: ' + err.message }); }
      }).catch(err => sendResponse({ error: 'Session error: ' + err.message }));
      return true;
    }

    case 'DOWNLOAD_EXCEL': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({ error: 'No tab ID' }); return; }
      restoreFromSession(tid).then(async s => {
        try {
          const posts = applyDateFilter(Array.from(s.posts.values()), s);
          if (posts.length === 0) { sendResponse({ error: 'No posts to export' }); return; }
          const thumbData = await Promise.all(posts.map(p => fetchThumbBase64(p.thumbnailUrl)));
          const xlsxBytes = generateXLSX(posts, thumbData);
          const date = new Date().toISOString().slice(0, 10);
          const handle = (s.handle || 'posts').replace(/[^a-zA-Z0-9._-]/g, '_');
          const filename = `${s.platform || 'social'}-${handle}-${date}.xlsx`;
          const url = binaryToDataUrl(xlsxBytes, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
          chrome.downloads.download({ url, filename, saveAs: false }, (dlId) => {
            if (chrome.runtime.lastError) { sendResponse({ error: chrome.runtime.lastError.message }); return; }
            sendResponse({ downloadId: dlId, postCount: posts.length });
          });
        } catch (err) {
          sendResponse({ error: 'Export failed: ' + err.message });
        }
      }).catch(err => sendResponse({ error: 'Session error: ' + err.message }));
      return true;
    }

    case 'DOWNLOAD_MEDIA_BULK': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({ error: 'No tab ID' }); return; }
      restoreFromSession(tid).then(s => {
        try {
          const posts = applyDateFilter(Array.from(s.posts.values()), s);
          const items = [];
          const headers = PLATFORM_HEADERS[s.platform] || [];
          for (const post of posts) {
            const isVideoPost = post.mediaType === 'video' || post.mediaType === 'reel';
            const urls = post.carouselUrls?.length > 0 ? post.carouselUrls : (post.mediaUrl ? [post.mediaUrl] : []);
            urls.forEach((url, idx) => {
              if (!url) return;
              const fileId = (post.carouselIds?.[idx]) || (urls.length > 1 ? `${post.postId}_${idx + 1}` : post.postId);
              items.push({
                postId: fileId,
                mediaUrl: url,
                filename: buildFilename(s.platform || 'social', s.handle || 'unknown', fileId, 0, url, isVideoPost),
                platform: s.platform,
                headers,
              });
            });
          }
          if (items.length === 0) { sendResponse({ error: 'No media URLs found to download' }); return; }
          DownloadQueue.enqueue(items, tid);
          sendResponse({ status: 'started', total: items.length });
        } catch (err) {
          sendResponse({ error: 'Download failed: ' + err.message });
        }
      }).catch(err => sendResponse({ error: 'Session error: ' + err.message }));
      return true;
    }

    case 'DOWNLOAD_MEDIA_SINGLE': {
      const tid = msg.tabId || tabId; // tabId includes sender.tab?.id for content-script calls
      if (!tid) { sendResponse({ error: 'No tab ID' }); return; }
      const s = getState(tid);
      const platform = msg.platform || s.platform || 'social';
      const handle = msg.handle || s.handle || 'unknown';
      const headers = PLATFORM_HEADERS[platform] || [];
      // msg.slides is an array for carousels; fall back to single-item legacy shape
      const slideList = msg.slides || [{ url: msg.mediaUrl, id: msg.postId }];
      const folder = (msg.saveFolder || '').trim().replace(/[\\:*?"<>|]/g, '');
      const items = slideList.map(slide => {
        const base = buildFilename(platform, handle, slide.id, 0, slide.url, slide.isVideo);
        return {
          postId:   slide.id,
          mediaUrl: slide.url,
          filename: base,
          // _filename overrides the default path inside _processNext
          _filename: folder ? `${folder}/${base}` : null,
          platform,
          headers,
        };
      });
      DownloadQueue.enqueue(items, tid);
      sendResponse({ status: 'started', total: items.length });
      break;
    }

    case 'GET_DOWNLOAD_PROGRESS': {
      const tid = tabId;
      sendResponse(DownloadQueue.getProgress(tid));
      break;
    }

    case 'DOWNLOAD_SELECTION_ZIP': {
      const tid = msg.tabId || tabId;
      if (!tid) { sendResponse({ error: 'No tab ID' }); return; }
      const slideList = msg.slides || [];
      const handle    = (msg.handle || 'instagram').replace(/[^a-zA-Z0-9._-]/g, '_');
      const zipName   = (msg.zipName || handle).replace(/[\\/:*?"<>|]/g, '_') || handle;
      if (!slideList.length) { sendResponse({ error: 'No slides' }); return; }

      sendResponse({ status: 'started', total: slideList.length });

      (async () => {
        DownloadQueue._progress.set(tid, { total: slideList.length, completed: 0, failed: 0, percent: 0, currentFilename: '', zipMode: true });
        DownloadQueue._saveProgress(tid);

        const entries = [];
        for (let i = 0; i < slideList.length; i++) {
          const slide = slideList[i];
          try {
            const resp = await fetch(slide.url);
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const buf = new Uint8Array(await resp.arrayBuffer());
            // Detect MP4 by 'ftyp' box at offset 4 — reliable for all Instagram videos
            const isMp4 = buf.length > 11 &&
              buf[4] === 0x66 && buf[5] === 0x74 && buf[6] === 0x79 && buf[7] === 0x70;
            const ext = isMp4 || slide.isVideo ? 'mp4' : 'jpg';
            entries.push({ name: `instagram-${handle}-${slide.id}.${ext}`, data: buf });
          } catch (err) {
            console.warn('[ZIP] fetch failed for', slide.url, err?.message);
          }
          const done = i + 1;
          DownloadQueue._progress.set(tid, { total: slideList.length, completed: done, failed: 0, percent: Math.round(done / slideList.length * 95), currentFilename: slide.id, zipMode: true });
          DownloadQueue._saveProgress(tid);
        }

        if (!entries.length) {
          DownloadQueue._progress.set(tid, { total: slideList.length, completed: 0, failed: slideList.length, percent: 100, currentFilename: 'Error', zipMode: false });
          DownloadQueue._saveProgress(tid);
          return;
        }

        const zipBytes = buildZip(entries);
        const dataUrl  = binaryToDataUrl(zipBytes, 'application/zip');
        const filename = `${zipName}.zip`;

        chrome.downloads.download({ url: dataUrl, filename, saveAs: true, conflictAction: 'uniquify' }, dlId => {
          const success = dlId != null && !chrome.runtime.lastError;
          DownloadQueue._progress.set(tid, { total: slideList.length, completed: success ? slideList.length : 0, failed: success ? 0 : slideList.length, percent: 100, currentFilename: filename, zipMode: false });
          DownloadQueue._saveProgress(tid);
        });
      })().catch(err => {
        console.error('[DOWNLOAD_SELECTION_ZIP] error:', err);
        DownloadQueue._progress.set(tid, { total: slideList.length, completed: 0, failed: slideList.length, percent: 100, currentFilename: 'Error', zipMode: false });
        DownloadQueue._saveProgress(tid);
      });

      return; // sendResponse already called above
    }

    case 'DOWNLOAD_ZIP': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({ error: 'No tab ID' }); return; }
      restoreFromSession(tid).then(async s => {
        try {
          let posts = applyDateFilter(Array.from(s.posts.values()), s);
          if (msg.videosOnly) posts = posts.filter(p => p.mediaType === 'video' || p.mediaType === 'reel');
          if (posts.length === 0) { sendResponse({ error: 'No posts found' }); return; }

          const items = [];
          for (const post of posts) {
            const isVideoPost = post.mediaType === 'video' || post.mediaType === 'reel';
            const urls = post.carouselUrls?.length > 0 ? post.carouselUrls : (post.mediaUrl ? [post.mediaUrl] : []);
            urls.forEach((url, idx) => {
              if (!url) return;
              const fileId = (post.carouselIds?.[idx]) || (urls.length > 1 ? `${post.postId}_${idx + 1}` : post.postId);
              items.push({ filename: buildFilename(s.platform || 'social', s.handle || 'unknown', fileId, 0, url, isVideoPost), mediaUrl: url });
            });
          }

          chrome.storage.session.set({
            [`zip_${tid}`]: { total: items.length, done: 0 },
            [`zip_cancel_${tid}`]: false
          });

          const igHeaders = { Referer: 'https://www.instagram.com/' };
          const entries = [];
          let done = 0;
          const isZipCancelled = () => new Promise(resolve => {
            chrome.storage.session.get(`zip_cancel_${tid}`, r => resolve(Boolean(r[`zip_cancel_${tid}`])));
          });
          for (const item of items) {
            if (await isZipCancelled()) {
              chrome.storage.session.remove(`zip_cancel_${tid}`);
              sendResponse({ error: 'Download stopped' });
              return;
            }
            try {
              const resp = await fetch(item.mediaUrl, { headers: igHeaders });
              if (await isZipCancelled()) {
                chrome.storage.session.remove(`zip_cancel_${tid}`);
                sendResponse({ error: 'Download stopped' });
                return;
              }
              if (resp.ok) {
                const buf = new Uint8Array(await resp.arrayBuffer());
                // Correct extension by magic bytes (MP4 = 'ftyp' at offset 4)
                const isMp4 = buf.length > 11 &&
                  buf[4] === 0x66 && buf[5] === 0x74 && buf[6] === 0x79 && buf[7] === 0x70;
                const name = isMp4 ? item.filename.replace(/\.(jpg|jpeg|png|webp)$/i, '.mp4') : item.filename;
                entries.push({ name, data: buf });
              }
            } catch (_) { /* skip unreachable files */ }
            chrome.storage.session.set({ [`zip_${tid}`]: { total: items.length, done: ++done } });
          }
          chrome.storage.session.remove(`zip_cancel_${tid}`);

          if (entries.length === 0) { sendResponse({ error: 'No downloadable files found (CORS blocked or URLs expired)' }); return; }

          const zipData = buildZip(entries);
          const dataUrl = binaryToDataUrl(zipData, 'application/zip');
          const date    = new Date().toISOString().slice(0, 10);
          const handle  = (s.handle || 'posts').replace(/[^a-zA-Z0-9._-]/g, '_');
          chrome.downloads.download({ url: dataUrl, filename: `social-scraper-${handle}-${date}.zip`, saveAs: false }, () => {
            if (chrome.runtime.lastError) { sendResponse({ error: chrome.runtime.lastError.message }); return; }
            sendResponse({ status: 'ok', fileCount: entries.length });
          });
        } catch (err) {
          sendResponse({ error: 'ZIP failed: ' + err.message });
        }
      }).catch(err => sendResponse({ error: 'Session error: ' + err.message }));
      return true;
    }

    case 'GET_DOWNLOAD_ITEMS': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({ error: 'No tab ID' }); return; }
      restoreFromSession(tid).then(s => {
        try {
          let posts = applyDateFilter(Array.from(s.posts.values()), s);
          if (msg.videosOnly) posts = posts.filter(p => p.mediaType === 'video' || p.mediaType === 'reel');
          const items = [];
          for (const post of posts) {
            const isVideoPost = post.mediaType === 'video' || post.mediaType === 'reel';
            const urls = post.carouselUrls?.length > 0 ? post.carouselUrls : (post.mediaUrl ? [post.mediaUrl] : []);
            urls.forEach((url, idx) => {
              if (!url) return;
              const fileId = (post.carouselIds?.[idx]) || (urls.length > 1 ? `${post.postId}_${idx + 1}` : post.postId);
              items.push({ filename: buildFilename(s.platform || 'social', s.handle || 'unknown', fileId, 0, url, isVideoPost), mediaUrl: url });
            });
          }
          sendResponse({ items });
        } catch (err) {
          sendResponse({ error: 'Failed to get items: ' + err.message });
        }
      }).catch(err => sendResponse({ error: 'Session error: ' + err.message }));
      return true;
    }

    case 'FETCH_REEL_PAGE': {
      // Fetch the reel's own page FROM THE BACKGROUND SW — this bypasses Instagram's
      // service worker and hits Instagram's actual server, which always returns full SSR
      // with the video_url for the reel.
      const { shortcode: sc } = msg;
      if (!sc) { sendResponse({ slides: null }); return; }
      (async () => {
        try {
          const resp = await fetch(
            'https://www.instagram.com/reel/' + sc + '/',
            {
              credentials: 'include',
              headers: {
                Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                Referer: 'https://www.instagram.com/',
              },
            }
          );
          const html = await resp.text();

          const decodeUrl = (raw) => {
            try { return JSON.parse('"' + raw + '"'); }
            catch (_) { return raw.replace(/\\\//g, '/').replace(/\\u0026/g, '&'); }
          };

          // Try SSR JSON shapes used by reels: video_url or video_versions[].url
          let mVid = /"video_url"\s*:\s*"(https:[^"]+)"/.exec(html);
          if (!mVid) {
            mVid = /"video_versions"\s*:\s*\[[\s\S]*?"url"\s*:\s*"(https:[^"]+)"/.exec(html);
          }
          if (mVid) {
            const videoUrl = decodeUrl(mVid[1]);
            sendResponse({ slides: [{ url: videoUrl, id: sc, isVideo: true }] });
            return;
          }

          // Fallback: og:video meta tag
          const rxOg = /property="og:video(?::secure_url)?"\s+content="([^"]+)"|content="([^"]+)"\s+property="og:video(?::secure_url)?"/i;
          const mOg  = rxOg.exec(html);
          if (mOg) {
            sendResponse({ slides: [{ url: mOg[1] || mOg[2], id: sc, isVideo: true }] });
            return;
          }

          sendResponse({ slides: null });
        } catch (err) {
          sendResponse({ slides: null });
        }
      })();
      return true;
    }

    case 'FETCH_IG_MEDIA_INFO': {
      // Run the fetch inside the page's MAIN world so the request has
      // Origin: https://www.instagram.com instead of the extension origin.
      const { shortcode, mediaId: passedId, csrf: csrfToken, wwwClaim } = msg;
      if (!shortcode || !csrfToken || !tabId) { sendResponse({ slides: null }); return; }

      const mediaId = passedId || scToId(shortcode);

      chrome.scripting.executeScript(
        {
          target: { tabId },
          world:  'MAIN',
          func: async (mediaId, csrfToken, wwwClaim) => {
            const hdrs = {
              'X-CSRFToken':      csrfToken,
              'X-IG-App-ID':      '936619743392459',
              'X-Requested-With': 'XMLHttpRequest',
              'X-IG-WWW-Claim':   wwwClaim || '0',
              'Accept':           'application/json',
            };
            const get = (url) => fetch(url, { credentials: 'include', headers: hdrs })
              .then(r => r.ok ? r.json() : null).catch(() => null);
            return await get(`https://www.instagram.com/api/v1/media/${mediaId}/info/`);
          },
          args: [mediaId, csrfToken, wwwClaim || '0'],
        },
        (results) => {
          if (chrome.runtime.lastError || !results?.[0]?.result) {
            sendResponse({ slides: null });
            return;
          }
          const item = results[0].result?.items?.[0];
          if (!item) { sendResponse({ slides: null }); return; }
          const rawSlides = item.carousel_media?.length ? item.carousel_media : [item];
          const slides = rawSlides.map(s => {
            const videoUrl = s.video_url || s.video_versions?.[0]?.url;
            const url = videoUrl || s.image_versions2?.candidates?.[0]?.url;
            if (!url) return null;
            return { url, id: String(s.pk || s.id), isVideo: !!videoUrl };
          }).filter(Boolean);
          sendResponse({ slides: slides.length ? slides : null });
        }
      );
      return true;
    }

    case 'CANCEL_DOWNLOADS': {
      const tid = msg.tabId;
      if (tid) {
        DownloadQueue.cancel(tid);
        chrome.storage.session.set({ [`zip_cancel_${tid}`]: true });
      }
      sendResponse({ status: 'cancelled' });
      break;
    }

    case 'SET_DATE_FILTER': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({}); return; }
      const s = getState(tid);
      s.dateFilterFrom = msg.fromDate || null;
      s.dateFilterTo   = msg.toDate   || null;
      saveStateToSession(tid);
      sendResponse({ status: 'filter_set' });
      break;
    }

    case 'DOWNLOAD_VIDEOS_ONLY': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({ error: 'No tab ID' }); return; }
      restoreFromSession(tid).then(s => {
        const posts = applyDateFilter(Array.from(s.posts.values()), s)
          .filter(p => p.mediaType === 'video' || p.mediaType === 'reel');
        if (posts.length === 0) { sendResponse({ error: 'No videos found in the selection' }); return; }
        const items = [];
        const headers = PLATFORM_HEADERS[s.platform] || [];
        for (const post of posts) {
          const urls = post.carouselUrls?.length > 0 ? post.carouselUrls : (post.mediaUrl ? [post.mediaUrl] : []);
          urls.forEach((url, idx) => {
            if (!url) return;
            const fileId = (post.carouselIds?.[idx]) || (urls.length > 1 ? `${post.postId}_${idx + 1}` : post.postId);
            items.push({
              postId: fileId,
              mediaUrl: url,
              filename: buildFilename(s.platform || 'social', s.handle || 'unknown', fileId, 0, url, true), // always video here
              platform: s.platform,
              headers,
            });
          });
        }
        if (items.length === 0) { sendResponse({ error: 'No video URLs found' }); return; }
        DownloadQueue.enqueue(items, tid);
        sendResponse({ status: 'started', total: items.length });
      });
      return true;
    }

    case 'CLEAR_DATA': {
      const tid = msg.tabId;
      if (!tid) { sendResponse({}); return; }
      tabState.delete(tid);
      chrome.alarms.clear(`${IG_ALARM_PREFIX}${tid}`);
      chrome.storage.session.remove([`tab_${tid}`, `${IG_ALARM_PREFIX}${tid}`]);
      sendResponse({ status: 'cleared' });
      break;
    }
  }

  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  tabState.delete(tabId);
  chrome.alarms.clear(`${IG_ALARM_PREFIX}${tabId}`);
  chrome.storage.session.remove([`tab_${tabId}`, `dl_progress_${tabId}`, `zip_${tabId}`, `${IG_ALARM_PREFIX}${tabId}`]);
});

// Clear tab state when the user navigates to a different profile (SPA navigation).
// Never wipe state while an extraction is running — Instagram may push URL changes
// (e.g. opening a post) that don't represent a profile switch.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (!changeInfo.url) return;
  const s = tabState.get(tabId);
  if (!s || !s.handle) return;
  if (s.isExtracting) return; // don't disrupt active extraction
  const detected = PlatformDetector.detect(changeInfo.url);
  if (!detected || detected.handle !== s.handle || detected.platform !== s.platform) {
    // Also check the alarm cursor — protects against SW-restart race where
    // isExtracting hasn't been re-armed yet but extraction is still running
    chrome.storage.session.get(`${IG_ALARM_PREFIX}${tabId}`, (r) => {
      const alarmEs = r[`${IG_ALARM_PREFIX}${tabId}`];
      if (alarmEs && !alarmEs.stopped) return; // extraction still running
      tabState.delete(tabId);
      chrome.storage.session.remove([`tab_${tabId}`, `dl_progress_${tabId}`, `zip_${tabId}`]);
    });
  }
});
