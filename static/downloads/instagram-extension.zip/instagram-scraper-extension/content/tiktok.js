// content/tiktok.js - TikTok scraper

(function () {
  'use strict';

  let isExtracting = false;
  let stopRequested = false;

  function getHandle() {
    const m = window.location.pathname.match(/^\/@([a-zA-Z0-9._]+)\/?$/);
    return m ? m[1] : null;
  }

  function getSecUid() {
    // Try SIGI_STATE (most reliable)
    try {
      const el = document.getElementById('SIGI_STATE');
      if (el) {
        const state = JSON.parse(el.textContent || '{}');
        const users = state?.UserModule?.users || state?.userModule?.users || {};
        for (const key of Object.keys(users)) {
          if (users[key]?.secUid) return users[key].secUid;
        }
      }
    } catch (e) {}

    // Try __NEXT_DATA__
    try {
      const nd = window.__NEXT_DATA__;
      const secUid = nd?.props?.pageProps?.userInfo?.user?.secUid;
      if (secUid) return secUid;
    } catch (e) {}

    // Try __UNIVERSAL_DATA__
    try {
      const ud = window.__UNIVERSAL_DATA__;
      const webappData = ud?.['webapp.user-detail']?.userInfo?.user;
      if (webappData?.secUid) return webappData.secUid;
    } catch (e) {}

    // Scan scripts for secUid pattern
    try {
      for (const script of document.querySelectorAll('script')) {
        const m = (script.textContent || '').match(/"secUid"\s*:\s*"([^"]{20,})"/);
        if (m) return m[1];
      }
    } catch (e) {}

    return null;
  }

  async function fetchPage(secUid, cursor) {
    const params = new URLSearchParams({
      secUid,
      count: '30',
      cursor: String(cursor || 0),
      aid: '1988',
      app_language: 'en',
    });
    const resp = await fetch(`https://www.tiktok.com/api/post/item_list/?${params}`, {
      headers: { 'Accept': '*/*' },
      credentials: 'include',
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    return resp.json();
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function runExtraction(handle) {
    isExtracting = true;
    stopRequested = false;
    try {
      chrome.runtime.sendMessage({ type: 'EXTRACTION_STARTED', platform: 'tiktok', handle });

      const secUid = getSecUid();
      if (!secUid) throw new Error('Could not find secUid — please refresh the TikTok profile page and try again.');

      let cursor = 0, hasMore = true, emptyPages = 0;

      while (hasMore && !stopRequested) {
        const data = await fetchPage(secUid, cursor);
        const items = data?.itemList || data?.item_list || [];

        if (items.length > 0) {
          emptyPages = 0;
          await new Promise(resolve => {
            chrome.runtime.sendMessage({ type: 'POST_DATA', platform: 'tiktok', handle, data: { items } }, resolve);
          });
        } else { emptyPages++; }

        hasMore = !!data?.hasMore;
        cursor = data?.nextCursor || data?.cursor || 0;
        if (emptyPages >= 3 || !hasMore) break;
        await sleep(1500 + Math.random() * 700);
      }

      chrome.runtime.sendMessage({ type: 'EXTRACTION_COMPLETE', platform: 'tiktok' });
    } catch (err) {
      chrome.runtime.sendMessage({ type: 'EXTRACTION_ERROR', error: err.message });
    } finally { isExtracting = false; }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {
      case 'START_EXTRACTION':
        if (isExtracting) { sendResponse({ status: 'already_running' }); return; }
        const handle = getHandle();
        if (!handle) { sendResponse({ error: 'No TikTok handle in URL' }); return; }
        runExtraction(handle);
        sendResponse({ status: 'started' });
        break;
      case 'STOP_EXTRACTION':
        stopRequested = true; isExtracting = false;
        sendResponse({ status: 'stopped' });
        break;
      case 'GET_PAGE_INFO':
        sendResponse({ handle: getHandle(), url: window.location.href, platform: 'tiktok' });
        break;
      case 'PING': sendResponse({ status: 'alive' }); break;
    }
    return true;
  });
})();
