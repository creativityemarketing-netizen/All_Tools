// instagram-ui.js — Injects a per-post download button on Instagram feed & reel pages

(function () {
  'use strict';

  const BTN_CLASS = 'scs-dl-btn';
  const B62 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';

  // ── Styles ──────────────────────────────────────────────────────────────────
  const style = document.createElement('style');
  style.textContent = `
    .${BTN_CLASS} {
      position: absolute;
      top: 8px;
      right: 8px;
      z-index: 9999;
      width: 36px;
      height: 36px;
      background: rgba(0,0,0,0.55);
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0.65;
      transition: opacity 0.18s, background 0.18s, transform 0.12s;
      backdrop-filter: blur(4px);
      -webkit-backdrop-filter: blur(4px);
    }
    .${BTN_CLASS}-wrap:hover .${BTN_CLASS},
    .${BTN_CLASS}:hover,
    .${BTN_CLASS}:focus { opacity: 1; }
    .${BTN_CLASS}:hover { background: rgba(0,149,246,0.85); transform: scale(1.1); }
    .${BTN_CLASS}.scs-done     { background: rgba(76,175,80,0.85);  opacity: 1 !important; }
    .${BTN_CLASS}.scs-error    { background: rgba(237,73,86,0.85);  opacity: 1 !important; }
    .${BTN_CLASS}.scs-spin     { opacity: 1 !important; animation: scs-spin 0.7s linear infinite; }
    .${BTN_CLASS}.scs-selected { background: rgba(0,149,246,0.9) !important; opacity: 1 !important; transform: scale(1.08); }
    @keyframes scs-spin { to { transform: rotate(360deg); } }
    .${BTN_CLASS} svg { pointer-events: none; }
    .${BTN_CLASS}-fixed { position: fixed !important; z-index: 99999 !important; }

    /* ── Select-mode floating controls ── */
    .scs-select-toggle {
      position: fixed;
      top: 64px;
      right: 16px;
      z-index: 999999;
      height: 36px;
      padding: 0 14px;
      background: rgba(30,30,30,0.88);
      border: 1.5px solid rgba(255,255,255,0.18);
      border-radius: 18px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      color: #fff;
      font-size: 12px;
      font-weight: 600;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      backdrop-filter: blur(6px);
      -webkit-backdrop-filter: blur(6px);
      transition: background 0.18s, transform 0.12s, border-color 0.18s;
      box-shadow: 0 2px 10px rgba(0,0,0,0.4);
      white-space: nowrap;
    }
    .scs-select-toggle:hover { transform: scale(1.05); border-color: rgba(255,255,255,0.4); }
    .scs-select-toggle.active { background: rgba(0,149,246,0.92); border-color: transparent; }
    .scs-select-toggle svg { pointer-events: none; }

    .scs-dl-selected-btn {
      position: fixed;
      top: 108px;
      right: 16px;
      z-index: 999999;
      height: 44px;
      padding: 0 18px;
      background: rgba(0,149,246,0.93);
      border: none;
      border-radius: 22px;
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
      gap: 7px;
      color: #fff;
      font-size: 13px;
      font-weight: 700;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      backdrop-filter: blur(6px);
      -webkit-backdrop-filter: blur(6px);
      transition: background 0.18s, transform 0.12s;
      box-shadow: 0 3px 12px rgba(0,0,0,0.35);
      white-space: nowrap;
    }
    .scs-dl-selected-btn:hover { background: rgba(0,118,210,0.97); transform: scale(1.04); }
    .scs-dl-selected-btn svg { pointer-events: none; }

    /* ── Batch download progress bar ── */
    .scs-dl-progress {
      position: fixed;
      bottom: 16px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 999999;
      background: rgba(18,18,18,0.94);
      border-radius: 28px;
      padding: 10px 20px;
      display: none;
      align-items: center;
      gap: 12px;
      color: #fff;
      font-size: 13px;
      font-weight: 600;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      box-shadow: 0 4px 20px rgba(0,0,0,0.45);
      min-width: 220px;
      pointer-events: none;
    }
    .scs-dl-progress-track {
      flex: 1;
      height: 5px;
      background: rgba(255,255,255,0.18);
      border-radius: 3px;
      min-width: 80px;
      overflow: hidden;
    }
    .scs-dl-progress-fill {
      height: 100%;
      background: #0095f6;
      border-radius: 3px;
      transition: width 0.35s ease;
      width: 0%;
    }
    .scs-dl-progress-fill.done { background: #4caf50; }

    /* ── Folder-picker modal ── */
    .scs-modal-overlay {
      position: fixed; inset: 0; z-index: 9999999;
      background: rgba(0,0,0,0.65);
      display: flex; align-items: center; justify-content: center;
      backdrop-filter: blur(5px); -webkit-backdrop-filter: blur(5px);
    }
    .scs-modal-overlay.scs-hidden { display: none; }
    .scs-modal {
      background: #1c1c1c;
      border-radius: 18px;
      padding: 28px 24px 20px;
      width: 340px;
      box-shadow: 0 12px 40px rgba(0,0,0,0.7);
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }
    .scs-modal-title { font-size: 16px; font-weight: 700; margin-bottom: 6px; }
    .scs-modal-sub   { font-size: 12px; color: #888; margin-bottom: 20px; }
    .scs-modal-label { font-size: 12px; color: #aaa; display: block; margin-bottom: 8px; }
    .scs-modal-row {
      display: flex; align-items: center;
      background: rgba(255,255,255,0.07);
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 10px; padding: 9px 12px; gap: 6px; margin-bottom: 22px;
    }
    .scs-modal-prefix { font-size: 12px; color: #666; white-space: nowrap; }
    .scs-modal-input {
      background: none; border: none; outline: none;
      color: #fff; font-size: 13px; flex: 1; min-width: 0;
    }
    .scs-modal-actions { display: flex; gap: 10px; justify-content: flex-end; }
    .scs-modal-cancel {
      padding: 9px 18px; background: rgba(255,255,255,0.09);
      border: none; border-radius: 9px; color: #fff; cursor: pointer; font-size: 13px;
    }
    .scs-modal-cancel:hover { background: rgba(255,255,255,0.16); }
    .scs-modal-files {
      padding: 9px 16px; background: #0095f6;
      border: none; border-radius: 9px; color: #fff;
      cursor: pointer; font-size: 13px; font-weight: 700;
    }
    .scs-modal-files:hover { background: #0082d9; }
    .scs-modal-zip {
      padding: 9px 16px; background: rgba(255,255,255,0.13);
      border: 1.5px solid rgba(255,255,255,0.22); border-radius: 9px; color: #fff;
      cursor: pointer; font-size: 13px; font-weight: 700;
    }
    .scs-modal-zip:hover { background: rgba(255,255,255,0.22); }

    /* Account caption search */
    .scs-search-panel {
      position: fixed;
      top: 154px;
      right: 16px;
      z-index: 9999998;
      width: min(360px, calc(100vw - 32px));
      height: min(520px, calc(100vh - 178px));
      min-width: 280px;
      min-height: 150px;
      max-width: calc(100vw - 32px);
      max-height: calc(100vh - 178px);
      background: rgba(18,18,18,0.94);
      border: 1px solid rgba(255,255,255,0.16);
      border-radius: 12px;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      box-shadow: 0 8px 28px rgba(0,0,0,0.45);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      overflow: hidden;
      display: flex;
      flex-direction: column;
    }
    .scs-search-panel.scs-collapsed {
      width: 240px !important;
      height: 42px !important;
      min-width: 0 !important;
      min-height: 0 !important;
      max-height: none !important;
    }
    .scs-search-panel.scs-collapsed .scs-search-body,
    .scs-search-panel.scs-collapsed .scs-search-resize { display: none; }
    .scs-search-head {
      height: 42px;
      padding: 0 10px 0 12px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .scs-search-title { font-size: 13px; font-weight: 700; white-space: nowrap; }
    .scs-search-min {
      width: 28px;
      height: 28px;
      border: none;
      border-radius: 50%;
      color: #fff;
      background: rgba(255,255,255,0.08);
      cursor: pointer;
      font-size: 18px;
      line-height: 1;
    }
    .scs-search-min:hover { background: rgba(255,255,255,0.16); }
    .scs-search-body {
      padding: 10px;
      display: flex;
      flex-direction: column;
      min-height: 0;
      flex: 1;
    }
    .scs-search-form { display: flex; gap: 8px; }
    .scs-search-input {
      flex: 1;
      min-width: 0;
      height: 36px;
      padding: 0 11px;
      border: 1px solid rgba(255,255,255,0.14);
      border-radius: 8px;
      outline: none;
      background: rgba(255,255,255,0.08);
      color: #fff;
      font-size: 13px;
    }
    .scs-search-input:focus { border-color: rgba(0,149,246,0.8); }
    .scs-search-run,
    .scs-search-stop {
      height: 36px;
      padding: 0 12px;
      border: none;
      border-radius: 8px;
      color: #fff;
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      white-space: nowrap;
    }
    .scs-search-run { background: #0095f6; }
    .scs-search-run:hover { background: #0082d9; }
    .scs-search-run:disabled { cursor: default; opacity: 0.55; }
    .scs-search-stop { display: none; background: rgba(237,73,86,0.9); }
    .scs-search-status {
      margin-top: 8px;
      color: #bdbdbd;
      font-size: 12px;
      min-height: 17px;
    }
    .scs-search-results {
      margin-top: 10px;
      min-height: 0;
      flex: 1;
      overflow: auto;
      display: grid;
      align-content: start;
      gap: 8px;
    }
    .scs-search-empty {
      padding: 14px 4px;
      color: #aaa;
      font-size: 13px;
      text-align: center;
    }
    .scs-search-result {
      display: grid;
      grid-template-columns: 74px minmax(0, 1fr);
      gap: 10px;
      padding: 8px;
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 8px;
      color: #fff;
      text-decoration: none;
      background: rgba(255,255,255,0.055);
    }
    .scs-search-result:hover { background: rgba(255,255,255,0.1); border-color: rgba(0,149,246,0.5); }
    .scs-search-thumb {
      width: 74px;
      height: 74px;
      object-fit: cover;
      border-radius: 6px;
      background: rgba(255,255,255,0.08);
    }
    .scs-search-meta {
      display: flex;
      gap: 8px;
      align-items: center;
      margin-bottom: 4px;
      color: #aaa;
      font-size: 11px;
      min-width: 0;
    }
    .scs-search-type {
      padding: 2px 6px;
      border-radius: 999px;
      background: rgba(0,149,246,0.18);
      color: #9bd8ff;
      font-weight: 700;
    }
    .scs-search-date { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .scs-search-caption {
      color: #f2f2f2;
      font-size: 12px;
      line-height: 1.35;
      overflow-wrap: anywhere;
    }
    .scs-search-mark {
      background: #ffd84d;
      color: #111;
      border-radius: 3px;
      padding: 0 2px;
      font-weight: 700;
    }
    .scs-search-resize {
      position: absolute;
      z-index: 2;
    }
    .scs-search-resize-left {
      left: 0;
      top: 42px;
      bottom: 18px;
      width: 10px;
      cursor: ew-resize;
    }
    .scs-search-resize-right {
      right: 0;
      top: 42px;
      bottom: 18px;
      width: 10px;
      cursor: ew-resize;
    }
    .scs-search-resize-bottom {
      left: 18px;
      right: 18px;
      bottom: 0;
      height: 10px;
      cursor: ns-resize;
    }
    .scs-search-resize-bl,
    .scs-search-resize-br {
      bottom: 0;
      width: 24px;
      height: 24px;
      cursor: nesw-resize;
    }
    .scs-search-resize-bl { left: 0; }
    .scs-search-resize-br {
      right: 0;
      cursor: nwse-resize;
    }
    .scs-search-resize-br::before {
      content: '';
      position: absolute;
      right: 5px;
      bottom: 5px;
      width: 10px;
      height: 10px;
      border-right: 2px solid rgba(255,255,255,0.72);
      border-bottom: 2px solid rgba(255,255,255,0.72);
    }
    .scs-search-resize-left:hover,
    .scs-search-resize-right:hover,
    .scs-search-resize-bottom:hover,
    .scs-search-resize-bl:hover,
    .scs-search-resize-br:hover { background: rgba(0,149,246,0.12); }
    .scs-search-panel.scs-inverse-light {
      background: rgba(255,255,255,0.97);
      border-color: rgba(0,0,0,0.18);
      color: #111;
      box-shadow: 0 8px 28px rgba(0,0,0,0.25);
    }
    .scs-search-panel.scs-inverse-light .scs-search-head { border-bottom-color: rgba(0,0,0,0.12); }
    .scs-search-panel.scs-inverse-light .scs-search-min {
      color: #111;
      background: rgba(0,0,0,0.08);
    }
    .scs-search-panel.scs-inverse-light .scs-search-min:hover { background: rgba(0,0,0,0.14); }
    .scs-search-panel.scs-inverse-light .scs-search-input {
      background: rgba(0,0,0,0.055);
      border-color: rgba(0,0,0,0.2);
      color: #111;
    }
    .scs-search-panel.scs-inverse-light .scs-search-status,
    .scs-search-panel.scs-inverse-light .scs-search-empty,
    .scs-search-panel.scs-inverse-light .scs-search-meta { color: #555; }
    .scs-search-panel.scs-inverse-light .scs-search-result {
      background: rgba(0,0,0,0.045);
      border-color: rgba(0,0,0,0.12);
      color: #111;
    }
    .scs-search-panel.scs-inverse-light .scs-search-result:hover {
      background: rgba(0,0,0,0.08);
      border-color: rgba(0,149,246,0.6);
    }
    .scs-search-panel.scs-inverse-light .scs-search-thumb { background: rgba(0,0,0,0.08); }
    .scs-search-panel.scs-inverse-light .scs-search-caption { color: #111; }
    .scs-search-panel.scs-inverse-light .scs-search-type {
      background: rgba(0,149,246,0.16);
      color: #005f99;
    }
    .scs-search-panel.scs-inverse-light .scs-search-resize-br::before {
      border-right-color: rgba(0,0,0,0.5);
      border-bottom-color: rgba(0,0,0,0.5);
    }
  `;
  document.head.appendChild(style);

  // ── Icons ────────────────────────────────────────────────────────────────────
  const ICON_DL = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="white">
    <path d="M12 15.586l-4.293-4.293-1.414 1.414L12 18.414l5.707-5.707-1.414-1.414L13 15.586V4h-2v11.586z"/>
    <path d="M5 20h14v2H5z"/>
  </svg>`;
  const ICON_DL_SM = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="white">
    <path d="M12 15.586l-4.293-4.293-1.414 1.414L12 18.414l5.707-5.707-1.414-1.414L13 15.586V4h-2v11.586z"/>
    <path d="M5 20h14v2H5z"/>
  </svg>`;
  const ICON_SPIN = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round">
    <circle cx="12" cy="12" r="9" stroke-opacity="0.3"/>
    <path d="M12 3a9 9 0 0 1 9 9"/>
  </svg>`;
  const ICON_OK = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>`;
  const ICON_ERR = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round">
    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
  </svg>`;
  // Checkbox icon for the select-mode toggle button
  const ICON_SELECT = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <rect x="3" y="3" width="18" height="18" rx="3" ry="3"/>
    <polyline points="9 12 11 14 15 10"/>
  </svg>`;
  // Filled checkmark for selected post buttons
  const ICON_CHECK = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="white">
    <path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/>
  </svg>`;

  // ── Interceptor cache (populated by injector.js) ────────────────────────────
  // injector.js (MAIN world, document_start) writes shortcode→slides into a
  // hidden DOM <script id="__scs_ig_cache"> element AND fires __scs_post_cached
  // events. We read the element at startup to catch entries cached before this
  // content script loaded (document_idle), then listen for new events.
  const postCache = new Map();
  try {
    const el = document.getElementById('__scs_ig_cache');
    if (el?.textContent) {
      const obj = JSON.parse(el.textContent);
      for (const [sc, slides] of Object.entries(obj)) {
        if (sc && Array.isArray(slides) && slides.length) postCache.set(sc, slides);
      }
    }
  } catch (_) {}
  console.log('[SCS-DBG] postCache loaded from DOM:', postCache.size, 'items');
  document.addEventListener('__scs_post_cached', e => {
    try {
      const { shortcode, slides } = JSON.parse(e.detail);
      if (shortcode && slides?.length) {
        postCache.set(shortcode, slides);
        console.log('[SCS-DBG] event: cached', shortcode, '| total:', postCache.size);
      }
    } catch (_) {}
  });

  // ── Selection state ──────────────────────────────────────────────────────────
  let selectMode = false;
  // key (shortcode or fallback timestamp) → { key, slides: [{url, id}], handle }
  const selection = new Map();

  // ── Helpers ──────────────────────────────────────────────────────────────────

  function scToId(sc) {
    let n = BigInt(0);
    for (const c of sc) {
      const i = B62.indexOf(c);
      if (i >= 0) n = n * 64n + BigInt(i);
    }
    return n.toString();
  }

  function csrf() {
    return (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';
  }

  function getHandle() {
    const m = window.location.pathname.match(/^\/([a-zA-Z0-9._]+)/);
    return m ? m[1] : 'unknown';
  }

  function getShortcode(article, postLink) {
    const urlMatch = window.location.pathname.match(/\/(p|reels?)\/([A-Za-z0-9_-]+)/);
    if (urlMatch) return urlMatch[2];
    if (postLink?.href) {
      const m = postLink.href.match(/\/(p|reels?)\/([A-Za-z0-9_-]+)/);
      if (m) return m[2];
    }
    const a = article && article !== document.body &&
              article.querySelector('a[href*="/p/"], a[href*="/reel/"], a[href*="/reels/"], a[href*="/reels/"]');
    if (!a) return null;
    const m = a.href.match(/\/(p|reels?)\/([A-Za-z0-9_-]+)/);
    return m ? m[2] : null;
  }

  function bestImgUrl(img) {
    if (!img) return null;
    if (img.srcset) {
      const best = img.srcset.split(',')
        .map(s => { const p = s.trim().split(/\s+/); return { url: p[0], w: parseInt(p[1]) || 0 }; })
        .sort((a, b) => b.w - a.w)[0];
      if (best?.url) return best.url;
    }
    return img.src || null;
  }

  function getVisibleMedia(article) {
    const video = article.querySelector('video');
    if (video?.src) return { url: video.src, ext: 'mp4' };
    const src = article.querySelector('video source');
    if (src?.src) return { url: src.src, ext: 'mp4' };
    const imgs = [...article.querySelectorAll('img')];
    const mainImg = imgs.find(img =>
      img.srcset && img.srcset.length > 0 &&
      (img.naturalWidth || parseInt(img.getAttribute('width')) || 0) > 60
    ) || imgs.find(img => img.srcset);
    const url = bestImgUrl(mainImg);
    if (url) return { url, ext: 'jpg' };
    return null;
  }

  // ── Shared media fetch ───────────────────────────────────────────────────────
  function parseApiSlides(item) {
    if (!item) return null;
    const rawSlides = item.carousel_media?.length ? item.carousel_media : [item];
    const slides = rawSlides.map(s => {
      const videoUrl = s.video_url || s.video_versions?.[0]?.url;
      const url = videoUrl || s.image_versions2?.candidates?.[0]?.url;
      if (!url) return null;
      return { url, id: String(s.pk || s.id), isVideo: !!videoUrl };
    }).filter(Boolean);
    return slides.length ? slides : null;
  }

  async function fetchMediaSlides(article, postLink, btn) {
    const handle    = getHandle();
    const shortcode = getShortcode(article, postLink);

    // 0️⃣  Interceptor cache — populated by injector.js from Instagram's own API calls
    console.log('[SCS-DBG] fetchMediaSlides shortcode:', shortcode, '| cache size:', postCache.size, '| hit:', shortcode ? postCache.has(shortcode) : false);
    if (shortcode && postCache.has(shortcode)) {
      return { key: shortcode, slides: postCache.get(shortcode), handle };
    }

    if (shortcode) {
      const mediaId  = scToId(shortcode);
      const csrfTok  = csrf();
      const wwwClaim = (document.cookie.match(/ig-www-claim=([^;]+)/) || [])[1] || '0';
      const igHeaders = {
        'X-CSRFToken':      csrfTok,
        'X-IG-App-ID':      '936619743392459',
        'X-Requested-With': 'XMLHttpRequest',
        'X-IG-WWW-Claim':   wwwClaim,
        'Accept':           'application/json',
      };

      // 1️⃣  Direct fetch from content script (same tab context, correct Origin/cookies)
      try {
        const resp = await fetch(
          `https://www.instagram.com/api/v1/media/${mediaId}/info/`,
          { credentials: 'include', headers: igHeaders }
        );
        if (resp.ok) {
          const data = await resp.json();
          const slides = parseApiSlides(data?.items?.[0]);
          if (slides) return { key: shortcode, slides, handle };
        }
      } catch (_) {}

      // 2️⃣  Background SW fallback (tries numeric-ID then shortcode-path endpoint)
      try {
        const result = await new Promise(resolve =>
          chrome.runtime.sendMessage(
            { type: 'FETCH_IG_MEDIA_INFO', shortcode, mediaId, csrf: csrfTok, wwwClaim },
            r => { resolve(chrome.runtime.lastError ? null : r); }
          )
        );
        if (result?.slides?.length) return { key: shortcode, slides: result.slides, handle };
      } catch (_) {}
    }

    // 3️⃣  Background SW reel-page fetch — bypasses Instagram's SW to get real SSR.
    //     injector.js page-context fetch goes through Instagram's SW (returns app shell);
    //     the extension background SW goes directly to the server and gets SSR video_url.
    if (shortcode) {
      try {
        const result = await new Promise(resolve =>
          chrome.runtime.sendMessage(
            { type: 'FETCH_REEL_PAGE', shortcode },
            r => { resolve(chrome.runtime.lastError ? null : r); }
          )
        );
        if (result?.slides?.length) return { key: shortcode, slides: result.slides, handle };
      } catch (_) {}
    }

    // 4️⃣  Last resort: use the specific image URL stored when the button was injected
    //     (avoids scanning document.body which picks the wrong element on profile grids)
    const fallback = btn?.dataset?.scsFallback;
    if (fallback) {
      const key = shortcode || String(Date.now());
      return { key, slides: [{ url: fallback, id: key, isVideo: false }], handle };
    }
    // 5️⃣  DOM video element (only works if Instagram renders a direct <video src>, not MSE)
    const media = getVisibleMedia(article);
    if (!media?.url || media.url.startsWith('blob:') || media.url.startsWith('data:')) return null;
    const key = shortcode || String(Date.now());
    return { key, slides: [{ url: media.url, id: key, isVideo: media.ext === 'mp4' }], handle };
  }

  // ── Button state machine ─────────────────────────────────────────────────────
  function setState(btn, state) {
    btn.classList.remove('scs-spin', 'scs-done', 'scs-error');
    btn.disabled = false;
    if (state === 'loading') {
      btn.classList.add('scs-spin');
      btn.innerHTML = ICON_SPIN;
      btn.disabled  = true;
    } else if (state === 'done') {
      btn.classList.remove('scs-selected');
      btn.classList.add('scs-done');
      btn.innerHTML = ICON_OK;
    } else if (state === 'error') {
      btn.classList.add('scs-error');
      btn.innerHTML = ICON_ERR;
    } else if (state === 'selected') {
      btn.classList.add('scs-selected');
      btn.innerHTML = ICON_CHECK;
    } else {
      // idle — keep selected highlight if the item is still in the selection set
      const key = btn.dataset.scsSelectKey;
      if (key && selection.has(key)) {
        btn.classList.add('scs-selected');
        btn.innerHTML = ICON_CHECK;
      } else {
        btn.classList.remove('scs-selected');
        btn.innerHTML = ICON_DL;
      }
    }
  }

  // ── Download (immediate) ─────────────────────────────────────────────────────
  // The service worker (background.js) fetches the media with full host_permissions
  // (CORS bypass) then downloads it. Content scripts cannot bypass CORS, so we
  // must delegate the actual fetch to the background.
  async function doDownload(article, btn, postLink) {
    setState(btn, 'loading');
    try {
      const result = await fetchMediaSlides(article, postLink, btn);
      if (!result || !result.slides.length) throw new Error('no-media');

      const resp = await new Promise(resolve =>
        chrome.runtime.sendMessage({
          type:     'DOWNLOAD_MEDIA_SINGLE',
          slides:   result.slides,
          platform: 'instagram',
          handle:   result.handle,
        }, (r) => {
          if (chrome.runtime.lastError) { resolve({ error: chrome.runtime.lastError.message }); return; }
          resolve(r);
        })
      );

      if (resp?.error) throw new Error(resp.error);

      startProgressPoll(false);
      await waitForDownloadFinish();
      setState(btn, 'done');
      setTimeout(() => setState(btn, null), 2500);
    } catch (err) {
      setState(btn, 'error');
      btn.title = 'Download failed: ' + (err?.message || 'unknown');
      console.warn('[SCS-DBG] download failed:', err?.message || err);
      setTimeout(() => setState(btn, null), 2500);
    }
  }

  // ── Select mode logic ────────────────────────────────────────────────────────
  function updateSelectUI() {
    const n = selection.size;
    dlSelectedBtn.innerHTML = `${ICON_DL_SM} Download Selection (${n})`;
    dlSelectedBtn.style.display = n > 0 ? 'flex' : 'none';
  }

  async function toggleSelectItem(btn, article, postLink) {
    const key = btn.dataset.scsSelectKey || getShortcode(article, postLink);

    if (key && selection.has(key)) {
      // Deselect
      selection.delete(key);
      delete btn.dataset.scsSelectKey;
      setState(btn, null);
      updateSelectUI();
      return;
    }

    setState(btn, 'loading');
    try {
      const result = await fetchMediaSlides(article, postLink, btn);
      if (!result) throw new Error('no-media');
      selection.set(result.key, result);
      btn.dataset.scsSelectKey = result.key;
      setState(btn, 'selected');
      updateSelectUI();
    } catch (_) {
      setState(btn, 'error');
      setTimeout(() => setState(btn, null), 2000);
    }
  }

  // ── Batch download progress bar ─────────────────────────────────────────────
  const dlProgressEl   = document.createElement('div');
  dlProgressEl.className = 'scs-dl-progress';
  const dlProgressLabel = document.createElement('span');
  const dlProgressTrack = document.createElement('div');
  dlProgressTrack.className = 'scs-dl-progress-track';
  const dlProgressFill  = document.createElement('div');
  dlProgressFill.className = 'scs-dl-progress-fill';
  dlProgressTrack.appendChild(dlProgressFill);
  dlProgressEl.appendChild(dlProgressLabel);
  dlProgressEl.appendChild(dlProgressTrack);
  document.body.appendChild(dlProgressEl);

  let _progressTimer = null;

  function startProgressPoll(isZip) {
    if (_progressTimer) return;
    dlProgressFill.classList.remove('done');
    dlProgressFill.style.width = '0%';
    dlProgressLabel.textContent = isZip ? 'Preparing ZIP...' : '0 / ?';
    dlProgressEl.style.display = 'flex';
    _progressTimer = setInterval(() => {
      chrome.runtime.sendMessage({ type: 'GET_DOWNLOAD_PROGRESS' }, resp => {
        if (chrome.runtime.lastError || !resp || resp.total === 0) return;
        const { completed, failed, total, percent, zipMode, lastError } = resp;
        if (zipMode) {
          dlProgressLabel.textContent = `Preparing: ${completed} / ${total}`;
        } else if (lastError) {
          dlProgressLabel.textContent = `Error: ${lastError}`;
        } else {
          dlProgressLabel.textContent = `${completed + failed} / ${total}`;
        }
        dlProgressFill.style.width = percent + '%';
        if (percent >= 100) {
          dlProgressFill.classList.add('done');
          clearInterval(_progressTimer);
          _progressTimer = null;
          setTimeout(() => { dlProgressEl.style.display = 'none'; }, 2000);
        }
      });
    }, 600);
  }

  // ── Folder-picker modal ─────────────────────────────────────────────────────
  function waitForDownloadFinish(timeoutMs = 120000) {
    const started = Date.now();
    return new Promise((resolve, reject) => {
      const timer = setInterval(() => {
        chrome.runtime.sendMessage({ type: 'GET_DOWNLOAD_PROGRESS' }, resp => {
          if (chrome.runtime.lastError) return;
          if (!resp || resp.total === 0) {
            if (Date.now() - started > timeoutMs) {
              clearInterval(timer);
              reject(new Error('download-timeout'));
            }
            return;
          }

          const finished = (resp.completed || 0) + (resp.failed || 0);
          if (finished >= resp.total) {
            clearInterval(timer);
            if ((resp.failed || 0) > 0) reject(new Error(resp.lastError || 'download-failed'));
            else resolve(resp);
          } else if (Date.now() - started > timeoutMs) {
            clearInterval(timer);
            reject(new Error('download-timeout'));
          }
        });
      }, 500);
    });
  }

  const modalOverlay = document.createElement('div');
  modalOverlay.className = 'scs-modal-overlay scs-hidden';
  modalOverlay.innerHTML = `
    <div class="scs-modal">
      <div class="scs-modal-title">Download Selection</div>
      <div class="scs-modal-sub" id="scs-modal-sub"></div>
      <label class="scs-modal-label">Save in (Downloads/):</label>
      <div class="scs-modal-row">
        <span class="scs-modal-prefix">Downloads /</span>
        <input class="scs-modal-input" id="scs-folder-input" type="text" placeholder="ex: instagram-photos" spellcheck="false">
      </div>
      <div class="scs-modal-actions">
        <button class="scs-modal-cancel" id="scs-modal-cancel">Cancel</button>
        <button class="scs-modal-zip"    id="scs-modal-zip">📦 ZIP</button>
        <button class="scs-modal-files"  id="scs-modal-files">📁 Files</button>
      </div>
    </div>
  `;
  document.body.appendChild(modalOverlay);

  const folderInput  = modalOverlay.querySelector('#scs-folder-input');
  const modalSub     = modalOverlay.querySelector('#scs-modal-sub');
  modalOverlay.querySelector('#scs-modal-cancel').addEventListener('click', () => {
    modalOverlay.classList.add('scs-hidden');
  });
  // Close on backdrop click
  modalOverlay.addEventListener('click', e => {
    if (e.target === modalOverlay) modalOverlay.classList.add('scs-hidden');
  });

  function showFolderModal(slideCount, onFiles, onZip) {
    modalSub.textContent = `${slideCount} selected media item${slideCount > 1 ? 's' : ''}`;
    folderInput.value = getHandle() || 'instagram';
    modalOverlay.classList.remove('scs-hidden');
    folderInput.focus();
    folderInput.select();

    const filesBtn = modalOverlay.querySelector('#scs-modal-files');
    const zipBtn   = modalOverlay.querySelector('#scs-modal-zip');

    const cleanup = () => {
      filesBtn.removeEventListener('click', filesHandler);
      zipBtn.removeEventListener('click', zipHandler);
      folderInput.removeEventListener('keydown', enterHandler);
      modalOverlay.classList.add('scs-hidden');
    };
    const filesHandler = () => {
      cleanup();
      onFiles(folderInput.value.trim() || getHandle() || 'instagram');
    };
    const zipHandler = () => {
      cleanup();
      onZip(folderInput.value.trim() || getHandle() || 'instagram');
    };
    const enterHandler = e => { if (e.key === 'Enter') filesHandler(); };
    filesBtn.addEventListener('click', filesHandler);
    zipBtn.addEventListener('click', zipHandler);
    folderInput.addEventListener('keydown', enterHandler);
  }

  // Account description/caption search.
  const RESERVED_IG_PATHS = new Set([
    'accounts', 'about', 'api', 'challenge', 'direct', 'explore', 'graphql',
    'p', 'reel', 'reels', 'stories', 'tv', 'web',
  ]);

  function getProfileHandleForSearch() {
    const m = window.location.pathname.match(/^\/([a-zA-Z0-9._]+)(?:\/(?:reels?|tagged|posts|videos|igtv))?\/?$/);
    if (!m || RESERVED_IG_PATHS.has(m[1].toLowerCase())) return null;
    return m[1];
  }

  function igHeaders() {
    return {
      'X-CSRFToken': csrf(),
      'X-IG-App-ID': '936619743392459',
      'X-Requested-With': 'XMLHttpRequest',
      'X-IG-WWW-Claim': (document.cookie.match(/ig-www-claim=([^;]+)/) || [])[1] || '0',
      'Accept': 'application/json',
    };
  }

  async function igJson(url, options = {}) {
    const resp = await fetch(url, {
      credentials: 'include',
      ...options,
      headers: { ...igHeaders(), ...(options.headers || {}) },
    });
    if (!resp.ok) throw new Error(`Instagram returned HTTP ${resp.status}`);
    return resp.json();
  }

  async function getSearchUser(handle) {
    const data = await igJson(
      `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(handle)}`
    );
    const user = data?.data?.user;
    const userId = user?.id || user?.pk;
    if (!userId) throw new Error('Account not found');
    if (user.is_private) throw new Error('This account is private');
    return { userId: String(userId), postCount: user.edge_owner_to_timeline_media?.count || 0 };
  }

  function captionText(item) {
    return item?.caption?.text || (typeof item?.caption === 'string' ? item.caption : '') || '';
  }

  function parseSearchItem(item, handle, forcedType) {
    if (!item) return null;
    const postId = String(item.id || item.pk || '');
    const shortcode = item.code || item.shortcode || '';
    if (!postId || !shortcode) return null;

    let mediaType = forcedType || 'post';
    if (!forcedType) {
      if (item.product_type === 'clips' || item.media_type === 2 || item.is_video || item.video_versions?.length) {
        mediaType = item.product_type === 'clips' ? 'reel' : 'video';
      } else if (item.media_type === 8 || item.carousel_media?.length) {
        mediaType = 'carousel';
      } else {
        mediaType = 'feed';
      }
    }

    const thumb =
      item.image_versions2?.candidates?.[0]?.url ||
      item.carousel_media?.[0]?.image_versions2?.candidates?.[0]?.url ||
      item.thumbnail_url ||
      item.display_url ||
      '';
    const taken = item.taken_at || item.taken_at_timestamp || 0;
    const isReel = mediaType === 'reel' || item.product_type === 'clips';

    return {
      postId,
      shortcode,
      caption: captionText(item),
      mediaType,
      thumbnailUrl: thumb,
      postUrl: `https://www.instagram.com/${isReel ? 'reel' : 'p'}/${shortcode}/`,
      publishedAt: taken ? new Date(taken * 1000).toISOString() : '',
      ownerHandle: item.user?.username || item.owner?.username || handle,
    };
  }

  function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, ch => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[ch]));
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function queryTokens(query) {
    return query.toLowerCase().split(/\s+/).map(s => s.trim()).filter(Boolean);
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function captionMatches(caption, tokens) {
    const low = caption.toLowerCase();
    return tokens.length > 0 && tokens.every(t => low.includes(t));
  }

  function highlightedCaption(caption, tokens) {
    const escaped = escapeHtml(caption || '');
    if (!tokens.length) return escaped;
    const unique = [...new Set(tokens)].sort((a, b) => b.length - a.length).map(escapeRegExp);
    if (!unique.length) return escaped;
    return escaped.replace(new RegExp(`(${unique.join('|')})`, 'gi'), '<mark class="scs-search-mark">$1</mark>');
  }

  function shortDate(iso) {
    if (!iso) return '';
    try {
      return new Intl.DateTimeFormat(undefined, { year: 'numeric', month: 'short', day: 'numeric' }).format(new Date(iso));
    } catch (_) {
      return iso.slice(0, 10);
    }
  }

  function renderSearchResults(results, tokens) {
    if (!results.length) {
      searchResultsEl.innerHTML = '<div class="scs-search-empty">No matches</div>';
      return;
    }
    searchResultsEl.innerHTML = results.map(post => `
      <a class="scs-search-result" href="${escapeHtml(post.postUrl)}" target="_blank" rel="noopener noreferrer">
        ${post.thumbnailUrl
          ? `<img class="scs-search-thumb" src="${escapeHtml(post.thumbnailUrl)}" alt="">`
          : '<div class="scs-search-thumb"></div>'}
        <div>
          <div class="scs-search-meta">
            <span class="scs-search-type">${escapeHtml(post.mediaType)}</span>
            <span class="scs-search-date">${escapeHtml(shortDate(post.publishedAt))}</span>
          </div>
          <div class="scs-search-caption">${highlightedCaption(post.caption, tokens)}</div>
        </div>
      </a>
    `).join('');
  }

  const searchPanel = document.createElement('div');
  searchPanel.className = 'scs-search-panel';
  searchPanel.innerHTML = `
    <div class="scs-search-head">
      <div class="scs-search-title">Description Search</div>
      <button class="scs-search-min" type="button" title="Minimize">-</button>
    </div>
    <div class="scs-search-body">
      <form class="scs-search-form">
        <input class="scs-search-input" type="search" placeholder="Search descriptions" spellcheck="false">
        <button class="scs-search-run" type="submit">Search</button>
        <button class="scs-search-stop" type="button">Stop</button>
      </form>
      <div class="scs-search-status"></div>
      <div class="scs-search-results"></div>
    </div>
    <div class="scs-search-resize scs-search-resize-left" data-dir="left" title="Resize width"></div>
    <div class="scs-search-resize scs-search-resize-right" data-dir="right" title="Resize width"></div>
    <div class="scs-search-resize scs-search-resize-bottom" data-dir="bottom" title="Resize height"></div>
    <div class="scs-search-resize scs-search-resize-bl" data-dir="bottom-left" title="Resize"></div>
    <div class="scs-search-resize scs-search-resize-br" data-dir="bottom-right" title="Resize"></div>
  `;
  document.body.appendChild(searchPanel);

  const searchForm = searchPanel.querySelector('.scs-search-form');
  const searchInput = searchPanel.querySelector('.scs-search-input');
  const searchRunBtn = searchPanel.querySelector('.scs-search-run');
  const searchStopBtn = searchPanel.querySelector('.scs-search-stop');
  const searchStatusEl = searchPanel.querySelector('.scs-search-status');
  const searchResultsEl = searchPanel.querySelector('.scs-search-results');
  const searchMinBtn = searchPanel.querySelector('.scs-search-min');
  const searchResizeHandles = [...searchPanel.querySelectorAll('.scs-search-resize')];
  let activeSearchId = 0;
  let searchOpenSize = null;

  function colorLuminance(color) {
    const value = String(color || '').trim();
    if (!value || value === 'transparent') return null;
    const m = value.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([.\d]+))?/i);
    if (!m) return null;
    if (m[4] !== undefined && Number(m[4]) === 0) return null;
    const [r, g, b] = m.slice(1, 4).map(Number);
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }

  function detectInstagramIsDark() {
    const rootStyle = getComputedStyle(document.documentElement);
    const igBgLum = colorLuminance(rootStyle.getPropertyValue('--ig-primary-background'));
    if (igBgLum !== null) return igBgLum < 128;

    const candidates = [
      document.body,
      document.documentElement,
      document.querySelector('main'),
      document.querySelector('[role="main"]'),
    ].filter(Boolean);

    for (const el of candidates) {
      const bg = getComputedStyle(el).backgroundColor;
      const lum = colorLuminance(bg);
      if (lum !== null) return lum < 128;
    }
    return window.matchMedia?.('(prefers-color-scheme: dark)').matches || false;
  }

  function syncSearchTheme() {
    const instagramIsDark = detectInstagramIsDark();
    searchPanel.classList.toggle('scs-inverse-light', instagramIsDark);
    searchPanel.classList.toggle('scs-inverse-dark', !instagramIsDark);
  }

  syncSearchTheme();
  window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', syncSearchTheme);
  setInterval(syncSearchTheme, 1500);

  function setSearchRunning(running) {
    searchRunBtn.disabled = running;
    searchInput.disabled = running;
    searchStopBtn.style.display = running ? 'block' : 'none';
  }

  function updateSearchStatus(scanned, matches, phase, done) {
    const part = phase ? `${phase}: ` : '';
    searchStatusEl.textContent = done
      ? `${matches} match${matches === 1 ? '' : 'es'} in ${scanned} checked`
      : `${part}${matches} match${matches === 1 ? '' : 'es'} / ${scanned} checked`;
  }

  async function runDescriptionSearch() {
    const query = searchInput.value.trim();
    const tokens = queryTokens(query);
    if (!tokens.length) {
      searchStatusEl.textContent = 'Enter a word';
      searchResultsEl.innerHTML = '';
      return;
    }

    const handle = getProfileHandleForSearch();
    if (!handle) {
      searchStatusEl.textContent = 'Open a public profile page first';
      searchResultsEl.innerHTML = '';
      return;
    }

    const searchId = ++activeSearchId;
    const seen = new Set();
    const matches = [];
    let scanned = 0;

    setSearchRunning(true);
    searchResultsEl.innerHTML = '';
    updateSearchStatus(0, 0, 'Starting', false);

    const addItems = (items, forcedType) => {
      for (const raw of items) {
        if (searchId !== activeSearchId) return false;
        const post = parseSearchItem(raw, handle, forcedType);
        if (!post || seen.has(post.postId)) continue;
        seen.add(post.postId);
        scanned++;
        if (captionMatches(post.caption, tokens)) {
          matches.push(post);
          renderSearchResults(matches, tokens);
        }
      }
      return true;
    };

    try {
      const { userId } = await getSearchUser(handle);

      let feedCursor = null;
      let feedEmptyPages = 0;
      while (searchId === activeSearchId) {
        let url = `https://www.instagram.com/api/v1/feed/user/${userId}/?count=50`;
        if (feedCursor) url += `&max_id=${encodeURIComponent(feedCursor)}`;
        const data = await igJson(url);
        const items = data?.items || [];
        if (items.length) feedEmptyPages = 0;
        else feedEmptyPages++;
        if (!addItems(items, null)) break;
        updateSearchStatus(scanned, matches.length, 'Feed', false);
        feedCursor = data?.next_max_id || null;
        if (!data?.more_available || !feedCursor || feedEmptyPages >= 3) break;
        await sleep(900 + Math.random() * 400);
      }

      let reelsCursor = null;
      while (searchId === activeSearchId) {
        let body = `target_user_id=${userId}&page_size=50`;
        if (reelsCursor) body += `&max_id=${encodeURIComponent(reelsCursor)}`;
        let data;
        try {
          data = await igJson('https://www.instagram.com/api/v1/clips/user/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body,
          });
        } catch (_) {
          break;
        }
        const items = (data?.items || []).map(i => i?.media || i).filter(Boolean);
        if (!addItems(items, 'reel')) break;
        updateSearchStatus(scanned, matches.length, 'Reels', false);
        reelsCursor = data?.paging_info?.max_id || null;
        if (!data?.paging_info?.more_available || !reelsCursor) break;
        await sleep(1100 + Math.random() * 400);
      }

      if (searchId === activeSearchId) {
        updateSearchStatus(scanned, matches.length, '', true);
        renderSearchResults(matches, tokens);
      }
    } catch (err) {
      if (searchId === activeSearchId) {
        searchStatusEl.textContent = err?.message || 'Search failed';
      }
    } finally {
      if (searchId === activeSearchId) setSearchRunning(false);
    }
  }

  searchForm.addEventListener('submit', e => {
    e.preventDefault();
    runDescriptionSearch();
  });
  searchStopBtn.addEventListener('click', () => {
    activeSearchId++;
    setSearchRunning(false);
    searchStatusEl.textContent = 'Search stopped';
  });
  searchMinBtn.addEventListener('click', () => {
    const willCollapse = !searchPanel.classList.contains('scs-collapsed');
    if (willCollapse) {
      const rect = searchPanel.getBoundingClientRect();
      searchOpenSize = { width: rect.width, height: rect.height };
    } else if (searchOpenSize) {
      searchPanel.style.width = `${searchOpenSize.width}px`;
      searchPanel.style.height = `${searchOpenSize.height}px`;
    }

    const collapsed = searchPanel.classList.toggle('scs-collapsed');
    searchMinBtn.textContent = collapsed ? '+' : '-';
    searchMinBtn.title = collapsed ? 'Open' : 'Minimize';
  });

  // ── Select-mode floating toggle button ───────────────────────────────────────
  searchResizeHandles.forEach(handle => {
    handle.addEventListener('pointerdown', e => {
      if (searchPanel.classList.contains('scs-collapsed')) return;
      e.preventDefault();
      e.stopPropagation();

      const dir = handle.dataset.dir || 'bottom-right';
      const startX = e.clientX;
      const startY = e.clientY;
      const startRect = searchPanel.getBoundingClientRect();
      const minW = 280;
      const minH = 150;
      const maxW = Math.max(minW, window.innerWidth - 32);
      const maxH = Math.max(minH, window.innerHeight - startRect.top - 16);
      const anchoredRight = window.innerWidth - startRect.right;

      searchPanel.style.right = `${anchoredRight}px`;
      searchPanel.style.left = '';
      handle.setPointerCapture?.(e.pointerId);

      const onMove = ev => {
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        let nextW = startRect.width;
        let nextH = startRect.height;

        if (dir.includes('left')) nextW = startRect.width - dx;
        if (dir.includes('right')) nextW = startRect.width + dx;
        if (dir.includes('bottom')) nextH = startRect.height + dy;

        searchPanel.style.width = `${Math.min(maxW, Math.max(minW, nextW))}px`;
        searchPanel.style.height = `${Math.min(maxH, Math.max(minH, nextH))}px`;
      };

      const onUp = ev => {
        handle.releasePointerCapture?.(ev.pointerId);
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
        window.removeEventListener('pointercancel', onUp);
      };

      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp);
      window.addEventListener('pointercancel', onUp);
    });
  });

  const selectToggleBtn = document.createElement('button');
  selectToggleBtn.className = 'scs-select-toggle';
  selectToggleBtn.title     = 'Selection mode';
  selectToggleBtn.innerHTML = ICON_SELECT + '<span style="pointer-events:none">Select</span>';
  selectToggleBtn.addEventListener('click', () => {
    selectMode = !selectMode;
    selectToggleBtn.classList.toggle('active', selectMode);
    if (!selectMode) {
      // Exit select mode: clear all selections
      selection.clear();
      document.querySelectorAll(`.${BTN_CLASS}.scs-selected`).forEach(b => {
        delete b.dataset.scsSelectKey;
        setState(b, null);
      });
      updateSelectUI();
    }
  });
  document.body.appendChild(selectToggleBtn);

  // ── Download-selected floating action button ─────────────────────────────────
  const dlSelectedBtn = document.createElement('button');
  dlSelectedBtn.className    = 'scs-dl-selected-btn';
  dlSelectedBtn.style.display = 'none';
  dlSelectedBtn.addEventListener('click', () => {
    if (!selection.size) return;

    const allSlides = [];
    for (const item of selection.values()) {
      for (const slide of item.slides) allSlides.push(slide);
    }

    const clearSelection = () => {
      selection.clear();
      document.querySelectorAll(`.${BTN_CLASS}.scs-selected`).forEach(b => {
        delete b.dataset.scsSelectKey;
        setState(b, null);
      });
      selectMode = false;
      selectToggleBtn.classList.remove('active');
      updateSelectUI();
    };

    showFolderModal(
      allSlides.length,
      // Files - individual files to Downloads/folder/
      folder => {
        chrome.runtime.sendMessage({
          type:       'DOWNLOAD_MEDIA_SINGLE',
          slides:     allSlides,
          platform:   'instagram',
          handle:     getHandle(),
          saveFolder: folder,
        });
        startProgressPoll(false);
        clearSelection();
      },
      // 📦 ZIP — single ZIP file, one save dialog
      folder => {
        chrome.runtime.sendMessage({
          type:     'DOWNLOAD_SELECTION_ZIP',
          slides:   allSlides,
          platform: 'instagram',
          handle:   getHandle(),
          zipName:  folder,
        });
        startProgressPoll(true);
        clearSelection();
      }
    );
  });
  document.body.appendChild(dlSelectedBtn);
  updateSelectUI();

  // ── Button injection ─────────────────────────────────────────────────────────
  function injectButtonOnMedia(mediaEl, article) {
    if (!mediaEl || mediaEl.dataset.scsDl) return;
    const rect = mediaEl.getBoundingClientRect();
    if (rect.width < 100 || rect.height < 100) return;

    const container = mediaEl.parentElement;
    if (!container || container.querySelector('.' + BTN_CLASS)) return;

    mediaEl.dataset.scsDl = '1';

    if (window.getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.classList.add(`${BTN_CLASS}-wrap`);

    const postLink  = mediaEl.closest('a[href*="/p/"], a[href*="/reel/"], a[href*="/reels/"]') || null;
    const articleEl = article || document.body;

    const btn = document.createElement('button');
    btn.className = BTN_CLASS;
    btn.title     = 'Download';
    btn.innerHTML = ICON_DL;

    // Store the specific image URL as a direct fallback (used when API & cache both fail).
    // Skip for reel/video links — downloading the thumbnail JPG instead of the MP4
    // would be misleading. Those fall back to the cache or show an honest red X.
    const isReelLink = !!postLink?.href?.match(/\/(reel|reels)\//);
    if (!isReelLink) {
      const fallbackUrl = bestImgUrl(mediaEl) || mediaEl.src || '';
      if (fallbackUrl && !fallbackUrl.startsWith('blob:') && !fallbackUrl.startsWith('data:')) {
        btn.dataset.scsFallback = fallbackUrl;
      }
    }

    btn.addEventListener('click', e => {
      e.preventDefault(); e.stopPropagation();
      if (selectMode) toggleSelectItem(btn, articleEl, postLink);
      else            doDownload(articleEl, btn, postLink);
    });

    container.appendChild(btn);
  }

  // Fixed-position button — appended to document.body so nothing clips it.
  // Positioned at TOP-LEFT to avoid Instagram's right-side action panel.
  function createFixedButton(videoEl) {
    if (videoEl.dataset.scsDl) return;
    videoEl.dataset.scsDl = '1';

    const article  = videoEl.closest('article') || document.body;
    const postLink = videoEl.closest('a[href*="/p/"], a[href*="/reel/"], a[href*="/reels/"]') || null;

    const btn = document.createElement('button');
    btn.className = BTN_CLASS + ' ' + BTN_CLASS + '-fixed';
    btn.title     = 'Download';
    btn.innerHTML = ICON_DL;

    let retries = 20;
    const reposition = () => {
      const r = videoEl.getBoundingClientRect();
      if (r.width < 50 || r.height < 50) {
        if (retries-- > 0) { setTimeout(reposition, 250); return; }
        btn.style.display = 'none';
        return;
      }
      btn.style.display = 'flex';
      btn.style.top   = (r.top  + 8) + 'px';
      btn.style.left  = (r.left + 8) + 'px';
      btn.style.right = '';
    };
    reposition();
    window.addEventListener('scroll', reposition, { passive: true });
    window.addEventListener('resize', reposition, { passive: true });

    const mo = new MutationObserver(() => {
      if (!document.contains(videoEl)) {
        btn.remove(); mo.disconnect();
        window.removeEventListener('scroll', reposition);
        window.removeEventListener('resize', reposition);
      }
    });
    mo.observe(document.body, { childList: true, subtree: true });

    btn.addEventListener('click', e => {
      e.preventDefault(); e.stopPropagation();
      if (selectMode) toggleSelectItem(btn, article, postLink);
      else            doDownload(article, btn, postLink);
    });
    document.body.appendChild(btn);
  }

  // ── Observer ─────────────────────────────────────────────────────────────────

  function watchVideoUntilSized(videoEl) {
    if (videoEl.dataset.scsDl || videoEl.dataset.scsWatch) return;
    videoEl.dataset.scsWatch = '1';
    const ro = new ResizeObserver(() => {
      const r = videoEl.getBoundingClientRect();
      const w = r.width  || videoEl.clientWidth;
      const h = r.height || videoEl.clientHeight;
      if (w >= 150 || h >= 150) {
        ro.disconnect();
        if (!videoEl.dataset.scsDl) createFixedButton(videoEl);
      }
    });
    ro.observe(videoEl);
  }

  function scan() {
    document.querySelectorAll('video').forEach(v => {
      if (v.dataset.scsDl || v.dataset.scsWatch) return;
      const w = v.getBoundingClientRect().width  || v.clientWidth;
      const h = v.getBoundingClientRect().height || v.clientHeight;
      if (w >= 150 || h >= 150) { createFixedButton(v); return; }
      watchVideoUntilSized(v);
    });

    document.querySelectorAll('article').forEach(article => {
      if (article.querySelector('video')) return;
      const imgs = [...article.querySelectorAll('img[srcset]')];
      const main = imgs.find(img => {
        const w = img.naturalWidth  || img.width  || img.getBoundingClientRect().width;
        const h = img.naturalHeight || img.height || img.getBoundingClientRect().height;
        return w > 100 && h > 100;
      });
      if (main) injectButtonOnMedia(main, article);
    });

    document.querySelectorAll('a[href] img').forEach(img => {
      if (img.closest('article') || img.dataset.scsDl) return;
      const link = img.closest('a');
      if (!link || !link.href.match(/\/(p|reels?|tv)\//)) return;
      const w = img.naturalWidth  || img.width  || img.getBoundingClientRect().width;
      const h = img.naturalHeight || img.height || img.getBoundingClientRect().height;
      if (w > 60 && h > 60) injectButtonOnMedia(img, null);
    });
  }

  scan();

  let scanTimer = null;
  new MutationObserver(() => {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, 300);
  }).observe(document.body, { childList: true, subtree: true });

})();
