// content/facebook.js - Facebook scraper via DOM + MutationObserver

(function () {
  'use strict';

  let isExtracting = false;
  let stopRequested = false;
  const seenIds = new Set();

  function getHandle() {
    const m = window.location.pathname.match(/^\/([a-zA-Z0-9.]+)\/?$/);
    const excluded = ['groups','marketplace','watch','gaming','notifications','events','pages','help','login'];
    return (m && !excluded.includes(m[1])) ? m[1] : null;
  }

  function extractPostId(url) {
    if (!url) return null;
    let m = url.match(/\/posts\/(\d+)/);
    if (m) return m[1];
    m = url.match(/[?&]story_fbid=(\d+)/);
    if (m) return m[1];
    m = url.match(/\/photos\/[^/]+\/(\d+)/);
    if (m) return m[1];
    m = url.match(/\/videos\/(\d+)/);
    if (m) return m[1];
    m = url.match(/pfbid([A-Za-z0-9]+)/);
    if (m) return m[1];
    return null;
  }

  function scrapeArticles(handle) {
    const posts = [];
    const articles = document.querySelectorAll('[role="article"]');

    for (const article of articles) {
      const timeEl = article.querySelector('time[datetime]');
      if (!timeEl) continue;

      const linkEl = article.querySelector(
        'a[href*="/posts/"], a[href*="/photos/"], a[href*="/videos/"], a[href*="pfbid"]'
      );
      const postUrl = linkEl?.href || '';
      const postId = extractPostId(postUrl) || `fb_${timeEl.dateTime.replace(/\W/g, '')}`;

      if (seenIds.has(postId)) continue;
      seenIds.add(postId);

      const videoEl = article.querySelector('video');
      const videoSrc = videoEl?.src || '';
      const imgEl = article.querySelector('img[referrerpolicy], img[src*="scontent"]');
      const imgSrc = imgEl?.src || '';

      const captionEl = article.querySelector(
        '[data-ad-comet-preview="message"], [data-ad-preview="message"], [data-testid="post_message"]'
      );
      const caption = captionEl?.textContent?.trim() || '';

      posts.push({
        postId,
        postUrl,
        caption,
        publishedAt: timeEl.dateTime ? new Date(timeEl.dateTime).toISOString() : '',
        mediaType: videoSrc ? 'video' : imgSrc ? 'image' : 'text',
        mediaUrl: videoSrc || imgSrc || '',
        thumbnailUrl: imgSrc || '',
        ownerHandle: handle,
        platform: 'facebook',
      });
    }
    return posts;
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function runExtraction(handle) {
    isExtracting = true;
    stopRequested = false;
    seenIds.clear();

    try {
      chrome.runtime.sendMessage({ type: 'EXTRACTION_STARTED', platform: 'facebook', handle });
      window.scrollTo(0, 0);
      await sleep(1000);

      let noNewCount = 0;
      let lastCount = 0;

      while (!stopRequested && noNewCount < 4) {
        const posts = scrapeArticles(handle);
        if (posts.length > 0) {
          await new Promise(resolve => {
            chrome.runtime.sendMessage({
              type: 'POST_DATA', platform: 'facebook', handle,
              data: { normalizedItems: posts }
            }, resolve);
          });
        }

        if (seenIds.size === lastCount) {
          noNewCount++;
        } else {
          noNewCount = 0;
          lastCount = seenIds.size;
        }

        window.scrollBy(0, window.innerHeight * 2);
        await sleep(2500 + Math.random() * 500);
      }

      chrome.runtime.sendMessage({ type: 'EXTRACTION_COMPLETE', platform: 'facebook' });
    } catch (err) {
      chrome.runtime.sendMessage({ type: 'EXTRACTION_ERROR', error: err.message });
    } finally { isExtracting = false; }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {
      case 'START_EXTRACTION':
        if (isExtracting) { sendResponse({ status: 'already_running' }); return; }
        const handle = getHandle();
        if (!handle) { sendResponse({ error: 'No Facebook handle in URL' }); return; }
        runExtraction(handle);
        sendResponse({ status: 'started' });
        break;
      case 'STOP_EXTRACTION':
        stopRequested = true; isExtracting = false;
        sendResponse({ status: 'stopped' });
        break;
      case 'GET_PAGE_INFO':
        sendResponse({ handle: getHandle(), url: window.location.href, platform: 'facebook' });
        break;
      case 'PING': sendResponse({ status: 'alive' }); break;
    }
    return true;
  });
})();
