// content/instagram.js — credential bridge only; extraction runs in the service worker

(function () {
  'use strict';

  function getHandle() {
    const m = window.location.pathname.match(/^\/([a-zA-Z0-9._]+)(?:\/(?:reels|posts|videos|tagged|igtv)?\/?)?$/);
    return m ? m[1] : null;
  }

  function getCsrf() {
    const m = document.cookie.match(/csrftoken=([^;]+)/);
    return m ? m[1] : '';
  }

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  function postTypeFromUrl(url) {
    return /\/reels?\//.test(url) ? 'reel' : 'image';
  }

  function collectVisiblePosts(handle) {
    const seen = new Map();
    document.querySelectorAll('a[href*="/p/"], a[href*="/reel/"], a[href*="/reels/"]').forEach(link => {
      const match = link.href.match(/\/(p|reel|reels)\/([A-Za-z0-9_-]+)/);
      if (!match) return;
      const shortcode = match[2];
      if (seen.has(shortcode)) return;
      const img = link.querySelector('img');
      const thumbnailUrl = img?.currentSrc || img?.src || '';
      seen.set(shortcode, {
        postId: shortcode,
        shortcode,
        postUrl: `https://www.instagram.com/${match[1]}/${shortcode}/`,
        caption: img?.alt || '',
        publishedAt: '',
        mediaType: postTypeFromUrl(link.href),
        likesCount: 0,
        commentsCount: 0,
        mediaUrl: thumbnailUrl,
        thumbnailUrl,
        videoDuration: 0,
        carouselUrls: thumbnailUrl ? [thumbnailUrl] : [],
        carouselIds: [shortcode],
        ownerHandle: handle,
        platform: 'instagram',
      });
    });
    return [...seen.values()];
  }

  function numberFromText(value) {
    const text = String(value || '').trim().toLowerCase().replace(/\s/g, '');
    const match = text.match(/([\d.,]+)([km])?/);
    if (!match) return 0;
    let number = Number(match[1].replace(/,/g, ''));
    if (!Number.isFinite(number)) return 0;
    if (match[2] === 'k') number *= 1000;
    if (match[2] === 'm') number *= 1000000;
    return Math.round(number);
  }

  function dateFromCaption(value) {
    const match = String(value || '').match(/\bon\s+([A-Z][a-z]+ \d{1,2}, \d{4})/);
    if (!match) return '';
    const date = new Date(match[1]);
    return Number.isNaN(date.getTime()) ? '' : date.toISOString();
  }

  async function enrichPost(post) {
    const enriched = { ...post };
    if (!enriched.publishedAt) enriched.publishedAt = dateFromCaption(enriched.caption);
    try {
      const response = await fetch(enriched.postUrl, { credentials: 'include' });
      if (!response.ok) return enriched;
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const description =
        doc.querySelector('meta[property="og:description"]')?.content ||
        doc.querySelector('meta[name="description"]')?.content ||
        '';
      const image = doc.querySelector('meta[property="og:image"]')?.content || '';
      const video = doc.querySelector('meta[property="og:video"]')?.content || '';
      const stats = description.match(/([\d.,]+\s*[km]?)\s+likes?,\s*([\d.,]+\s*[km]?)\s+comments?/i);
      if (stats) {
        enriched.likesCount = numberFromText(stats[1]);
        enriched.commentsCount = numberFromText(stats[2]);
      }
      const timestamp = html.match(/"taken_at"\s*:\s*(\d{9,12})/);
      if (timestamp) enriched.publishedAt = new Date(Number(timestamp[1]) * 1000).toISOString();
      if (!enriched.publishedAt) enriched.publishedAt = dateFromCaption(description);
      if (video) {
        enriched.mediaType = 'reel';
        enriched.mediaUrl = video;
      } else if (image) {
        enriched.mediaUrl = image;
      }
      if (image) enriched.thumbnailUrl = image;
    } catch (_) {}
    return enriched;
  }

  async function scrapeVisiblePosts(expectedCount = 0) {
    const handle = getHandle();
    const collected = new Map();
    const published = new Set();
    const remember = () => {
      collectVisiblePosts(handle).forEach(post => collected.set(post.postId, post));
    };
    const publishNew = () => {
      const items = [...collected.values()].filter(post => !published.has(post.postId));
      if (!items.length) return;
      items.forEach(post => published.add(post.postId));
      chrome.runtime.sendMessage({
        type: 'POST_DATA',
        platform: 'instagram',
        handle,
        data: { normalizedItems: items },
      }, () => void chrome.runtime.lastError);
    };

    remember();
    publishNew();
    const target = Number(expectedCount || 0);
    let stableRounds = 0;
    for (let round = 0; round < 12; round++) {
      if (target && collected.size >= target) break;
      const before = collected.size;
      window.scrollBy(0, Math.max(700, Math.floor(window.innerHeight * 0.9)));
      await sleep(900);
      remember();
      publishNew();
      stableRounds = collected.size === before ? stableRounds + 1 : 0;
      if (stableRounds >= 3) break;
    }
    return {
      handle,
      normalizedItems: [...collected.values()].map(post => ({
        ...post,
        publishedAt: post.publishedAt || dateFromCaption(post.caption),
      })),
    };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    switch (msg.type) {
      case 'GET_CREDENTIALS':
        sendResponse({ csrf: getCsrf(), handle: getHandle() });
        break;
      case 'GET_PAGE_INFO':
        sendResponse({ handle: getHandle(), url: window.location.href, platform: 'instagram' });
        break;
      case 'SCRAPE_VISIBLE_POSTS':
        scrapeVisiblePosts(msg.expectedCount || 0)
          .then(result => sendResponse(result))
          .catch(error => sendResponse({ error: error.message }));
        return true;
      case 'PING':
        sendResponse({ status: 'alive' });
        break;
    }
    return true;
  });
})();
