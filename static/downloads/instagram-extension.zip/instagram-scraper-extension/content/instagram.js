// content/instagram.js — credential bridge only; extraction runs in the service worker

(function () {
  'use strict';

  function getHandle() {
    const m = window.location.pathname.match(/^\/([a-zA-Z0-9._]+)(?:\/(?:reels|posts|videos|tagged|igtv)?\/?)?$/);
    return m ? m[1] : null;
  }

  function getCsrf() {
    const m = document.cookie.match(/csrftoken=([^;]+)/);
    return m ? m[1] : '';
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    switch (msg.type) {
      case 'GET_CREDENTIALS':
        sendResponse({ csrf: getCsrf(), handle: getHandle() });
        break;
      case 'GET_PAGE_INFO':
        sendResponse({ handle: getHandle(), url: window.location.href, platform: 'instagram' });
        break;
      case 'PING':
        sendResponse({ status: 'alive' });
        break;
    }
    return true;
  });
})();
