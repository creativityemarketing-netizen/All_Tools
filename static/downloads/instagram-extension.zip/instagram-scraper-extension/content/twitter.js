// content/twitter.js - X/Twitter scraper via fetch interceptor

(function () {
  'use strict';

  let isExtracting = false;
  let stopRequested = false;
  let interceptedItems = [];
  let interceptorInstalled = false;

  function getHandle() {
    const m = window.location.pathname.match(/^\/([a-zA-Z0-9_]+)\/?$/);
    const excluded = ['home','explore','notifications','messages','i','settings','compose','search'];
    return (m && !excluded.includes(m[1])) ? m[1] : null;
  }

  // Inject fetch interceptor into page context
  function installInterceptor() {
    if (interceptorInstalled) return;
    interceptorInstalled = true;
    const script = document.createElement('script');
    script.textContent = `(function(){
      const _f = window.fetch;
      window.fetch = async function(...args) {
        const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
        const res = await _f.apply(this, args);
        if (url.includes('UserTweets') || url.includes('UserTweetsAndReplies') || url.includes('UserMedia')) {
          res.clone().json().then(d => {
            document.dispatchEvent(new CustomEvent('__tw_scraper_data', { detail: JSON.stringify(d) }));
          }).catch(()=>{});
        }
        return res;
      };
    })();`;
    (document.head || document.documentElement).prepend(script);
    script.remove();
  }

  function parseTweets(data) {
    const posts = [];
    try {
      const instructions =
        data?.data?.user?.result?.timeline_v2?.timeline?.instructions ||
        data?.data?.user?.result?.timeline?.timeline?.instructions || [];
      for (const inst of instructions) {
        if (inst.type !== 'TimelineAddEntries') continue;
        for (const entry of (inst.entries || [])) {
          const result = entry?.content?.itemContent?.tweet_results?.result;
          if (!result) continue;
          const tweetResult = result.__typename === 'TweetWithVisibilityResults' ? result.tweet : result;
          if (!tweetResult) continue;
          const legacy = tweetResult.legacy || {};
          if (!legacy.id_str) continue;
          const mediaEntities = legacy.extended_entities?.media || legacy.entities?.media || [];
          const firstMedia = mediaEntities[0];
          let mediaUrl = '', mediaType = 'text';
          if (firstMedia) {
            if (firstMedia.type === 'video' || firstMedia.type === 'animated_gif') {
              mediaType = 'video';
              const variants = (firstMedia.video_info?.variants || [])
                .filter(v => v.content_type === 'video/mp4')
                .sort((a,b) => (b.bitrate||0)-(a.bitrate||0));
              mediaUrl = variants[0]?.url || '';
            } else {
              mediaType = 'image';
              mediaUrl = (firstMedia.media_url_https || '') + '?format=jpg&name=large';
            }
          }
          const userResult = tweetResult.core?.user_results?.result?.legacy;
          const handle = userResult?.screen_name || legacy.user_id_str || '';
          posts.push({
            postId: legacy.id_str,
            postUrl: handle ? `https://x.com/${handle}/status/${legacy.id_str}` : `https://x.com/i/web/status/${legacy.id_str}`,
            caption: legacy.full_text || '',
            publishedAt: legacy.created_at ? new Date(legacy.created_at).toISOString() : '',
            mediaType,
            likesCount: legacy.favorite_count ?? 0,
            commentsCount: legacy.reply_count ?? 0,
            mediaUrl,
            thumbnailUrl: firstMedia?.media_url_https || '',
            carouselUrls: mediaEntities.map(m =>
              m.type === 'video' || m.type === 'animated_gif'
                ? (m.video_info?.variants||[]).filter(v=>v.content_type==='video/mp4').sort((a,b)=>(b.bitrate||0)-(a.bitrate||0))[0]?.url||''
                : (m.media_url_https||'')+'?format=jpg&name=large'
            ).filter(Boolean),
            ownerHandle: handle,
            platform: 'twitter',
          });
        }
      }
    } catch (e) {}
    return posts;
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function runExtraction(handle) {
    isExtracting = true;
    stopRequested = false;
    interceptedItems = [];

    try {
      installInterceptor();
      chrome.runtime.sendMessage({ type: 'EXTRACTION_STARTED', platform: 'twitter', handle });

      // Listen for intercepted data
      const onData = (event) => {
        try {
          const data = JSON.parse(event.detail);
          const posts = parseTweets(data);
          if (posts.length > 0) {
            interceptedItems.push(...posts);
            chrome.runtime.sendMessage({ type: 'POST_DATA', platform: 'twitter', handle, data: { normalizedItems: posts } });
          }
        } catch (e) {}
      };
      document.addEventListener('__tw_scraper_data', onData);

      // Scroll to trigger timeline loading
      window.scrollTo(0, 0);
      let noNewCount = 0;
      let lastCount = 0;

      while (!stopRequested && noNewCount < 5) {
        window.scrollBy(0, window.innerHeight * 1.5);
        await sleep(2000 + Math.random() * 500);

        if (interceptedItems.length === lastCount) {
          noNewCount++;
        } else {
          noNewCount = 0;
          lastCount = interceptedItems.length;
        }
      }

      document.removeEventListener('__tw_scraper_data', onData);
      chrome.runtime.sendMessage({ type: 'EXTRACTION_COMPLETE', platform: 'twitter' });
    } catch (err) {
      chrome.runtime.sendMessage({ type: 'EXTRACTION_ERROR', error: err.message });
    } finally { isExtracting = false; }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {
      case 'START_EXTRACTION':
        if (isExtracting) { sendResponse({ status: 'already_running' }); return; }
        const handle = getHandle();
        if (!handle) { sendResponse({ error: 'No Twitter handle in URL' }); return; }
        runExtraction(handle);
        sendResponse({ status: 'started' });
        break;
      case 'STOP_EXTRACTION':
        stopRequested = true; isExtracting = false;
        sendResponse({ status: 'stopped' });
        break;
      case 'GET_PAGE_INFO':
        sendResponse({ handle: getHandle(), url: window.location.href, platform: 'twitter' });
        break;
      case 'PING': sendResponse({ status: 'alive' }); break;
    }
    return true;
  });
})();
