// normalizer.js - Canonical post schema for all 4 platforms

function instagramDateFromId(mediaId) {
  try {
    const id = BigInt(String(mediaId || '').split('_')[0]);
    const timestampMs = (id >> 23n) + 1314220021721n;
    const date = new Date(Number(timestampMs));
    return Number.isNaN(date.getTime()) ? '' : date.toISOString();
  } catch (_) {
    return '';
  }
}

const Normalizer = {

  fromInstagram(item, defaultHandle = '') {
    const rawPostId = String(item.id || item.pk || '');
    const postId = rawPostId.split('_')[0];
    if (!postId) return null;
    const taken =
      item.taken_at ||
      item.taken_at_timestamp ||
      item.device_timestamp ||
      item.clips_metadata?.taken_at ||
      0;
    const shortcode = item.code || item.shortcode || '';
    const postUrl = shortcode
      ? `https://www.instagram.com/p/${shortcode}/`
      : `https://www.instagram.com/p/${postId}/`;
    const caption =
      item.caption?.text || (typeof item.caption === 'string' ? item.caption : '') || '';
    let mediaType = 'image';
    if (item._forceType) {
      mediaType = item._forceType;
    } else if (item.media_type === 2 || item.is_video || item.video_url || item.video_versions?.length) {
      mediaType = item.product_type === 'clips' ? 'reel' : 'video';
    } else if (item.media_type === 8 || item.carousel_media || item.carousel_media_count > 1) {
      mediaType = 'carousel';
    }
    const mediaUrl =
      item.video_url ||
      item.video_versions?.[0]?.url ||
      item.image_versions2?.candidates?.[0]?.url ||
      item.display_url || '';
    const thumbnailUrl =
      item.image_versions2?.candidates?.[0]?.url ||
      item.thumbnail_url || item.display_url || '';
    const durationMs =
      item.clips_metadata?.original_sound_info?.duration_in_ms ??
      item.music_metadata?.music_info?.music_asset_info?.duration_in_ms ??
      0;
    const rawVideoDuration = Number(
      item.video_duration ??
      item.video_versions?.[0]?.duration ??
      item.carousel_media?.find?.(slide => slide.video_duration)?.video_duration ??
      item.video_dash_manifest?.video_duration ??
      item.clips_metadata?.video_duration ??
      (durationMs ? durationMs / 1000 : 0)
    ) || 0;
    const videoDuration = mediaType === 'video' || mediaType === 'reel'
      ? (rawVideoDuration > 10000 ? rawVideoDuration / 1000 : rawVideoDuration)
      : 0;
    // Collect carousel URLs and per-slide IDs
    const carouselUrls = [];
    const carouselIds  = [];
    if (mediaType === 'carousel' && Array.isArray(item.carousel_media)) {
      for (const slide of item.carousel_media) {
        const u =
          slide.image_versions2?.candidates?.[0]?.url ||
          slide.display_url ||
          slide.thumbnail_url ||
          '';
        if (u) {
          carouselUrls.push(u);
          carouselIds.push(String(slide.id || slide.pk || '').split('_')[0]);
        }
      }
    }
    return {
      postId, shortcode, postUrl, caption,
      publishedAt: taken
        ? new Date(taken > 100000000000 ? taken : taken * 1000).toISOString()
        : instagramDateFromId(postId),
      mediaType,
      likesCount: item.like_count ?? item.likes?.count ?? 0,
      commentsCount: item.comment_count ?? item.comments_count ?? 0,
      mediaUrl,
      thumbnailUrl: thumbnailUrl || carouselUrls[0] || mediaUrl,
      videoDuration,
      carouselUrls, carouselIds,
      ownerHandle: item.user?.username || item.owner?.username || defaultHandle,
      platform: 'instagram',
    };
  },

  fromTikTok(item) {
    const postId = String(item.id || '');
    if (!postId) return null;
    const handle = item.author?.uniqueId || item.author?.nickname || '';
    return {
      postId,
      shortcode: postId,
      postUrl: `https://www.tiktok.com/@${handle}/video/${postId}`,
      caption: item.desc || '',
      publishedAt: item.createTime ? new Date(item.createTime * 1000).toISOString() : '',
      mediaType: 'video',
      videoDuration: Number(item.video?.duration ?? item.video?.durationSeconds ?? 0) || 0,
      likesCount: item.stats?.diggCount ?? item.stats?.heartCount ?? 0,
      commentsCount: item.stats?.commentCount ?? 0,
      mediaUrl: item.video?.downloadAddr || item.video?.playAddr || '',
      thumbnailUrl: item.video?.cover || item.video?.originCover || '',
      carouselUrls: [],
      ownerHandle: handle,
      platform: 'tiktok',
    };
  },

  fromTwitter(result) {
    if (!result) return null;
    const legacy = result.legacy || result.tweet?.legacy || {};
    const postId = result.rest_id || legacy.id_str || '';
    if (!postId) return null;
    const handle = legacy.user_id_str || result.core?.user_results?.result?.legacy?.screen_name || '';
    const mediaEntities = legacy.extended_entities?.media || legacy.entities?.media || [];
    const firstMedia = mediaEntities[0];
    let mediaUrl = '';
    let mediaType = 'text';
    if (firstMedia) {
      if (firstMedia.type === 'video' || firstMedia.type === 'animated_gif') {
        mediaType = 'video';
        const variants = (firstMedia.video_info?.variants || [])
          .filter(v => v.content_type === 'video/mp4')
          .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
        mediaUrl = variants[0]?.url || firstMedia.media_url_https || '';
      } else {
        mediaType = 'image';
        mediaUrl = (firstMedia.media_url_https || '') + '?format=jpg&name=large';
      }
    }
    const allMediaUrls = mediaEntities.map(m =>
      m.type === 'video' || m.type === 'animated_gif'
        ? (m.video_info?.variants || []).filter(v => v.content_type === 'video/mp4').sort((a,b)=>(b.bitrate||0)-(a.bitrate||0))[0]?.url || ''
        : (m.media_url_https || '') + '?format=jpg&name=large'
    ).filter(Boolean);
    return {
      postId,
      shortcode: postId,
      postUrl: `https://x.com/i/web/status/${postId}`,
      caption: legacy.full_text || '',
      publishedAt: legacy.created_at ? new Date(legacy.created_at).toISOString() : '',
      mediaType,
      videoDuration: Number(firstMedia?.video_info?.duration_millis || 0) / 1000 || 0,
      likesCount: legacy.favorite_count ?? 0,
      commentsCount: legacy.reply_count ?? 0,
      mediaUrl,
      thumbnailUrl: firstMedia?.media_url_https || '',
      carouselUrls: allMediaUrls,
      ownerHandle: handle,
      platform: 'twitter',
    };
  },

  fromFacebook(data) {
    const postId = String(data.postId || '');
    if (!postId) return null;
    return {
      postId,
      shortcode: postId,
      postUrl: data.postUrl || '',
      caption: data.caption || '',
      publishedAt: data.publishedAt || '',
      mediaType: data.mediaType || 'text',
      videoDuration: Number(data.videoDuration || 0) || 0,
      likesCount: 0,
      commentsCount: 0,
      mediaUrl: data.mediaUrl || '',
      thumbnailUrl: data.thumbnailUrl || '',
      carouselUrls: [],
      ownerHandle: data.ownerHandle || '',
      platform: 'facebook',
    };
  },
};

if (typeof module !== 'undefined' && module.exports) module.exports = Normalizer;
