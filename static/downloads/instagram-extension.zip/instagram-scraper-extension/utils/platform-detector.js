// platform-detector.js - Detects social media platform from URL

const EXCLUDED = {
  instagram: ['explore','reels','stories','accounts','p','reel','tv','direct','ar','challenge'],
  facebook:  ['groups','marketplace','watch','gaming','notifications','events','pages','help','login'],
  twitter:   ['home','explore','notifications','messages','i','settings','compose','hashtag','search'],
};

const PlatformDetector = {
  detect(url) {
    if (!url) return null;

    // Instagram — match profile root AND sub-pages like /reels/, /posts/, /tagged/
    let m = url.match(/^https?:\/\/(?:www\.)?instagram\.com\/([a-zA-Z0-9._]+)(?:\/(?:reels|posts|videos|tagged|igtv)?\/?)?(\?.*)?$/);
    if (m && !EXCLUDED.instagram.includes(m[1])) {
      return { platform: 'instagram', handle: m[1], color: '#e1306c', emoji: '📷' };
    }

    // TikTok
    m = url.match(/^https?:\/\/(?:www\.)?tiktok\.com\/@([a-zA-Z0-9._]+)\/?(\?.*)?$/);
    if (m) {
      return { platform: 'tiktok', handle: m[1], color: '#fe2c55', emoji: '🎵' };
    }

    // Facebook
    m = url.match(/^https?:\/\/(?:www\.)?facebook\.com\/([a-zA-Z0-9.]+)\/?(\?.*)?$/);
    if (m && !EXCLUDED.facebook.includes(m[1])) {
      return { platform: 'facebook', handle: m[1], color: '#1877f2', emoji: '👤' };
    }

    // X / Twitter
    m = url.match(/^https?:\/\/(?:www\.)?(?:x|twitter)\.com\/([a-zA-Z0-9_]+)\/?(\?.*)?$/);
    if (m && !EXCLUDED.twitter.includes(m[1])) {
      return { platform: 'twitter', handle: m[1], color: '#1d9bf0', emoji: '🐦' };
    }

    return null;
  },

  label(platform) {
    return { instagram: 'Instagram', tiktok: 'TikTok', facebook: 'Facebook', twitter: 'X / Twitter' }[platform] || platform;
  },
};

if (typeof module !== 'undefined' && module.exports) module.exports = PlatformDetector;
