// data-parser.js - Normalizes Instagram GraphQL nodes into flat post objects

const DataParser = {
  parseResponse(data) {
    const results = { posts: [], pageInfo: null };
    if (!data || typeof data !== 'object') return results;
    this._walk(data, results, 0);
    return results;
  },

  _walk(obj, results, depth) {
    if (!obj || typeof obj !== 'object' || depth > 12) return;

    // Detect containers by key name
    const containerKeys = [
      'edge_owner_to_timeline_media',
      'xdt_api__v1__feed__user_timeline_connection',
      'xdt_api__v1__user__web_profile_info__connection',
      'edge_user_to_photos_of_you',
      'edge_hashtag_to_media',
      'edge_hashtag_to_top_posts',
      'edge_web_feed_timeline',
      'edges',          // generic edges array
    ];

    for (const key of containerKeys) {
      if (obj[key] && typeof obj[key] === 'object') {
        this._extractContainer(obj[key], results);
      }
    }

    // Look for inline media arrays (newer API: items[])
    if (Array.isArray(obj.items)) {
      for (const item of obj.items) {
        const post = this._parseNode(item);
        if (post) results.posts.push(post);
      }
    }

    // Look for media_or_ad arrays
    if (Array.isArray(obj.media_or_ad)) {
      for (const item of obj.media_or_ad) {
        const post = this._parseNode(item);
        if (post) results.posts.push(post);
      }
    }

    // Recurse into plain objects (not arrays handled above)
    for (const [key, value] of Object.entries(obj)) {
      if (
        value &&
        typeof value === 'object' &&
        !containerKeys.includes(key) &&
        key !== 'items' &&
        key !== 'media_or_ad'
      ) {
        this._walk(value, results, depth + 1);
      }
    }
  },

  _extractContainer(container, results) {
    // Page info
    const pi = container.page_info || container.pageInfo;
    if (pi) {
      results.pageInfo = {
        hasNextPage: pi.has_next_page ?? pi.hasNextPage ?? false,
        endCursor: pi.end_cursor ?? pi.endCursor ?? null,
      };
    }

    // Edges → nodes
    const edges = Array.isArray(container.edges) ? container.edges : [];
    for (const edge of edges) {
      const node = edge.node || edge;
      if (node && typeof node === 'object') {
        const post = this._parseNode(node);
        if (post) results.posts.push(post);
      }
    }

    // Inline nodes array
    const nodes = Array.isArray(container.nodes) ? container.nodes : [];
    for (const node of nodes) {
      const post = this._parseNode(node);
      if (post) results.posts.push(post);
    }
  },

  _parseNode(node) {
    if (!node || typeof node !== 'object') return null;

    // Must have some identifier
    const postId = node.id || node.pk || node.media_id || null;
    if (!postId) return null;

    // Must have a timestamp to be a post
    const timestamp = node.taken_at_timestamp || node.taken_at || node.device_timestamp || 0;
    if (!timestamp) return null;

    const shortcode = node.shortcode || node.code || node.share_url?.split('/p/')?.[1]?.replace('/', '') || '';
    const postUrl = shortcode
      ? `https://www.instagram.com/p/${shortcode}/`
      : `https://www.instagram.com/p/${postId}/`;

    // Caption
    let caption = '';
    if (node.edge_media_to_caption?.edges?.[0]?.node?.text) {
      caption = node.edge_media_to_caption.edges[0].node.text;
    } else if (node.caption?.text) {
      caption = node.caption.text;
    } else if (typeof node.caption === 'string') {
      caption = node.caption;
    } else if (node.accessibility_caption) {
      caption = node.accessibility_caption;
    }

    // Date
    const publishedAt = new Date(timestamp * 1000).toISOString();

    // Media type
    let mediaType = 'image';
    const typename = node.__typename || '';
    if (
      typename.toLowerCase().includes('video') ||
      node.is_video ||
      node.media_type === 2 ||
      node.product_type === 'igtv' ||
      node.product_type === 'clips'
    ) {
      mediaType = node.product_type === 'clips' ? 'reel' : 'video';
    } else if (
      typename.toLowerCase().includes('sidecar') ||
      node.media_type === 8 ||
      node.carousel_media ||
      node.carousel_media_count > 1
    ) {
      mediaType = 'carousel';
    }

    // Counts
    const likesCount =
      node.edge_media_preview_like?.count ??
      node.edge_liked_by?.count ??
      node.like_count ??
      node.likes?.count ??
      0;

    const commentsCount =
      node.edge_media_to_comment?.count ??
      node.edge_media_preview_comment?.count ??
      node.comment_count ??
      node.comments?.count ??
      0;

    // Media URL — prefer highest quality
    const imageVersions = node.image_versions2?.candidates;
    const bestImage = imageVersions?.[0]?.url || '';
    const mediaUrl =
      node.video_url ||
      node.display_url ||
      bestImage ||
      node.thumbnail_src ||
      '';
    const thumbnailUrl =
      node.thumbnail_src ||
      bestImage ||
      node.display_url ||
      node.thumbnail_resources?.[0]?.src ||
      '';
    const videoDuration = Number(
      node.video_duration ??
      node.video_dash_manifest?.video_duration ??
      0
    ) || 0;

    // Owner
    const ownerUsername =
      node.owner?.username ||
      node.user?.username ||
      '';

    return {
      postId: String(postId),
      shortcode,
      postUrl,
      caption,
      publishedAt,
      mediaType,
      likesCount,
      commentsCount,
      videoDuration,
      mediaUrl,
      thumbnailUrl,
      ownerUsername,
    };
  },
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = DataParser;
}
