// download-queue.js - Media download queue manager using chrome.downloads API

function friendlyDownloadError(error) {
  const code = String(error || 'download-failed');
  if (code.includes('FILE_NO_SPACE')) {
    return 'Not enough disk space. Free some space or choose another destination folder.';
  }
  if (code.includes('USER_CANCELED')) return 'Download cancelled.';
  if (code.includes('FILE_TOO_LARGE')) {
    return 'The file is too large for the selected destination.';
  }
  return code;
}

const DownloadQueue = {
  _queues:   new Map(), // tabId → [item]
  _active:   new Map(), // downloadId → { tabId, item }
  _progress: new Map(), // tabId → { total, completed, failed, percent, currentFilename }
  MAX_CONCURRENT: 3,
  _activeCount: 0,
  _unsafeHeaderNames: new Set([
    'accept-charset',
    'accept-encoding',
    'access-control-request-headers',
    'access-control-request-method',
    'connection',
    'content-length',
    'cookie',
    'date',
    'dnt',
    'expect',
    'host',
    'keep-alive',
    'origin',
    'referer',
    'te',
    'trailer',
    'transfer-encoding',
    'upgrade',
    'via',
  ]),

  getProgress(tabId) {
    return this._progress.get(tabId) || { total: 0, completed: 0, failed: 0, percent: 0, currentFilename: '', lastError: '' };
  },

  _safeHeaders(headers) {
    return (headers || []).filter(h => {
      const name = String(h?.name || '').toLowerCase();
      return name && !name.startsWith('proxy-') && !name.startsWith('sec-') && !this._unsafeHeaderNames.has(name);
    });
  },

  // Regular enqueue — saves to default social-scraper/instagram/ without asking.
  enqueue(items, tabId) {
    const queue = items.map(item => ({ ...item, status: 'pending', retries: 0 }));
    this._queues.set(tabId, queue);
    this._progress.set(tabId, { total: items.length, completed: 0, failed: 0, percent: 0, currentFilename: '', lastError: '' });
    this._saveProgress(tabId);
    for (let i = 0; i < Math.min(this.MAX_CONCURRENT, items.length); i++) {
      this._processNext(tabId);
    }
  },

  // Save-as-once enqueue:
  //   • Shows ONE save dialog for the first file so the user picks a folder.
  //   • Persists the remaining items in chrome.storage.session so they survive a SW restart.
  //   • Once the first download goes in_progress (user clicked Save), all remaining
  //     files are downloaded silently to the same folder.
  enqueueSaveAs(items, tabId) {
    if (!items.length) return;

    const queue = items.map((item, idx) => ({
      ...item,
      status:         idx === 0 ? 'downloading' : 'waiting',
      retries:        0,
      _isBatchLeader: idx === 0,
    }));
    this._queues.set(tabId, queue);
    this._progress.set(tabId, { total: items.length, completed: 0, failed: 0, percent: 0, currentFilename: '', lastError: '' });
    this._saveProgress(tabId);
    this._activeCount++;

    const first = queue[0];
    const prog  = this._progress.get(tabId);
    if (prog) prog.currentFilename = first.filename;
    this._saveProgress(tabId);

    const opts = {
      url:            first.mediaUrl,
      filename:       first.filename, // bare name — the dialog shows the clean filename
      saveAs:         true,
      conflictAction: 'uniquify',
    };
    const safeHeaders = this._safeHeaders(first.headers);
    if (safeHeaders.length) opts.headers = safeHeaders;

    chrome.downloads.download(opts, (downloadId) => {
      if (chrome.runtime.lastError || downloadId == null) {
        this._activeCount = Math.max(0, this._activeCount - 1);
        first.status = 'failed';
        this._updateProgress(tabId, false, chrome.runtime.lastError?.message || 'download-start-failed');
        return;
      }
      this._active.set(downloadId, { tabId, item: first });

      // Persist batch so the SW can restore it after a restart.
      // (The save dialog can stay open for many seconds, long enough for the SW to die.)
      chrome.storage.session.set({
        scs_batch: {
          leaderId:    downloadId,
          leaderFile:  first.filename,
          tabId,
          remaining: queue.slice(1).map(i => ({
            postId:   i.postId,
            mediaUrl: i.mediaUrl,
            filename: i.filename,
            platform: i.platform,
            headers:  i.headers || [],
          })),
        },
      });
    });
  },

  // Called once the chosen directory is known; unlocks all 'waiting' items.
  _startBatchRemainder(tabId, chosenDir) {
    const queue = this._queues.get(tabId) || [];
    queue.forEach(item => {
      if (item.status !== 'waiting') return;
      item.status    = 'pending';
      item._filename = this._resolveFilename(item, chosenDir);
    });
    const slots = this.MAX_CONCURRENT - this._activeCount;
    for (let i = 0; i < slots; i++) this._processNext(tabId);
  },

  // Called after a SW restart: rebuilds the queue from session data and starts downloads.
  _restoreAndStartBatch(batch, chosenDir) {
    chrome.storage.session.remove('scs_batch');
    if (!batch.remaining?.length) return;

    const { tabId } = batch;
    const items = batch.remaining.map(i => ({
      ...i,
      status:    'pending',
      retries:   0,
      _filename: this._resolveFilename(i, chosenDir),
    }));

    // If the queue was already set up (SW didn't fully restart), merge;
    // otherwise create a fresh queue.
    const existing = this._queues.get(tabId);
    if (existing?.length) {
      items.forEach(ni => {
        const idx = existing.findIndex(ei => ei.postId === ni.postId);
        if (idx >= 0) existing[idx] = ni; else existing.push(ni);
      });
    } else {
      this._queues.set(tabId, items);
      this._progress.set(tabId, {
        total: items.length, completed: 0, failed: 0, percent: 0, currentFilename: '', lastError: '',
      });
      this._saveProgress(tabId);
    }

    const slots = Math.min(this.MAX_CONCURRENT - this._activeCount, items.length);
    for (let i = 0; i < slots; i++) this._processNext(tabId);
  },

  _resolveFilename(item, chosenDir) {
    // chosenDir: relative path within Downloads, e.g. "Instagram/" or "" or null
    if (chosenDir !== null) return chosenDir + item.filename;
    return `social-scraper/${item.platform}/${item.filename}`;
  },

  cancel(tabId) {
    const queue = this._queues.get(tabId) || [];
    for (const item of queue) {
      if (item.status === 'pending' || item.status === 'waiting') item.status = 'cancelled';
    }
    for (const [dlId, entry] of this._active.entries()) {
      if (entry.tabId === tabId) {
        chrome.downloads.cancel(dlId, () => {});
        this._active.delete(dlId);
        this._activeCount = Math.max(0, this._activeCount - 1);
      }
    }
    chrome.storage.session.remove('scs_batch');
    const prog = this._progress.get(tabId);
    if (prog) { prog.currentFilename = 'Cancelled'; this._saveProgress(tabId); }
  },

  _processNext(tabId) {
    if (this._activeCount >= this.MAX_CONCURRENT) return;
    const queue = this._queues.get(tabId) || [];
    // Skip 'waiting' items — they need the batch leader's directory first.
    const item = queue.find(i => i.status === 'pending');
    if (!item) return;

    item.status = 'downloading';
    this._activeCount++;

    const prog = this._progress.get(tabId);
    if (prog) prog.currentFilename = item.filename;
    this._saveProgress(tabId);

    if (item.fetchFirst) {
      this._processFetchedDownload(tabId, item);
      return;
    }

    // chrome.downloads.download() is NOT a JS fetch — CORS rules do not apply.
    // Chrome's download manager sends the request like a user clicking a link,
    // including the user's cookies for that domain.
    const opts = {
      url:            item.mediaUrl,
      filename:       item._filename || `social-scraper/${item.platform}/${item.filename}`,
      conflictAction: 'uniquify',
      saveAs:         false,
    };
    const safeHeaders = this._safeHeaders(item.headers);
    if (safeHeaders.length) opts.headers = safeHeaders;

    chrome.downloads.download(opts, (downloadId) => {
      if (chrome.runtime.lastError || downloadId == null) {
        this._activeCount = Math.max(0, this._activeCount - 1);
        item.status = 'failed';
        this._updateProgress(tabId, false, chrome.runtime.lastError?.message || 'download-start-failed');
        this._processNext(tabId);
        return;
      }
      this._active.set(downloadId, { tabId, item });
    });
  },

  async _processFetchedDownload(tabId, item) {
    try {
      const headerObj = {};
      for (const h of (item.headers || [])) {
        if (h?.name) headerObj[h.name] = h.value || '';
      }

      const resp = await fetch(item.mediaUrl, {
        credentials: 'include',
        referrer: 'https://www.instagram.com/',
        headers: headerObj,
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);

      const bytes = new Uint8Array(await resp.arrayBuffer());
      if (!bytes.length) throw new Error('empty-file');

      const isMp4 = bytes.length > 11 &&
        bytes[4] === 0x66 && bytes[5] === 0x74 && bytes[6] === 0x79 && bytes[7] === 0x70;
      const mime = isMp4
        ? 'video/mp4'
        : (resp.headers.get('content-type') || 'image/jpeg').split(';')[0];
      if (isMp4) {
        item.filename = item.filename.replace(/\.(jpg|jpeg|png|webp)$/i, '.mp4');
        if (item._filename) item._filename = item._filename.replace(/\.(jpg|jpeg|png|webp)$/i, '.mp4');
      }

      let binary = '';
      const CHUNK = 65536;
      for (let i = 0; i < bytes.length; i += CHUNK) {
        binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
      }
      const dataUrl = `data:${mime};base64,` + btoa(binary);
      const opts = {
        url: dataUrl,
        filename: item._filename || `social-scraper/${item.platform}/${item.filename}`,
        conflictAction: 'uniquify',
        saveAs: false,
      };

      chrome.downloads.download(opts, (downloadId) => {
        if (chrome.runtime.lastError || downloadId == null) {
          this._activeCount = Math.max(0, this._activeCount - 1);
          item.status = 'failed';
          this._updateProgress(tabId, false, chrome.runtime.lastError?.message || 'download-start-failed');
          this._processNext(tabId);
          return;
        }
        this._active.set(downloadId, { tabId, item });
      });
    } catch (_) {
      this._activeCount = Math.max(0, this._activeCount - 1);
      item.status = 'failed';
      this._updateProgress(tabId, false, 'fetch-before-download-failed');
      this._processNext(tabId);
    }
  },

  _onDownloadChanged(delta) {
    const entry = this._active.get(delta.id);

    // ── SW-restart recovery ──────────────────────────────────────────────────
    // The SW was killed while the save dialog was open. Now it woke up for this
    // event. _active is empty so we read the persisted batch from session storage.
    if (!entry) {
      const relevantState = delta.state?.current;
      if (relevantState === 'in_progress' || relevantState === 'complete') {
        chrome.storage.session.get('scs_batch', (r) => {
          const batch = r.scs_batch;
          if (!batch || batch.leaderId !== delta.id) return;
          chrome.downloads.search({ id: delta.id }, (results) => {
            const fullPath  = results?.[0]?.filename || '';
            const chosenDir = fullPath
              ? this._extractRelativeDir(fullPath, batch.leaderFile)
              : null;
            this._restoreAndStartBatch(batch, chosenDir);
          });
        });
      } else if (delta.state?.current === 'interrupted') {
        chrome.storage.session.get('scs_batch', (r) => {
          if (r.scs_batch?.leaderId === delta.id) {
            chrome.storage.session.remove('scs_batch');
          }
        });
      }
      return;
    }

    // ── Normal path (SW still alive) ─────────────────────────────────────────
    const { tabId, item } = entry;

    // Batch leader went in_progress = user confirmed the Save dialog.
    if (item._isBatchLeader && delta.state?.current === 'in_progress' && !item._batchStarted) {
      item._batchStarted = true;
      chrome.downloads.search({ id: delta.id }, (results) => {
        const fullPath  = results?.[0]?.filename || '';
        const chosenDir = fullPath
          ? this._extractRelativeDir(fullPath, item.filename)
          : null;
        this._startBatchRemainder(tabId, chosenDir);
        chrome.storage.session.remove('scs_batch');
      });
    }

    if (delta.state?.current === 'complete') {
      this._active.delete(delta.id);
      this._activeCount = Math.max(0, this._activeCount - 1);
      item.status = 'done';
      this._updateProgress(tabId, true);
      this._processNext(tabId);
    } else if (delta.state?.current === 'interrupted') {
      this._active.delete(delta.id);
      this._activeCount = Math.max(0, this._activeCount - 1);
      const interruptionError = delta.error?.current || 'interrupted';

      if (item._isBatchLeader) {
        // User cancelled the Save dialog — abort the whole batch.
        const queue = this._queues.get(tabId) || [];
        queue.forEach(i => {
          if (i.status !== 'waiting' && i.status !== 'pending') return;
          i.status = interruptionError === 'FILE_NO_SPACE' ? 'failed' : 'cancelled';
          this._updateProgress(tabId, false, interruptionError);
        });
        this._updateProgress(tabId, false, interruptionError);
        chrome.storage.session.remove('scs_batch');
      } else if (interruptionError === 'FILE_NO_SPACE') {
        item.status = 'failed';
        this._updateProgress(tabId, false, interruptionError);

        // A full destination drive cannot be fixed by retrying.
        const queue = this._queues.get(tabId) || [];
        queue.forEach(queuedItem => {
          if (queuedItem.status !== 'pending' && queuedItem.status !== 'waiting') return;
          queuedItem.status = 'failed';
          this._updateProgress(tabId, false, interruptionError);
        });
      } else if (item.retries < 2) {
        item.retries++;
        item.status = 'pending';
        this._processNext(tabId);
      } else {
        item.status = 'failed';
        this._updateProgress(tabId, false, interruptionError);
        this._processNext(tabId);
      }
    }
  },

  // Returns the directory relative to the Downloads folder.
  // e.g. "<Downloads>\Instagram\file.jpg" → "Instagram/"
  // Returns "" if the user saved directly in Downloads.
  // Returns null if the path is outside Downloads (fall back to default folder).
  _extractRelativeDir(fullPath, filename) {
    const p    = fullPath.replace(/\\/g, '/');
    const base = filename.split('/').pop();
    const idx  = p.lastIndexOf('/' + base);
    if (idx < 0) return null;
    const dir = p.slice(0, idx + 1); // ends with /
    const m   = dir.match(/[Dd]ownloads\/(.*)/);
    return m ? m[1] : null;
  },

  _updateProgress(tabId, success, error) {
    const prog = this._progress.get(tabId);
    if (!prog) return;
    if (success) {
      prog.completed++;
      prog.lastError = '';
    } else {
      prog.failed++;
      prog.lastError = friendlyDownloadError(error);
    }
    prog.percent = Math.round((prog.completed + prog.failed) / prog.total * 100);
    this._saveProgress(tabId);
  },

  _saveProgress(tabId) {
    const prog = this._progress.get(tabId);
    chrome.storage.session.set({ [`dl_progress_${tabId}`]: prog });
  },
};

chrome.downloads.onChanged.addListener((delta) => DownloadQueue._onDownloadChanged(delta));

function buildFilename(platform, handle, postId, index, mediaUrl, isVideo) {
  const ext = isVideo || /\.mp4|video\/mp4|mime_type=video/i.test(mediaUrl) ? 'mp4' : 'jpg';
  return `${platform}-${handle}-${postId}.${ext}`;
}

const PLATFORM_HEADERS = {
  tiktok:    [{ name: 'Referer', value: 'https://www.tiktok.com/' }],
  // Chrome may reject privileged headers such as Referer/Origin in downloads.
  // Keep Instagram downloads header-free so CDN media URLs download like normal links.
  instagram: [],
  facebook:  [{ name: 'Referer', value: 'https://www.facebook.com/' }],
  twitter:   [],
};
