// csv-generator.js - Generates CSV from normalized post objects (all platforms)

const CsvGenerator = {
  COLUMNS: [
    { key: 'platform',      header: 'Platform' },
    { key: 'ownerHandle',   header: 'Account' },
    { key: 'postId',        header: 'Post ID' },
    { key: 'postUrl',       header: 'Post URL' },
    { key: 'caption',       header: 'Caption' },
    { key: 'publishedAt',   header: 'Published At' },
    { key: 'mediaType',     header: 'Media Type' },
    { key: 'videoDurationFormatted', header: 'Video Duration' },
    { key: 'likesCount',    header: 'Likes' },
    { key: 'commentsCount', header: 'Comments' },
    { key: 'mediaUrl',      header: 'Media URL' },
    { key: 'thumbnailUrl',  header: 'Thumbnail URL' },
    { key: '_thumbnail',    header: 'Thumbnail' },
  ],

  escapeField(value) {
    const str = value == null ? '' : String(value);
    if (str.includes('"') || str.includes(',') || str.includes('\n') || str.includes('\r')) {
      return '"' + str.replace(/"/g, '""') + '"';
    }
    return str;
  },

  generate(posts) {
    const headerRow = this.COLUMNS.map(c => c.header).join(',');
    const dataRows = posts.map(post => {
      const enriched = {
        ...post,
        videoDurationFormatted: this.formatDuration(post.videoDuration),
        _thumbnail: post.thumbnailUrl ? `=IMAGE("${post.thumbnailUrl}")` : '',
      };
      return this.COLUMNS.map(c => this.escapeField(enriched[c.key])).join(',');
    });
    return '\uFEFF' + headerRow + '\r\n' + dataRows.join('\r\n');
  },

  formatDuration(seconds) {
    const total = Math.round(Number(seconds || 0));
    if (!total) return '';
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    return h > 0
      ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
      : `${m}:${String(s).padStart(2, '0')}`;
  },

  getFilename(platform, handle) {
    const date = new Date().toISOString().slice(0, 10);
    const p = (platform || 'social').replace(/[^a-zA-Z0-9]/g, '');
    const h = (handle || 'unknown').replace(/[^a-zA-Z0-9._-]/g, '_');
    return `${p}-${h}-${date}.csv`;
  },
};

if (typeof module !== 'undefined' && module.exports) module.exports = CsvGenerator;
