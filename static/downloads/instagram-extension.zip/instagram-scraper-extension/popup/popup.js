// popup.js - Multi-platform popup UI with search, profile card, table, and Excel export

(function () {
  'use strict';

  // ── DOM refs ──────────────────────────────────────────────────────────────
  const header          = document.getElementById('header');
  const appTitle        = document.getElementById('app-title');
  const statusIcon      = document.getElementById('status-icon');
  const statusText      = document.getElementById('status-text');
  const profileInfo     = document.getElementById('profile-info');
  const usernameEl      = document.getElementById('username');
  const profileCard     = document.getElementById('profile-card');
  const profileName     = document.getElementById('profile-name');
  const profileHandle   = document.getElementById('profile-handle');
  const statPosts       = document.getElementById('stat-posts');
  const statFollowers   = document.getElementById('stat-followers');
  const tabNav          = document.getElementById('tab-nav');
  const tabMetadata     = document.getElementById('tab-metadata');
  const tabDownloads    = document.getElementById('tab-downloads');
  const progressSection = document.getElementById('progress-section');
  const postCountEl     = document.getElementById('post-count');
  const reelCountEl     = document.getElementById('reel-count');
  const elapsedEl       = document.getElementById('elapsed-time');
  const extractProgress = document.getElementById('extract-progress');
  const scrollingInd    = document.getElementById('scrolling-indicator');
  const btnExtract      = document.getElementById('btn-extract');
  const btnStop         = document.getElementById('btn-stop');
  const btnDownloadXL   = document.getElementById('btn-download-excel');
  const btnClear        = document.getElementById('btn-clear');
  const tableWrap       = document.getElementById('table-wrap');
  const postsTbody      = document.getElementById('posts-tbody');
  const errorMsg        = document.getElementById('error-msg');
  const fetchStats      = document.getElementById('fetch-stats');
  const fetchedCountEl  = document.getElementById('fetched-count');
  // Downloads tab
  const btnDlMedia      = document.getElementById('btn-download-media');
  const dlProgressSec   = document.getElementById('dl-progress-section');
  const dlProgressBar   = document.getElementById('dl-progress-bar');
  const dlCount         = document.getElementById('dl-count');
  const dlPercent       = document.getElementById('dl-percent');
  const dlFilename      = document.getElementById('dl-filename');
  const btnCancelDl     = document.getElementById('btn-cancel-dl');
  // Date filter
  const dateFilter      = document.getElementById('date-filter');
  const filterFrom      = document.getElementById('filter-from');
  const filterTo        = document.getElementById('filter-to');
  const btnApplyFilter  = document.getElementById('btn-apply-filter');
  const filterStatus    = document.getElementById('filter-status');
  // Video-only download
  const btnDlVideos     = document.getElementById('btn-dl-videos');
  // Download format toggle
  const btnModeFiles    = document.getElementById('btn-mode-files');
  const btnModeZip      = document.getElementById('btn-mode-zip');

  let currentTabId    = null;
  let currentHandle   = null;
  let currentPlatform = null;
  let timerInterval   = null;
  let startTime       = null;
  let pollInterval    = null;
  let dlPollInterval  = null;
  let zipPollInterval = null;
  let lastTotalPosts  = 0;
  let lastProfileShown = false;
  let downloadMode       = 'files'; // 'files' | 'zip'
  let folderDlCancelled  = false;
  let downloadCancelled  = false;

  const PLATFORM_STYLES = {
    instagram: { gradient: 'linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888)', emoji: '📷', label: 'Instagram' },
    tiktok:    { gradient: 'linear-gradient(45deg,#010101,#fe2c55)', emoji: '🎵', label: 'TikTok' },
    facebook:  { gradient: 'linear-gradient(45deg,#1877f2,#0d5fbd)', emoji: '👤', label: 'Facebook' },
    twitter:   { gradient: 'linear-gradient(45deg,#1d9bf0,#0c6aad)', emoji: '🐦', label: 'X / Twitter' },
  };

  // ── Helpers ───────────────────────────────────────────────────────────────
  const show = el => el.classList.remove('hidden');
  const hide = el => el.classList.add('hidden');

  function setStatus(type, text) {
    statusIcon.className = 'status-icon ' + (type || '');
    statusText.textContent = text;
  }
  function showError(text) { errorMsg.textContent = text; show(errorMsg); }
  function clearError()    { hide(errorMsg); }

  function formatElapsed(ms) {
    const s = Math.floor(ms / 1000);
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  }
  function formatNum(n) {
    if (n == null) return '-';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return String(n);
  }
  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function parseDisplayDate(value) {
    const raw = String(value || '').trim();
    if (!raw) return { iso: null, display: '' };
    const match = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (!match) return { error: 'Use date format dd/mm/yyyy' };
    const day = Number(match[1]);
    const month = Number(match[2]);
    const year = Number(match[3]);
    const date = new Date(year, month - 1, day);
    if (
      date.getFullYear() !== year ||
      date.getMonth() !== month - 1 ||
      date.getDate() !== day
    ) return { error: 'Enter a valid date' };
    return {
      iso: `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`,
      display: `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`,
    };
  }
  function formatDisplayDate(iso) {
    const match = String(iso || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return match ? `${match[3]}/${match[2]}/${match[1]}` : '';
  }
  function getDateFilterValues() {
    const from = parseDisplayDate(filterFrom.value);
    if (from.error) return { error: 'From date: ' + from.error };
    const to = parseDisplayDate(filterTo.value);
    if (to.error) return { error: 'To date: ' + to.error };
    if (from.iso && to.iso && from.iso > to.iso) return { error: 'From date must be before To date' };
    return { from, to };
  }

  function getCurrentState() {
    return new Promise(resolve => {
      chrome.runtime.sendMessage({ type: 'GET_STATE', tabId: currentTabId }, state => {
        if (chrome.runtime.lastError) resolve(null);
        else resolve(state || null);
      });
    });
  }

  function showDownloadStarting(message) {
    downloadCancelled = false;
    show(dlProgressSec);
    show(btnCancelDl);
    dlProgressBar.classList.remove('complete');
    dlProgressBar.classList.add('loading');
    dlProgressBar.style.width = '45%';
    dlCount.textContent = 'Starting';
    dlPercent.textContent = '';
    dlFilename.textContent = message;
  }

  function showDownloadError(message) {
    hide(dlProgressSec);
    showError(message);
  }

  function waitForExtractionReady() {
    return new Promise(resolve => {
      let tries = 0;
      const maxTries = 900;
      const timer = setInterval(async () => {
        tries++;
        if (downloadCancelled) {
          clearInterval(timer);
          resolve({ error: 'Download stopped' });
          return;
        }
        const state = await getCurrentState();
        refreshState();
        if (!state) {
          clearInterval(timer);
          resolve({ error: 'Could not read extraction state' });
          return;
        }
        if (state.lastError) {
          clearInterval(timer);
          resolve({ error: state.lastError });
          return;
        }
        if (!state.isExtracting) {
          clearInterval(timer);
          resolve(state.totalPosts > 0 ? { ok: true } : { error: 'No posts found to download' });
          return;
        }
        if (tries >= maxTries) {
          clearInterval(timer);
          resolve({ error: 'Extraction took too long. Try extracting posts first, then download.' });
        }
      }, 1000);
    });
  }

  async function ensurePostsReadyForDownload() {
    const state = await getCurrentState();
    if (state?.totalPosts > 0) return true;
    if (!currentTabId || !currentHandle) return false;

    const dates = getDateFilterValues();
    if (dates.error) {
      showError(dates.error);
      return false;
    }

    setStatus('working', 'Extracting posts before download...');
    showDownloadStarting('Extracting posts before download...');
    btnDlMedia.disabled = true;
    btnDlVideos.disabled = true;

    const started = await new Promise(resolve => {
      chrome.runtime.sendMessage({
        type: 'START_EXTRACTION',
        tabId: currentTabId,
        dateFilterFrom: dates.from.iso,
        dateFilterTo:   dates.to.iso,
      }, resp => {
        if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
        else resolve(resp || {});
      });
    });

    if (started?.error) {
      btnDlMedia.disabled = false;
      btnDlVideos.disabled = false;
      showDownloadError(started.error);
      return false;
    }

    setExtracting();
    const ready = await waitForExtractionReady();
    btnDlMedia.disabled = false;
    btnDlVideos.disabled = false;
    if (ready.error) {
      showDownloadError(ready.error);
      return false;
    }
    return true;
  }

  function startTimer() {
    startTime = Date.now();
    timerInterval = setInterval(() => {
      elapsedEl.textContent = formatElapsed(Date.now() - startTime);
    }, 1000);
  }
  function stopTimer() { clearInterval(timerInterval); timerInterval = null; }

  function applyPlatform(platform) {
    const style = PLATFORM_STYLES[platform] || PLATFORM_STYLES.instagram;
    header.style.background = style.gradient;
    appTitle.textContent = style.label + ' Scraper';
  }

  // ── Tab switching ─────────────────────────────────────────────────────────
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tab = btn.dataset.tab;
      if (tab === 'metadata') { show(tabMetadata); hide(tabDownloads); stopDlPoll(); }
      else                    { hide(tabMetadata); show(tabDownloads); startDlPoll(); }
    });
  });

  // ── Polling ───────────────────────────────────────────────────────────────
  function startPolling() { pollInterval = setInterval(refreshState, 1200); }
  function stopPolling()  { clearInterval(pollInterval); pollInterval = null; }
  function startDlPoll()  { if (!dlPollInterval) dlPollInterval = setInterval(refreshDownloadProgress, 800); }
  function stopDlPoll()   { clearInterval(dlPollInterval); dlPollInterval = null; }

  function startZipPoll() {
    if (zipPollInterval) return;
    zipPollInterval = setInterval(() => {
      if (!currentTabId) return;
      chrome.storage.session.get(`zip_${currentTabId}`, (r) => {
        const p = r[`zip_${currentTabId}`];
        if (!p || p.total === 0) return;
        const pct = Math.round(p.done / p.total * 100);
        dlProgressBar.style.width = pct + '%';
        dlCount.textContent    = `${p.done} / ${p.total}`;
        dlPercent.textContent  = pct + '%';
        dlFilename.textContent = p.done < p.total ? 'Download in progress...' : 'Compressing ZIP...';
      });
    }, 600);
  }
  function stopZipPoll() { clearInterval(zipPollInterval); zipPollInterval = null; }

  [filterFrom, filterTo].forEach(input => {
    input.addEventListener('input', () => {
      input.value = input.value
        .replace(/[^\d/]/g, '')
        .replace(/^(\d{2})(\d)/, '$1/$2')
        .replace(/^(\d{2}\/\d{2})(\d)/, '$1/$2')
        .slice(0, 10);
    });
  });

  function refreshState() {
    if (!currentTabId) return;
    chrome.runtime.sendMessage({ type: 'GET_STATE', tabId: currentTabId }, (state) => {
      if (chrome.runtime.lastError || !state) return;

      // Update counts
      const feed    = state.feedCount    || 0;
      const reels   = state.reelCount    || 0;
      const total   = state.totalPosts   || 0;
      const fetched = state.fetchedTotal || 0;
      postCountEl.textContent = feed;
      reelCountEl.textContent = reels;

      // Show raw fetch progress when a date filter is active and matched count is 0
      if (state.isExtracting && fetched > 0 && (state.dateFilterFrom || state.dateFilterTo)) {
        fetchedCountEl.textContent  = fetched;
        fetchStats.style.display    = 'block';
      } else {
        fetchStats.style.display    = 'none';
      }

      // Progress bar: estimate against expected postCount from profile
      if (state.isExtracting) {
        const expected = state.profile?.postCount || 0;
        if (expected > 0 && feed > 0) {
          const pct = Math.min(90, Math.round((feed / expected) * 70));
          extractProgress.style.width = pct + '%';
        } else if (total > 0) {
          // indeterminate-ish: grow slowly up to 50%
          const pct = Math.min(50, Math.round(total / 5));
          extractProgress.style.width = pct + '%';
        }
      }

      // Profile card (only populate once)
      if (state.profile && !lastProfileShown) {
        updateProfileCard(state.profile);
        lastProfileShown = true;
      }

      // Show table if we have posts
      if (total > 0) {
        show(progressSection);
        btnDownloadXL.disabled = false;
        btnClear.disabled      = false;
        btnDlMedia.disabled    = false;
        btnDlVideos.disabled   = false;
        btnApplyFilter.disabled = false;
        show(dateFilter);

        if (state.samplePosts?.length > 0 && total !== lastTotalPosts) {
          lastTotalPosts = total;
          renderTable(state.samplePosts);
          show(tableWrap);
        }
      }

      if (state.lastError) showError(state.lastError);
      if (!state.isExtracting && !btnStop.classList.contains('hidden')) {
        onExtractionDone(total);
      }
    });
  }

  function refreshDownloadProgress() {
    if (!currentTabId) return;
    chrome.runtime.sendMessage({ type: 'GET_STATE', tabId: currentTabId }, (state) => {
      if (chrome.runtime.lastError || !state) return;
      const prog = state.downloadProgress;
      if (!prog || prog.total === 0) return;
      show(dlProgressSec);
      dlProgressBar.style.width = prog.percent + '%';
      dlCount.textContent = `${prog.completed + prog.failed} / ${prog.total}`;
      dlPercent.textContent = prog.percent + '%';
      if (prog.currentFilename) dlFilename.textContent = prog.currentFilename;
      if (prog.completed + prog.failed >= prog.total) {
        hide(btnCancelDl);
        btnDlMedia.disabled   = false;
        btnDlVideos.disabled  = false;
      }
    });
  }

  // ── Profile card ──────────────────────────────────────────────────────────
  function updateProfileCard(profile) {
    profileName.textContent = profile.fullName || profile.username || '';
    profileHandle.textContent = '@' + (profile.username || '');
    statPosts.textContent     = formatNum(profile.postCount);
    statFollowers.textContent = formatNum(profile.followerCount);
    show(profileCard);
  }

  // ── Posts table ───────────────────────────────────────────────────────────
  function renderTable(posts) {
    const BADGE = { image: 'bi', video: 'bv', carousel: 'bc', reel: 'br', text: 'bt' };
    const fmtDate = d => {
      if (!d) return '';
      try { return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); }
      catch { return d.slice(0, 10); }
    };
    postsTbody.innerHTML = posts.slice(0, 50).map(p => `
      <tr>
        <td><span class="badge ${BADGE[p.mediaType] || 'bi'}">${p.mediaType || '?'}</span></td>
        <td class="cap">${esc(p.caption) || '<span class="no-cap">—</span>'}</td>
        <td class="num">${formatNum(p.likesCount)}</td>
        <td class="date">${fmtDate(p.publishedAt)}</td>
      </tr>`).join('');
  }

  // ── Extraction UI states ──────────────────────────────────────────────────
  function setExtracting() {
    clearError();
    lastTotalPosts   = 0;
    lastProfileShown = false;
    hide(btnExtract); show(btnStop);
    show(progressSection); show(scrollingInd);
    postCountEl.textContent = '0';
    reelCountEl.textContent = '0';
    extractProgress.style.width = '0%';
    extractProgress.classList.remove('complete');
    startTimer(); startPolling();
    setStatus('working', 'Extracting posts…');
  }

  // Resume extraction UI without resetting counts or timer
  function resumeExtracting(storedStartMs) {
    clearError();
    hide(btnExtract); show(btnStop);
    show(progressSection); show(scrollingInd);
    extractProgress.classList.remove('complete');
    // Restore elapsed time from when extraction actually started
    if (storedStartMs) {
      startTime = storedStartMs;
      if (!timerInterval) timerInterval = setInterval(() => {
        elapsedEl.textContent = formatElapsed(Date.now() - startTime);
      }, 1000);
    } else if (!timerInterval) {
      startTimer();
    }
    startPolling();
    setStatus('working', 'Extracting posts…');
  }

  function onExtractionDone(total) {
    stopTimer(); stopPolling();
    hide(btnStop); show(btnExtract); btnExtract.disabled = false;
    hide(scrollingInd);
    fetchStats.style.display = 'none';
    extractProgress.style.width = '100%';
    extractProgress.classList.add('complete');
    setStatus('ready', `Done — ${total} items extracted`);
    refreshState();
  }

  // ── Download format toggle ────────────────────────────────────────────────
  btnModeFiles.addEventListener('click', () => {
    downloadMode = 'files';
    btnModeFiles.classList.add('active'); btnModeZip.classList.remove('active');
  });
  btnModeZip.addEventListener('click', () => {
    downloadMode = 'zip';
    btnModeZip.classList.add('active'); btnModeFiles.classList.remove('active');
  });

  // ── Extract button (current tab) ──────────────────────────────────────────
  btnExtract.addEventListener('click', () => {
    if (!currentTabId || !currentHandle) return;
    clearError();
    const dates = getDateFilterValues();
    if (dates.error) { showError(dates.error); return; }
    chrome.runtime.sendMessage({
      type: 'START_EXTRACTION',
      tabId: currentTabId,
      dateFilterFrom: dates.from.iso,
      dateFilterTo:   dates.to.iso,
    }, (resp) => {
      if (chrome.runtime.lastError) { showError('Failed: ' + chrome.runtime.lastError.message); return; }
      if (resp?.error) { showError(resp.error); return; }
      setExtracting();
    });
  });

  btnStop.addEventListener('click', () => {
    if (!currentTabId) return;
    chrome.runtime.sendMessage({ type: 'STOP_EXTRACTION', tabId: currentTabId }, () => {
      stopTimer(); stopPolling();
      hide(btnStop); show(btnExtract); btnExtract.disabled = false;
      hide(scrollingInd);
      setStatus('ready', 'Extraction stopped');
    });
  });

  // ── CSV download ──────────────────────────────────────────────────────────
  btnDownloadXL.addEventListener('click', () => {
    if (!currentTabId) return;
    clearError(); btnDownloadXL.disabled = true;
    chrome.runtime.sendMessage({ type: 'DOWNLOAD_EXCEL', tabId: currentTabId }, (resp) => {
      btnDownloadXL.disabled = false;
      if (resp?.error) showError(resp.error);
      else if (resp?.postCount) setStatus('ready', `Excel saved - ${resp.postCount} posts`);
    });
  });

  // ── Clear ─────────────────────────────────────────────────────────────────
  btnClear.addEventListener('click', () => {
    if (!currentTabId) return;
    chrome.runtime.sendMessage({ type: 'CLEAR_DATA', tabId: currentTabId }, () => {
      postCountEl.textContent = '0';
      reelCountEl.textContent = '0';
      btnDownloadXL.disabled  = true;
      btnClear.disabled       = true;
      btnDlMedia.disabled     = true;
      btnDlVideos.disabled    = true;
      btnApplyFilter.disabled = true;
      filterFrom.value        = '';
      filterTo.value          = '';
      filterStatus.textContent = '';
      filterStatus.className   = 'filter-status';
      lastTotalPosts        = 0;
      lastProfileShown      = false;
      extractProgress.style.width = '0%';
      extractProgress.classList.remove('complete');
      hide(progressSection); hide(dlProgressSec); hide(tableWrap); hide(profileCard); hide(dateFilter);
      setStatus('ready', 'Data cleared — ready to extract again');
    });
  });

  // ── Date filter ───────────────────────────────────────────────────────────
  btnApplyFilter.addEventListener('click', () => {
    if (!currentTabId) return;
    clearError();
    const dates = getDateFilterValues();
    if (dates.error) { showError(dates.error); return; }
    const fromVal = dates.from.iso;
    const toVal   = dates.to.iso;
    chrome.runtime.sendMessage(
      { type: 'SET_DATE_FILTER', tabId: currentTabId, fromDate: fromVal, toDate: toVal },
      () => {
        if (fromVal || toVal) {
          filterStatus.textContent = `Active filter: ${dates.from.display || '...'} to ${dates.to.display || '...'}`;
          filterStatus.className   = 'filter-status filtered';
        } else {
          filterStatus.textContent = 'Filter disabled';
          filterStatus.className   = 'filter-status';
        }
        lastTotalPosts = 0;
        refreshState();
      }
    );
  });

  // ── Media downloads ───────────────────────────────────────────────────────
  function startZipDownload(videosOnly) {
    btnDlMedia.disabled = true; btnDlVideos.disabled = true;
    show(dlProgressSec); show(btnCancelDl);
    dlProgressBar.classList.remove('loading');
    dlProgressBar.style.width = '0%';
    dlCount.textContent    = '0 / ?';
    dlPercent.textContent  = '0%';
    dlFilename.textContent = videosOnly ? 'Starting video ZIP download...' : 'Starting media ZIP download...';
    startZipPoll();
    chrome.runtime.sendMessage({ type: 'DOWNLOAD_ZIP', tabId: currentTabId, videosOnly }, (resp) => {
      stopZipPoll();
      btnDlMedia.disabled = false; btnDlVideos.disabled = false;
      hide(btnCancelDl);
      hide(dlProgressSec);
      if (resp?.error) {
        if (resp.error === 'Download stopped') setStatus('ready', 'Download stopped');
        else showError(resp.error);
      }
      else setStatus('ready', `ZIP saved - ${resp.fileCount} files`);
    });
  }

  async function downloadToFolder(videosOnly, dirHandle) {
    const result = await new Promise(resolve =>
      chrome.runtime.sendMessage({ type: 'GET_DOWNLOAD_ITEMS', tabId: currentTabId, videosOnly }, resolve)
    );
    if (downloadCancelled) { hide(dlProgressSec); hide(btnCancelDl); setStatus('ready', 'Download stopped'); return; }
    if (result?.error) { showDownloadError(result.error); return; }
    if (!result?.items?.length) { showDownloadError('No media found'); return; }

    const { items } = result;
    btnDlMedia.disabled = true; btnDlVideos.disabled = true;
    show(dlProgressSec); show(btnCancelDl);
    dlProgressBar.classList.remove('complete');
    dlProgressBar.classList.remove('loading');
    dlProgressBar.style.width = '0%';
    dlCount.textContent    = `0 / ${items.length}`;
    dlPercent.textContent  = '0%';
    folderDlCancelled = false;

    // Fetch each file and write it directly into the chosen folder
    let done = 0;
    for (const item of items) {
      if (folderDlCancelled) break;
      try {
        dlFilename.textContent = item.filename;
        const resp = await fetch(item.mediaUrl, { headers: { Referer: 'https://www.instagram.com/' } });
        if (resp.ok) {
          const buf = await resp.arrayBuffer();
          const bytes = new Uint8Array(buf);
          // Correct extension by magic bytes (MP4 ftyp box at offset 4)
          const isMp4 = bytes.length > 11 &&
            bytes[4] === 0x66 && bytes[5] === 0x74 && bytes[6] === 0x79 && bytes[7] === 0x70;
          const finalName = isMp4
            ? item.filename.replace(/\.(jpg|jpeg|png|webp)$/i, '.mp4')
            : item.filename.replace(/\.mp4$/i, '.jpg');
          dlFilename.textContent = finalName;
          const fh = await dirHandle.getFileHandle(finalName, { create: true });
          const writable = await fh.createWritable();
          await writable.write(new Blob([bytes]));
          await writable.close();
        }
      } catch (_) { /* skip unreachable files */ }
      done++;
      const pct = Math.round(done / items.length * 100);
      dlProgressBar.style.width = pct + '%';
      dlCount.textContent    = `${done} / ${items.length}`;
      dlPercent.textContent  = pct + '%';
    }

    hide(btnCancelDl);
    btnDlMedia.disabled = false; btnDlVideos.disabled = false;
    if (!folderDlCancelled) {
      dlProgressBar.classList.add('complete');
      setStatus('ready', `${done} file(s) saved in the selected folder`);
    } else {
      dlFilename.textContent = 'Cancelled';
    }
  }

  btnDlMedia.addEventListener('click', async () => {
    if (!currentTabId) return;
    clearError();
    if (downloadMode === 'zip') {
      showDownloadStarting('Starting media ZIP download...');
      if (await ensurePostsReadyForDownload()) startZipDownload(false);
      return;
    }
    let dirHandle;
    try {
      showDownloadStarting('Choose a folder to save media...');
      dirHandle = await window.showDirectoryPicker({ mode: 'readwrite', startIn: 'downloads' });
    } catch (_) {
      hide(dlProgressSec); hide(btnCancelDl);
      setStatus('ready', 'Download cancelled');
      return;
    }
    showDownloadStarting('Starting media download...');
    if (!(await ensurePostsReadyForDownload())) return;
    downloadToFolder(false, dirHandle).catch(err => showError('Error: ' + err.message));
  });

  btnDlVideos.addEventListener('click', async () => {
    if (!currentTabId) return;
    clearError();
    if (downloadMode === 'zip') {
      showDownloadStarting('Starting video ZIP download...');
      if (await ensurePostsReadyForDownload()) startZipDownload(true);
      return;
    }
    let dirHandle;
    try {
      showDownloadStarting('Choose a folder to save videos...');
      dirHandle = await window.showDirectoryPicker({ mode: 'readwrite', startIn: 'downloads' });
    } catch (_) {
      hide(dlProgressSec); hide(btnCancelDl);
      setStatus('ready', 'Download cancelled');
      return;
    }
    showDownloadStarting('Starting video download...');
    if (!(await ensurePostsReadyForDownload())) return;
    downloadToFolder(true, dirHandle).catch(err => showError('Error: ' + err.message));
  });

  btnCancelDl.addEventListener('click', () => {
    folderDlCancelled = true;
    downloadCancelled = true;
    if (currentTabId) {
      chrome.runtime.sendMessage({ type: 'STOP_EXTRACTION', tabId: currentTabId }, () => {});
      chrome.runtime.sendMessage({ type: 'CANCEL_DOWNLOADS', tabId: currentTabId }, () => {});
    }
    hide(btnCancelDl);
    dlProgressBar.classList.remove('loading');
    dlFilename.textContent = 'Stopping download...';
    setStatus('ready', 'Stopping download...');
  });

  // ── Init: detect current tab platform ────────────────────────────────────
  function init() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab) { setStatus('error', 'No active tab'); return; }

      const detected = PlatformDetector.detect(tab.url);
      if (!detected) {
        setStatus('', 'Enter a username above or navigate to a social profile');
        return;
      }

      currentTabId    = tab.id;
      currentPlatform = detected.platform;
      currentHandle   = detected.handle;
      applyPlatform(detected.platform);
      usernameEl.textContent = '@' + detected.handle;
      show(profileInfo); show(tabNav);
      show(dateFilter); btnApplyFilter.disabled = false;
      btnDlMedia.disabled = false;
      btnDlVideos.disabled = false;

      chrome.runtime.sendMessage({ type: 'GET_STATE', tabId: currentTabId }, (state) => {
        // Discard state from a different profile (stale data from previous SPA navigation)
        if (state?.handle && state.handle !== currentHandle) {
          setStatus('ready', 'Ready to extract');
          btnExtract.disabled = false;
          btnDlMedia.disabled = false;
          btnDlVideos.disabled = false;
          return;
        }
        if (state?.profile) { updateProfileCard(state.profile); lastProfileShown = true; }
        // Restore saved date filter inputs
        if (state?.dateFilterFrom) filterFrom.value = formatDisplayDate(state.dateFilterFrom);
        if (state?.dateFilterTo)   filterTo.value   = formatDisplayDate(state.dateFilterTo);
        if (state?.dateFilterFrom || state?.dateFilterTo) {
          filterStatus.textContent = `Active filter: ${formatDisplayDate(state.dateFilterFrom) || '...'} to ${formatDisplayDate(state.dateFilterTo) || '...'}`;
          filterStatus.className   = 'filter-status filtered';
        }
        if (state?.totalPosts > 0) {
          show(progressSection);
          postCountEl.textContent  = state.feedCount  || 0;
          reelCountEl.textContent  = state.reelCount  || 0;
          btnDownloadXL.disabled   = false;
          btnClear.disabled        = false;
          btnDlMedia.disabled      = false;
          btnDlVideos.disabled     = false;
          btnApplyFilter.disabled  = false;
          show(dateFilter);
          extractProgress.style.width = '100%';
          extractProgress.classList.add('complete');
          if (state.samplePosts?.length > 0) { renderTable(state.samplePosts); show(tableWrap); }
          if (state.isExtracting) {
            chrome.storage.session.get('ig_extract_start', (r) => resumeExtracting(r.ig_extract_start));
          } else setStatus('ready', `${state.totalPosts} posts ready — click Extract to refresh`);
        } else if (state?.isExtracting) {
          chrome.storage.session.get('ig_extract_start', (r) => resumeExtracting(r.ig_extract_start));
        } else {
          // Check if extraction is running on another tab (user switched away from Instagram)
          chrome.storage.session.get(['ig_active_tab', 'ig_extract_start'], (r) => {
            const activeTid = parseInt(r['ig_active_tab'] || '0', 10);
            if (!activeTid || activeTid === currentTabId) {
              setStatus('ready', 'Ready to extract');
              btnExtract.disabled = false;
              return;
            }
            // Switch context to the extracting tab so polling shows live progress
            currentTabId = activeTid;
            resumeExtracting(r.ig_extract_start);
          });
          return;
        }
        if (state?.lastError) showError(state.lastError);
      });
    });
  }

  init();
})();
