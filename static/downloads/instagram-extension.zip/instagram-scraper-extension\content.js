// content.js - Runs on instagram.com, makes API calls directly (same-origin, cookies included automatically)

(function () {
  'use strict';

  let isExtracting = false;
  let stopRequested = false;

  function getUsername() {
    const match = window.location.pathname.match(/^\/([a-zA-Z0-9._]+)\/?$/);
    return match ? match[1] : null;
  }

  function getCsrf() {
    const m = document.cookie.match(/csrftoken=([^;]+)/);
    return m ? m[1] : '';
  }

  function instagramHttpError(status) {
    if (status === 429) {
      return 'Instagram is rate-limiting this account/session right now (HTTP 429). Wait a few minutes, refresh Instagram, and try again while logged in.';
    }
    if (status === 401 || status === 403) {
      return `Instagram rejected the request (HTTP ${status}). Refresh Instagram and make sure you are logged in.`;
    }
    return `Instagram returned HTTP ${status}`;
  }

  // Fetch using the page's own session (same-origin, no CORS issues)
  async function igFetch(url) {
    for (let attempt = 0; attempt < 4; attempt++) {
      const resp = await window.fetch(url, {
        method: 'GET',
        headers: {
          'X-IG-App-ID': '936619743392459',
          'X-CSRFToken': getCsrf(),
          'X-Requested-With': 'XMLHttpRequest',
          'X-ASBD-ID': '129477',
          'X-IG-WWW-Claim': sessionStorage.getItem('www-claim-v2') || '0',
          'Accept': 'application/json',
        },
        credentials: 'include',
      });
      if (resp.ok) return resp.json();
      if (resp.status !== 429 || attempt === 3) throw new Error(instagramHttpError(resp.status));
      await sleep([30000, 60000, 120000][attempt] + Math.random() * 5000);
    }
  }

  async function getUserId(username) {
    const data = await igFetch(
      `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`
    );
    const id = data?.data?.user?.id || data?.data?.user?.pk;
    if (!id) throw new Error('Could not get user ID. Response: ' + JSON.stringify(data).substring(0, 150));
    return String(id);
  }

  async function fetchPage(userId, cursor) {
    let url = `https://www.instagram.com/api/v1/feed/user/${userId}/?count=12`;
    if (cursor) url += `&max_id=${encodeURIComponent(cursor)}`;
    return igFetch(url);
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function runExtraction(username) {
    isExtracting = true;
    stopRequested = false;

    try {
      console.log('[IG Scraper] Starting for:', username);
      console.log('[IG Scraper] CSRF token:', getCsrf() ? 'found' : 'NOT FOUND');

      chrome.runtime.sendMessage({ type: 'EXTRACTION_STARTED', username });

      const userId = await getUserId(username);
      console.log('[IG Scraper] User ID:', userId);

      let cursor = null;
      let moreAvailable = true;
      let emptyPages = 0;

      while (moreAvailable && !stopRequested) {
        const data = await fetchPage(userId, cursor);
        const items = data?.items || [];

        console.log(`[IG Scraper] Got ${items.length} items, more=${data?.more_available}`);

        if (items.length > 0) {
          emptyPages = 0;
          await new Promise((resolve) => {
            chrome.runtime.sendMessage({ type: 'POST_DATA', data: { items } }, resolve);
          });
        } else {
          emptyPages++;
        }

        moreAvailable = !!data?.more_available;
        cursor = data?.next_max_id || null;
        if (emptyPages >= 3 || !cursor) break;

        await sleep(9000 + Math.random() * 5000);
      }

      console.log('[IG Scraper] Extraction complete');
      chrome.runtime.sendMessage({ type: 'EXTRACTION_COMPLETE' });

    } catch (err) {
      console.error('[IG Scraper] Error:', err.message);
      chrome.runtime.sendMessage({ type: 'EXTRACTION_ERROR', error: err.message });
    } finally {
      isExtracting = false;
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {
      case 'START_EXTRACTION':
        if (isExtracting) { sendResponse({ status: 'already_running' }); return; }
        const username = getUsername();
        if (!username) { sendResponse({ error: 'No username in URL' }); return; }
        runExtraction(username);
        sendResponse({ status: 'started' });
        break;
      case 'STOP_EXTRACTION':
        stopRequested = true;
        isExtracting = false;
        sendResponse({ status: 'stopped' });
        break;
      case 'GET_PAGE_INFO':
        sendResponse({ username: getUsername(), url: window.location.href });
        break;
      case 'PING':
        sendResponse({ status: 'alive' });
        break;
    }
    return true;
  });
})();
